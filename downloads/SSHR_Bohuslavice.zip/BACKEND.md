# SSHR Bohuslavice – BACKEND.md

> Živý zápis o MQTT backendu, kontejnerech a souvisejících službách pro SSHR/CEPRO deployment.  
> Udržuj formát Markdown, nové poznámky přidávej jako sekce `##`.

---

## MQTT Broker (Mosquitto)

- **Server:** `ds2203-mspan-01`
- **Docker image:** `eclipse-mosquitto:2.0`
- **Container name:** `mosquitto`
- **Porty:** `1883/tcp` (klasické MQTT), `9001/tcp` (WebSocket pro frontend)
- **Autentizace:** `allow_anonymous false`, přihlašovací údaje uložené v `/mosquitto/config/passwords`
- **Konfigurace:** `/volume1/DATA/INTEGRATION/mqtt/config/mosquitto.conf`
- **Typické topics:** `cepro/session/*`, `cepro/position`, `cepro/zones`, `cepro/incident/*`
- **Síťová adresa:** broker běží na NASu (`192.168.60.3`) na portu `1883` (MQTT) / `9001` (WebSocket).
- **Klientská aplikace (ČEPRO)** posílá MQTT publish na IP NASu s přihlášením `cepro / SILNE-HESLO`.
- **Topic convention:** `cepro/data`, `cepro/events`, `cepro/#` (wildcard pro všechny podtopics).

### Mosquitto klientské nástroje

- `mosquitto_sub` / `mosquitto_pub` nejsou nainstalované na samotném Synology NASu – běží jen broker v Dockeru.
- Pokud potřebuješ vytvořit heslo, spusť jednorázový kontejner:

```bash
sudo docker run --rm -it \
  -v /volume1/DATA/MQTT/config:/mosquitto/config \
  eclipse-mosquitto:2.0 \
  mosquitto_passwd -c /mosquitto/config/passwords cepro
```

- Po zadání hesla může Mosquitto hlásit:  
  `Warning: File .../passwords has world readable permissions.`  
  → oprav na `chmod 0700 /volume1/DATA/MQTT/config/passwords`.

- Aktuální obsah `passwords` (hash pro uživatele `cepro`):

```
cepro:$7$101$LJhA3wohhsqmAiTW$9OFoYv0GHOqTzphF6pGkljXYxNKlD5fagDFfUrp7nuPrkL/N0WFk4w6mhBJym5+TcEBIkRWA7H34fHi2HyD4wA==
```

- Heslo: **SILNE-HESLO**

- Spuštění brokeru (manuálně):

```bash
sudo docker run -d \
  --name mosquitto \
  -p 1883:1883 \
  -p 9001:9001 \
  -v /volume1/DATA/MQTT/config:/mosquitto/config \
  -v /volume1/DATA/MQTT/data:/mosquitto/data \
  eclipse-mosquitto:2.0
```

- Test subscription (z NASu, přes `docker exec`, protože klienti nejsou v host OS):

```bash
sudo docker exec -it mosquitto \
  mosquitto_sub -h 127.0.0.1 -p 1883 \
    -u cepro -P "SILNE-HESLO" \
    -t 'test/topic'
```

## Docker služby (snapshot 07.11.2025)

| Container | Image | Stav | Porty / Popis |
|-----------|-------|------|---------------|
| `mosquitto` | `eclipse-mosquitto:2.0` | Up 2 weeks | 1883, 9001 – MQTT broker |
| `cepro-md2pdf` | `pandoc/latex:3.1` | Restarting (1) každých ~45 s | Konverze Markdown → PDF |
| `stack-promtail-1` | `grafana/promtail:2.9.8` | Up 4 weeks | Log shipper do Loki |
| `tileserver` | `maptiler/tileserver-gl` | Up 4 weeks (healthy) | 8092→8080 – mapové dlaždice |
| `stack-grafana-1` | `grafana/grafana:10.4.6` | Up 4 weeks | 3000 – dashboardy |
| `stack-loki-1` | `grafana/loki:2.9.8` | Up 4 weeks | 3100 – log storage |
| `cepro-ingestor` | `agent-cepro-ingestor` | Up 5 weeks | 8000 – REST ingest API |
| `nginx:alpine` (`3724e065003e`) | `nginx:alpine` | Up | Reverzní proxy pro Grafana Explore |

> Výpis pochází z `sudo docker ps` na hostu `ds2203-mspan-01`.

## Monitoring & přístupy

- **Grafana hlavní UI:** `http://ds2203-mspan-01:3000`
- **Grafana Explore (Loki dotazy):** `http://ds2203-mspan-01:3000/explore`
- **SSH přístup:** `ssh MARSPA@ds2203-mspan-01`

## TODO / Poznámky

- [ ] Sleduj restart loop u `cepro-md2pdf` (znovu zbuildit pandoc kontejner / zkontrolovat vstupní soubory).
- [ ] Dopsat MQTT topics pro incident eval (`cepro/incident/eval`) včetně payload struktury.
- [ ] Přidat log rotaci pro `/volume1/DATA/INTEGRATION/mqtt/data/` (aktuálně jen manuální čištění).
