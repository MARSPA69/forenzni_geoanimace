# BE Jupiter GIS – Backend Integration Handbook  
**Projekt:** SSHR Bohuslavice  **Revize:** 2025‑11‑06  **Verze dokumentu:** 2.0

---

## 1. Architektura řešení

```
┌─────────────────────┐        ┌──────────────────────────┐        ┌───────────────────────────┐
│  SSHR Frontend      │  HTTPS │    NAS Gateway (5050)     │  IPC   │  Jupiter Worker (Notebook) │
│  jupiter-gis-connector.js ───▶  FastAPI / uvicorn        ├─queue─▶│  docker: jupyter/datascience│
│                     │        │  /volume1/DATA/SSHR_JUPITER│       │  výsledky ukládá na NAS    │
└────────┬────────────┘        └────────────┬──────────────┘        └───────────┬───────────────┘
         │                                   │                                   │
         │                                   ▼                                   ▼
         │                        NAS sdílená data: inbox/  analysis/  logs/   (JSON/CSV/PDF)
         │
         ▼
 fallback režim (mock analýzy) – žádná komunikace s NAS
```

### Klíčové komponenty
| Vrstva | Popis | Technologie |
| --- | --- | --- |
| FE konektor | export tracking dat, volání NAS API, příjem analýz | `jupiter-gis-connector.js` |
| NAS Gateway | REST API, audit, správa jobů | `python:3.11-slim` + FastAPI / uvicorn |
| Worker | Jupiter / notebook analýzy, dávkové skripty | `jupyter/datascience-notebook` |
| Storage | Persistentní úložiště exportů a výsledků | `/volume1/DATA/SSHR_JUPITER` |

---

## 2. NAS adresářová struktura

```
/volume1/DATA/SSHR_JUPITER/
 ├── inbox/            # snapshoty ze SSHR (JSON)
 ├── analysis/         # výsledky analýz (JSON/CSV/PDF)
 ├── logs/             # gateway & worker logy
 ├── docker-compose.yml
 ├── .env              # tajné údaje (token, cesty)
 ├── .env.example      # vzor
 ├── config.json       # retence, profily, metadata
 └── README.md         # provozní poznámky
```

> Pozn.: `.gitkeep` soubory držíme jen v repozitáři; na NASu nejsou potřeba.

---

## 3. Docker Compose služby

```yaml
version: "3.9"

services:
  sshr-jupiter-gateway:
    image: python:3.11-slim
    container_name: sshr-jupiter-gateway
    restart: unless-stopped
    env_file: [.env]
    working_dir: /app
    command: >
      sh -c "pip install --no-cache-dir -r requirements.txt &&
             uvicorn app.main:app --host 0.0.0.0 --port ${SERVER_PORT:-5050}"
    volumes:
      - ./gateway:/app
      - ./inbox:/data/inbox
      - ./analysis:/data/analysis
      - ./logs:/data/logs
      - ./config.json:/app/config.json:ro
    ports: ["5050:5050"]
    networks: [sshr-jupiter-net]

  sshr-jupiter-worker:
    image: jupyter/datascience-notebook:latest
    container_name: sshr-jupiter-worker
    restart: unless-stopped
    env_file: [.env]
    working_dir: /home/jovyan/work
    command: start-notebook.sh --NotebookApp.token='' --NotebookApp.password=''
    volumes:
      - ./notebooks:/home/jovyan/work/notebooks
      - ./analysis:/home/jovyan/work/analysis
      - ./inbox:/home/jovyan/work/inbox
      - ./logs:/home/jovyan/work/logs
    ports: ["8889:8888"]
    networks: [sshr-jupiter-net]

networks:
  sshr-jupiter-net:
    driver: bridge
```

---

## 4. Konfigurační soubory

### `.env` (vytvoř z `.env.example`)
```dotenv
JUPITER_API_TOKEN=**************
NAS_EXPORT_BASE=/volume1/DATA/SSHR_JUPITER/inbox
NAS_ANALYSIS_BASE=/volume1/DATA/SSHR_JUPITER/analysis
NAS_LOG_BASE=/volume1/DATA/SSHR_JUPITER/logs
JUPITER_API_URL=https://jupiter.example.com/api   # volitelné
JUPITER_JOB_QUEUE=sshr_jupiter
ALLOWED_ORIGIN=https://192.168.1.93:5001
SERVER_PORT=5050
```

### `config.json` (výchozí)
```json
{
  "version": "1.0.0",
  "facility": "SSHR_Bohuslavice",
  "endpoints": {
    "export": "/sshr/jupiter/export",
    "analysis": "/sshr/jupiter/analysis",
    "analysisLatest": "/sshr/jupiter/analysis/latest"
  },
  "retention": {
    "exportsDays": 30,
    "analysisDays": 90,
    "logsDays": 14
  },
  "jupiter": {
    "analyticProfiles": [
      "risk-score",
      "pattern-detection",
      "zone-optimization"
    ],
    "defaultJobProfile": "sshr-risk-eval"
  }
}
```

---

## 5. REST API gateway (HTTPS 5050)

Zabezpečení: `Authorization: Bearer <JUPITER_API_TOKEN>`

| Endpoint | Metoda | Tělo / Parametry | Popis |
| --- | --- | --- | --- |
| `/sshr/jupiter/export` | `POST` | JSON snapshot z `exportSSHRData()` | Uloží export do `inbox/`, zapíše audit |
| `/sshr/jupiter/analysis` | `POST` | `{ "trigger": "...", "priority": "...", ... }` | Spustí Jupiter job / notebook (worker) |
| `/sshr/jupiter/analysis/latest` | `GET` | — | Vrátí poslední dostupnou analýzu (`analysis/`) |
| `/sshr/jupiter/health` *(doporučeno)* | `GET` | — | Stav gateway, workeru, storage |

### Příklad požadavku z FE
```javascript
await fetch('https://192.168.1.93:5050/sshr/jupiter/export', {
  method: 'POST',
  headers: {
    'Authorization': `Bearer ${token}`,
    'Content-Type': 'application/json'
  },
  body: JSON.stringify(exportData)
});
```

### Odpovědi
- `201 Created` + `{exportId, storedAt}` – export uložen
- `202 Accepted` – analýza přijata, běží job (gateway vrátí `jobId`)
- `200 OK` – poslední analýza (`{ analysis: {...}, metadata: {...} }`)
- `4xx/5xx` – chyba (gateway zapíše do `logs/` + FE přepne na fallback)

---

## 6. Workflow

1. **Export**  
   - FE (`exportSSHRData`) → `POST /export`  
   - Soubor uložen do `inbox/YYYY/MM/sshr_snapshot_<timestamp>.json`  
   - Audit: `nas:export`

2. **Analýza**  
   - FE → `POST /analysis` (trigger `periodic`, `zones-updated`, `incident-start` …)  
   - Gateway zapíše job → worker načte z `inbox/`, provede notebook skript, výsledek uloží do `analysis/`.

3. **Výsledek**  
   - FE → `GET /analysis/latest` nebo push přes WebSocket (volitelné)  
   - `jupiter-analysis-updated` event nese `{analysis, context}` (`mode: remote/moc/fallback`).

4. **Fallback**  
   - Pokud NAS neodpovídá, konektor přejde do mock režimu (`fallbackToMockMode`) a pracuje čistě lokálně.

---

## 7. Monitoring & logy

| Složka | Obsah | Poznámky |
| --- | --- | --- |
| `logs/gateway.log` | REST přístupy, chyby, audit | logrotate 14 dní |
| `logs/worker.log` | běh notebooku, výsledky | retenční politika 30 dní |
| `analysis/*` | JSON/CSV/PDF analýzy | dle `analysisDays` v configu |
| `inbox/*` | vstupní snapshoty | čistit CRONem (např. po 30 dnech) |

Monitoring doporučený přes `docker logs` + NAS grafy (Grafana / Synology log center).

---

## 8. Bezpečnost

- API token pouze v `.env` (nenahrávat do git).  
- HTTPS certifikát na NAS (self-signed OK, FE nastavit `https://192.168.1.93:5050`).  
- Omezení přístupu jen z interní sítě (firewall / VPN).  
- Worker notebook běží bez hesla – povolit jen administrátorům (např. omezit port 8889).  
- FE konfig (token, URL) injektovat při buildu nebo přes `window.SSHR_CONFIG.jupiter`.

---

## 9. Postup nasazení

1. Přihlásit se na NAS, vytvořit `/volume1/DATA/SSHR_JUPITER/`.  
2. Zkopírovat soubory z repozitáře (`docker-compose.yml`, `.env.example`, `config.json`, `README.md`).  
3. Vytvořit `.env`, doplnit `JUPITER_API_TOKEN` a případně další proměnné.  
4. `docker-compose up -d` v adresáři `/volume1/DATA/SSHR_JUPITER/`.  
5. Ověřit `https://192.168.1.93:5050/sshr/jupiter/analysis/latest` (měl by vrátit prázdné JSON / info).  
6. Na FE nastavit:
   ```javascript
   window.SSHR_CONFIG = {
     ...window.SSHR_CONFIG,
     jupiter: {
       enabled: true,
       mockMode: false,
       baseUrl: 'https://192.168.1.93:5050',
       token: '<JUPITER_API_TOKEN>',
       exportInterval: 30000
     }
   };
   ```
7. Spustit aplikaci, zkontrolovat, že `inbox/` přijímá snapshoty a `analysis/` vzniká po volání `/analysis`.

---

## 10. TODO / další rozvoj

- Doplnit endpoint `/health` a `/jobs/{id}` na gateway.  
- Automatizovat retenci (cron skript nebo NAS Shared Folder tasks).  
- Napojit worker na skutečné Jupiter API místo mock notebooku.  
- Vytvořit dashboard v Grafaně nad logy `logs/` a analýzami `analysis/`.  
- Implementovat WebSocket push z gateway → FE (`analysis_complete`, `alert`, `zone_recommendation`).

---

> Správce NAS: `https://192.168.1.93:5001/`  
>  – struktura, Compose a soubory jsou připraveny v repozitáři (`adminlte/dist/SSHR_Bohuslavice/NAS/SSHR_JUPITER/`).
