/**
 * SSHR Bohuslavice - Global configuration
 * ---------------------------------------
 * Extracted from the renderer so that other modules (UI, engines, tests)
 * can safely consume a single source of truth.
 */

(function configureSSHR(global) {
  const SSHR_CONFIG = Object.freeze({
    version: '2.0.0',
    areaName: 'SSHR Bohuslavice',
    mode: 'persons-only',
    polygonMode: 'FIXED',
    map: {
      center: [50.33051536896484, 16.094826778414713],
      zoom: 18,
      minZoom: 15,
      maxZoom: 22
    },
    limits: {
      maxPersons: 50,
      maxCards: 20
    },
    timings: {
      updateInterval: 1000,
      animationSpeed: 800
    }
  });

  global.SSHR_CONFIG = SSHR_CONFIG;
})(window);

console.log('✅ [CONFIG] SSHR configuration loaded');
