// Dataset: Síť prvků komunikační, energetické a podpůrné infrastruktury

window.INFRA_PRVKY = [
  {
    name: "Dieselagregát",
    coordinates: { lat: 50.3292808, lon: 16.09306 },
    priority: "HIGH",
  },
  {
    name: "HUP",
    coordinates: { lat: 50.33096772322275, lon: 16.095364847864538 },
    priority: "HIGH",
  },
  {
    name: "HUE",
    coordinates: { lat: 50.33094632792218, lon: 16.095328736671746 },
    priority: "HIGH",
  },
  {
    name: "Hydrant",
    coordinates: { lat: 50.32990670054917, lon: 16.093686692517604 },
    priority: "MEDIUM",
  },
  {
    name: "Požární hlásič 1",
    coordinates: { lat: 50.3302164, lon: 16.09451 },
    priority: "MEDIUM",
  },
  {
    name: "RHP",
    coordinates: { lat: 50.3301358, lon: 16.0945636 },
    priority: "MEDIUM",
  },
  {
    name: "RHP",
    coordinates: { lat: 50.3305792, lon: 16.0949231 },
    priority: "MEDIUM",
  },
  {
    name: "Vchod do skladu#1",
    coordinates: { lat: 50.3316156770679, lon: 16.096002206952612 },
    priority: "HIGH",
  },
  {
    name: "Vchod do skladu#2",
    coordinates: { lat: 50.33145138997785, lon: 16.096331155041785 },
    priority: "HIGH",
  },
  {
    name: "Vchod do skladu#3",
    coordinates: { lat: 50.32968630353728, lon: 16.093757814956543 },
    priority: "MEDIUM",
  },
  {
    name: "Vchod do skladu#4",
    coordinates: { lat: 50.32952308159876, lon: 16.094098924756256 },
    priority: "MEDIUM",
  },
  {
    name: "Vchod do servisní místnosti#5",
    coordinates: { lat: 50.328602786347616, lon: 16.09249508238547 },
    priority: "MEDIUM",
  },
  {
    name: "Vchod do skladu#6",
    coordinates: { lat: 50.32886691692882, lon: 16.09336784991159 },
    priority: "MEDIUM",
  },
  {
    name: "Vchod do skladu#7",
    coordinates: { lat: 50.329032626246345, lon: 16.093002210545254 },
    priority: "MEDIUM",
  },
  {
    name: "Vchod do skladu#8",
    coordinates: { lat: 50.33109057030257, lon: 16.094984830234793 },
    priority: "HIGH",
  },
];

// Make available globally for SSHR renderer
console.log(`🏭 [INFRA] Loaded ${window.INFRA_PRVKY.length} infrastructure elements`);
