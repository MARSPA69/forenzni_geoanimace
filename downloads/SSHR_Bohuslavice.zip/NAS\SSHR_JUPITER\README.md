# SSHR ↔ Jupiter NAS Gateway

Tento adresář zrcadlí strukturu, která má být vytvořena na NASu ve složce `/volume1/DATA/SSHR_JUPITER/`.

## Struktura

```
/volume1/DATA/SSHR_JUPITER/
 ├── inbox/            # příchozí JSON exporty ze snapshotů
 ├── analysis/         # výsledky Jupiter analýz (JSON, CSV, PDF…)
 ├── logs/             # logy backendu / workerů
 ├── docker-compose.yml
 ├── .env              # vytvořte z .env.example, doplňte TOKEN
 └── config.json       # volitelná mapování, retence, profily
```

## Docker služby (návrh)

| Služba                 | Image                         | Popis                                   |
| ---------------------- | ----------------------------- | --------------------------------------- |
| `sshr-jupiter-gateway` | `python:3.11-slim`            | REST API (`/sshr/jupiter/...`)          |
| `sshr-jupiter-worker`  | `jupyter/datascience-notebook`| Analýzy / notebooky, přístup na NAS data|

## Endpoints

| Endpoint                                                 | Metoda | Popis                                 |
| -------------------------------------------------------- | ------ | ------------------------------------- |
| `https://192.168.1.93:5050/sshr/jupiter/export`          | POST   | přijímá JSON exporty ze snapshotů     |
| `https://192.168.1.93:5050/sshr/jupiter/analysis`        | POST   | spouští Jupiter analýzu / Docker job  |
| `https://192.168.1.93:5050/sshr/jupiter/analysis/latest` | GET    | vrací poslední výsledek analýzy       |

> Na FE straně se token + endpoint načítá přes `window.SSHR_CONFIG.jupiter`.

## Postup nasazení

1. Na NASu vytvoř `/volume1/DATA/SSHR_JUPITER/` a podadresáře `inbox/`, `analysis/`, `logs/`.
2. Zkopíruj `docker-compose.yml`, `config.json` a `.env.example`. Soubor `.env` doplň o reálný `JUPITER_API_TOKEN`.
3. Spusť `docker-compose up -d` – gateway poběží na portu `5050`, Jupyter notebook na `8889`.
4. Z FE (aplikace SSHR) nastav:
   ```js
   window.SSHR_CONFIG = {
     ...window.SSHR_CONFIG,
     jupiter: {
       enabled: true,
       baseUrl: 'https://192.168.1.93:5050',
       token: '...NAS TOKEN...',
       mockMode: false,
       exportInterval: 30000
     }
   };
   ```
5. Konektor automaticky odesílá exporty, žadá analýzy a načítá výsledky. Při výpadku NAS se přepne do mock režimu.

## Poznámky

- Složky obsahují `.gitkeep`, aby byly verzované – na NAS je není potřeba nechávat.
- Worker (`jupyter/datascience-notebook`) startuje s prázdným tokenem – zajisti omezení přístupu na úrovni sítě.
- Logy a exporty mají retention v `config.json` (`exportsDays`, `analysisDays`, `logsDays`); backend by měl mazat starší soubory podle těchto hodnot.
