# SSHR Bohuslavice – Real-time GPS Validation Plan

## Objectives
- **Prevent false positives** by validating incoming GNSS samples before they update the map.
- **Surface actionable feedback** inside person panels, incident widgets, and marker popups.
- **Keep parity with ČEPRO UX** so operators experience identical workflows.

## Validation Pipeline
1. **Sample Intake**
   - Centralise all live updates (parallel datasets, manual drops, future MQTT feed) through a new `ValidationService`.
   - Normalise sample format (`{lat,lng,timestamp,accuracy,speed}`) before any map interaction.
2. **Static Checks**
   - Range guard: reject coordinates outside perimeter fence with severity “critical”.
   - Precision thresholds: flag `accuracy > 5m` as warning; discard > 20m.
   - Time sanity: ignore samples older than last accepted timestamp for the person.
3. **Dynamic Analysis**
   - Velocity delta: compare against previous sample to detect teleport jumps (`>15m` within <1s).
   - Zone diff: call `SSHRIncidentEngine.evaluatePosition` only after validation flag `valid === true`.
   - Drift scoring: maintain a rolling window (e.g. last 15s) to compute mean accuracy and stability; expose as KPI in panel.
4. **Feedback Hooks**
   - Person marker tooltip:
     - Add validation badge (`OK / WARN / FAIL`) and last accuracy reading.
   - Parallel panel:
     - Display accuracy + drift metrics, highlight row when state is “warn”.
   - Incident widget:
     - Include validation context with each violation (e.g. “Entered RED (accuracy 2.3m)”).
   - Visitor card modal:
     - Show last validation status before allowing card handover/return.
5. **Escalation**
   - On validation failure: prevent marker move, log to IncidentManager with type `gps-validation`.
   - On consecutive warnings (>3 within 30s): auto-escalate to operator via toast + optional audio cue.

## Implementation Steps
1. **Module Skeleton**
   - `validation-engine.js`: exports `validateSample(personId, sample)` returning `{valid, severity, reason, adjustedSample}`.
   - Wire into `parallel-engine` and manual drop handler before `PersonTracker.updatePersonPosition`.
2. **State Persistence**
   - Extend `PersonTracker` to store `validation` object on each person (`{status, lastValidSample, metrics}`).
   - Expose helper `getValidationState(personId)` for UI components.
3. **UI Updates**
   - Update marker popup template and `parallel-panel` adapter to include validation pill.
   - Add CSS modifiers in `sshr_styles.css` for `.validation-ok`, `.validation-warn`, `.validation-fail`.
   - Extend IncidentManager templates to accept validation payload.
4. **Testing**
   - Unit tests (Jest or Vitest) for validation rules using mocked samples.
   - Browser integration script that replays edge-case datasets (low accuracy, rapid jumps).
   - Manual QA checklist mirroring ČEPRO scenario scripts.

## Data Quality Monitoring
- Store validation metrics per session (JSON export) for offline analysis.
- Aggregate dashboard (Grafana/Metabase) fed by exported logs for long-term drift tracking.

## Dependencies & Open Questions
- Source of `accuracy`/`speed` for live data — ensure provider updates format.
- Confirm operator tolerance thresholds with security team.
- Align incident taxonomy (`gps-validation`) with reporting backend.

## Deliverables Breakdown
| Milestone | Scope | Owner | ETA |
|-----------|-------|-------|-----|
| M1 – Validation Engine | Build `validation-engine.js`, integrate with PersonTracker | FE Dev | T+3 days |
| M2 – UI Feedback | Panels, popups, incident badges | UI Dev | T+5 days |
| M3 – Reporting | Session export + dashboard ingestion | Data Eng | T+8 days |
| M4 – QA & Sign-off | Automated + manual scenario validation | QA | T+9 days |

