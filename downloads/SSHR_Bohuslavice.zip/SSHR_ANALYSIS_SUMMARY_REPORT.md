# 📊 SSHR Dataset Analysis - Souhrnný Report

**Datum analýzy:** 2025-11-07
**Analyzované soubory:** SSHR_DATA1-7.js
**RED FENCE perimeter:** Definován v ZONES_SSHR.js

## 🎯 Celkové výsledky

| Dataset     | GPS body | Mimo perimeter | Anomálie (>20 km/h) | Kvalita |
|-------------|----------|----------------|---------------------|---------|
| SSHR_DATA1  | 1,645    | 4 (0.24%)      | 7 (0.43%)           | 99.5/100 ✅ |
| SSHR_DATA2  | 1,410    | 5 (0.35%)      | 5 (0.35%)           | 99.5/100 ✅ |
| SSHR_DATA3  | 192      | 25 (13.02%)    | 50 (26.04%)         | 67.4/100 ⚠️ |
| SSHR_DATA4  | 167      | 9 (5.39%)      | 122 (73.05%)        | 57.3/100 ⚠️ |
| SSHR_DATA5  | 159      | 63 (39.62%)    | 125 (78.62%)        | 40.2/100 ❌ |
| SSHR_DATA6  | 87       | 11 (12.64%)    | 59 (67.82%)         | 53.7/100 ⚠️ |
| SSHR_DATA7  | 138      | 1 (0.72%)      | 77 (55.80%)         | 59.6/100 ⚠️ |
| **CELKEM**  | **3,798** | **118 (3.11%)** | **445 (11.72%)**   | **68.2/100** |

## 📋 Klíčové pozorování

### ✅ **Vynikající datasety** (Kvalita ≥ 90%)
- **SSHR_DATA1**: Nejkvalitnější dataset (99.5/100)
  - 1,645 GPS bodů s minimálními problémy
  - Pouze 4 body mimo perimeter na začátku trasy
  - 7 anomálních rychlostí (max 117.60 km/h)
  - Průměrná rychlost 4.24 km/h - realistická chůze

- **SSHR_DATA2**: Druhý nejkvalitnější dataset (99.5/100)
  - 1,410 GPS bodů
  - 5 bodů mimo perimeter (soustředěno kolem indexu 393-397)
  - 5 anomálních rychlostí (max 41.93 km/h)
  - Průměrná rychlost 4.14 km/h - realistická chůze

### ⚠️ **Problematické datasety** (Kvalita 50-70%)
- **SSHR_DATA3**: Střední kvalita (67.4/100)
  - Krátký dataset (192 bodů) s vysokým podílem anomálií
  - 13% bodů mimo perimeter
  - 26% anomálních rychlostí (max 216.10 km/h)
  - Průměrná rychlost 13.89 km/h - příliš vysoká

- **SSHR_DATA4, DATA6, DATA7**: Nízká kvalita (53-60/100)
  - Vysoký podíl anomálních rychlostí (55-73%)
  - Nerealistické maximální rychlosti (64-976 km/h)
  - Průměrné rychlosti 28-46 km/h - nerealistické pro chůzi

### ❌ **Kritický dataset** (Kvalita < 50%)
- **SSHR_DATA5**: Nejhorší kvalita (40.2/100)
  - 159 bodů s extrémními problémy
  - 40% bodů mimo perimeter
  - 79% anomálních rychlostí (max 7,572.44 km/h!)
  - Průměrná rychlost 125.63 km/h - zcela nerealistická

## 🔍 Detailní analýza problémů

### 1. **GPS body mimo RED FENCE perimeter**
- **Celkem:** 118 bodů (3.11% všech dat)
- **Nejproblematičtější:** SSHR_DATA5 (63 bodů, 39.62%)
- **Vzorec:** Většina problémů na okrajích perimetru nebo při přechodech

### 2. **Anomální rychlosti (> 20 km/h)**
- **Celkem:** 445 anomálií (11.72% všech přechodů)
- **Nejvyšší rychlost:** 7,572.44 km/h (SSHR_DATA5)
- **Časté rychlosti:** 40-50 km/h (nerealistické pro chůzi)

### 3. **Časová konzistence**
- ✅ **Všechny datasety**: Časová razítka v rostoucím pořadí
- ✅ **Formát**: Všechna razítka ve správném ISO formátu
- **Interval:** Konstantní 1-sekundové intervaly

## 📊 Statistické shrnutí

### Rychlosti pohybu
| Metrika | DATA1 | DATA2 | DATA3 | DATA4 | DATA5 | DATA6 | DATA7 |
|---------|-------|-------|-------|-------|-------|-------|-------|
| **Min** | 0.00  | 0.00  | 0.00  | 0.00  | 0.00  | 0.00  | 0.00  |
| **Max** | 117.60| 41.93 | 216.10| 976.07|7572.44| 170.82| 64.89 |
| **Avg** | 4.24  | 4.14  | 13.89 | 39.07 | 125.63| 46.23 | 28.61 |

### Perimeter compliance
- **DATA1, DATA2**: 99%+ bodů uvnitř perimetru ✅
- **DATA3, DATA4, DATA6**: 87-95% bodů uvnitř perimetru ⚠️
- **DATA5**: Pouze 60% bodů uvnitř perimetru ❌
- **DATA7**: 99% bodů uvnitř perimetru ✅

## 🛠️ Doporučení pro opravu

### **Priorita 1: SSHR_DATA5** (Kritická)
```
- 🚨 NUTNÁ kompletní revize datasetu
- Odstranění/oprava 63 bodů mimo perimeter
- Korekce 125 extrémních rychlostních anomálií
- Přegenerování s realistickými parametry pohybu
```

### **Priorita 2: SSHR_DATA4** (Vysoká)
```
- 📊 Filtrování anomálních rychlostí (122 anomálií)
- Korekce maximální rychlosti (976.07 km/h → realistická)
- Optimalizace průměrné rychlosti (39.07 → 3-6 km/h)
```

### **Priorita 3: DATA3, DATA6, DATA7** (Střední)
```
- 🔧 Vyhlazení rychlostních špiček
- Korekce perimeter compliance
- Optimalizace průměrných rychlostí
```

### **Priorita 4: DATA1, DATA2** (Nízká)
```
- ✅ Již vynikající kvalita
- Drobné vylepšení: korekce počátečních bodů mimo perimeter
- Kontrola několika málo anomálních rychlostí
```

## 🎯 Požadované parametry pro opravy

### **Realistické rychlosti**
- **Pomalá chůze:** 2-4 km/h
- **Normální chůze:** 4-6 km/h
- **Rychlá chůze:** 6-8 km/h
- **Maximum:** 15 km/h (krátkodobé běhání)

### **GPS přesnost**
- **Všechny body:** Uvnitř RED FENCE perimetru
- **Tolerance:** ±2 metry pro GPS drift
- **Vyhlazení:** Bez teleportací > 10 metrů/sekundu

### **Časová konzistence**
- ✅ **Aktuálně OK:** 1-sekundové intervaly
- ✅ **Aktuálně OK:** Rostoucí pořadí timestamps

## 📈 Závěr a celkové hodnocení

**Celková kvalita datasetů: 68.2/100** ⚠️ **Průměrná kvalita - doporučeny opravy**

### **Silné stránky:**
- Konzistentní časová struktura napříč všemi datasety
- DATA1 a DATA2 mají vynikající kvalitu
- Dobrá pokrytost testovacích scénářů

### **Hlavní problémy:**
- Vysoký podíl nerealistických rychlostí (11.72% anomálií)
- DATA5 vykazuje kritické problémy
- Několik datasetů s body mimo definovaný perimeter

### **Doporučené akce:**
1. **Okamžitě:** Oprava/regenerace SSHR_DATA5
2. **Do týdne:** Korekce DATA4, DATA6, DATA7
3. **Optimalizace:** Drobné úpravy DATA1, DATA2
4. **Validace:** Implementace runtime kontrol pro budoucí datasety

---

*Report vygenerován SSHR Dataset Analyzer v1.0*
*Pro detailní analýzu otevřete: analysis_report.html*