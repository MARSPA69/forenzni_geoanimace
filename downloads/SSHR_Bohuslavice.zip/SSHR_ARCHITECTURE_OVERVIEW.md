# SSHR Bohuslavice – Architecture & Process Map

_Datum: 2025‑11‑02_  
_Autor: Codex Agent_

---

## 1. Ústřední workflow (tl;dr)

| Fáze | Hlavní komponenty | Co se děje |
|------|-------------------|------------|
| **Start aplikace** | `index_SSHR.html` → `renderer_SSHR_Bohuslavice.js` | Vytvoří se Leaflet mapa, inicializuje se polygon manager (plotuje RED fence) a nastaví se widgety. |
| **Příprava dat** | Sidebar (Forenzní analýza) → `window.sshrDatasetCache` | Uživatelské dropdowny vybírají osoby / vozidla. Tlačítko „Načíst“ uloží seznam datasetů do cache, ale animace ještě neběží. |
| **Spuštění animace** | Controls widget → `parallel-engine.js` + `parallel-tracking.js` | RUN načte dataset(y) do ParallelEngine, který po tickách (1s) posílá pozice do PersonTrackeru a Incident engine. |
| **Zobrazení na mapě** | `renderer_SSHR_Bohuslavice.js` + Leaflet | PersonTracker přes renderer posouvá markery, aktualizuje widgety a spouští incidenty/efekty. |
| **Návštěvnické karty** | `SSHR_card_manager.js` + widget 2 | V průběhu animace mohou panely osob přijímat karty. Formulář (Osoba/OP nebo Kamion/SPZ) zapisuje vstup; EXIT ukládá log do localStorage. |
| **Stop & vyčištění** | Controls + Sidebar | STOP vyvolá EXIT pro aktivní karty, CLEAR resetuje dataset cache. Počítadla se aktualizují v rámci `updateSSHRWidgets()`. |

---

## 2. Data Flow – kdo posílá co komu

1. **Datasety osob/vozidel** (`SSHR_DATA*.js`) registruje `parallel-engine.js`. `ParallelEngine.step()` bere každý tick objekt `{lat,lng,timestamp}`, posílá jej do:
   - `PersonTracker.updatePersonPosition()` (viz `parallel-tracking.js`) – posun markerů.
   - `IncidentEngine.evaluatePosition()` – detekce vstupu do RED zóny, rychlostní incidenty apod.
   - `SSHRParallelUI.updatePanel()` – aktualizace mini-panelu (čas/Lat/Lng).

2. **PersonTracker → Renderer**  
   `updatePersonPosition()` volá `animateMarkerToPosition()` definované v rendereru, který přes Anime.js tweenuje Leaflet marker a aktualizuje popupy, historie i widgety (person count, incident list).

3. **IncidentEngine → UI / Card manager**  
   Při incidentu emituje `incident-start` event. `setupParallelControls()` v `index_SSHR.html` přepne status panelu na „INCIDENT“ a zavolá `SSHRCardManager.recordIncident(datasetName, detail)` – karta si tak loguje přestupky.

4. **Card manager → localStorage & widget 2**  
   `SSHR_card_manager.js` drží pole `cards[]` (SSHR001–SSHR010). Při přiřazení doplní metadata o návštěvníkovi, při EXIT uloží JSON záznam do `SSHR_visitLog_YYYY-MM-DD`. Widget 2 v `index_SSHR.html` zobrazuje stav a card manager rendererem grid aktualizuje.

5. **Polygon manager**  
   `polygon-manager.js` načte data z `ZONES_SSHR.js`. `loadPerimeterFence()` okamžitě vykreslí RED fence (polyline) na mapu; ostatní zóny se renderují až přes „Animační vrstvy“. Incident engine využívá polygon manager API (`isPointInZone`, `checkSSHRZoneViolation`).

---

## 3. Přehled souborů a jejich role

### 3.1 Prezentace & UI

| Soubor | Popis |
|--------|-------|
| **index_SSHR.html** | Hlavní HTML skelet (sidebar, widgety, map container). Obsahuje inline CSS pro widget 2 (`.visitor-card`) a orchestraci UI (`renderForensicDropdowns`, `setupParallelControls`, DOM obsah forenzních dropdownů). |
| **sshr_styles.css** | Doplňkové styly (sidebar panely, widgety, legendy). Pozor: styl pro `.visitor-card` je intentionally prázdný – řídíme ho z HTML kvůli widgetům. |
| **renderer_SSHR_Bohuslavice.js** | Centrální renderer i „lepidlo“ mezi mapou a logikou. Řídí inicializaci (mapa, polygon manager, card manager, incident engine) a drží globální map-state (`window.sshrPersons`, `window.sshrLayers`). Také zajišťuje fallback API (`window.SSHR.*`). |

### 3.2 Animace a data

| Soubor | Popis |
|--------|-------|
| **parallel-engine.js** | Engine pro paralelní dataset playback. Registruje dataset jména (`SSHR_DATA#`), vytváří tracky, tickuje pozice, emituje events (`session-start`, `tracks-finished`). |
| **parallel-tracking.js** | PersonTracker – stav každé osoby (pozice, rychlost, statistiky). Volá anime.js animace (pohyby), loguje incidenty, udržuje historie pro widgety. |
| **incident-engine.js** | Most mezi polygon managerem a incident systémem. Hodnotí pozice (z `ParallelEngine` nebo PersonTracker) a posílá eventy do UI a incident systému. |
| **incident-system.js** | UI a storage incidentů (notifikace, widget 1). |
| **SSHR_DATA1.js … SSHR_DATA16.js** | Vzorky pohybů osob (16 datasetů pro 4 dny). |

### 3.3 Návštěvnické karty

| Soubor | Popis |
|--------|-------|
| **SSHR_card_manager.js** | Nový modul; spravuje pool `SSHR001–SSHR010`, drag/drop na paralelní panel (`registerDropZone`), formulář pro „Osoba“ (OP) / „Kamion“ (SPZ), eviduje incidenty a zapisuje logy (`SSHR_visitLog_*`). |
| **visitor-cards.js** | Starší helper (grid karet, drag&drop) – používaný v jiných projektech; v SSHR kód zůstává kvůli kompatibilitě, ale init přebírá `SSHR_card_manager.js`. |
| **SSHR_VISITOR_CARDS_DEBUG_LOG.md** | Historie zásahů do widgetu 2 – dobré čtení při budoucích úpravách. |

### 3.4 Zóny & polygon management

| Soubor | Popis |
|--------|-------|
| **polygon-manager.js** | Třída `SSHRPolygonManager` (FIXED/FLOAT módy, Leaflet.draw integrace). `loadPerimeterFence()` kreslí RED fence. API se exponuje přes `window.SSHR.zones`. |
| **ZONES_SSHR.js** | Zdrojová data (fence coords, green/red polygony). |

### 3.5 Konfigurace + data vstupů

| Soubor | Popis |
|--------|-------|
| **CONFIG_SSHR.js** | Konfigurace mapy (center/zoom), limity (maxCards, update interval). |
| **ANCHOR_SSHR.js** | Pozice kotev (Leaflet marker layer). |

### 3.6 Dokumentace & testy

| Soubor | Popis |
|--------|-------|
| **SSHR.md** | Projektový deník (release notes, debug zápisy – viz sekce k widgetu 2). |
| **DEBUG_LOG_02112025.md**, **SSHR_VISITOR_CARDS_DEBUG_LOG.md** | Detailní logy konkrétních změn. |
| **test-integration.js** | Browser integrační testy: kontrola dostupnosti modulů, PersonTracker, card manageru a incident systému. |
| **PHASE2_COMPLETION_SUMMARY.md**, **PHASE3_POLYGON_COMPLETION.md**, **REALTIME_VALIDATION_PLAN.md** | Reporty z předchozích fází projektu. |

---

## 4. Životní cyklus komponent

### 4.1 Inicializace (`initSSHRRenderer`)
1. `initSSHRMap()` → Leaflet map + base tiles.
2. `SSHRCardManager.init()` – připraví pool karet.
3. `initSSHRPolygonManager(map)` → `loadPerimeterFence()`.
4. `SSHRParallel.initialise()` – propojí PersonTracker atd.
5. Incident engine se inicializuje s polygon managerem.
6. `updateSSHRWidgets()` se spouští každou sekundu (počet osob, incidenty).

### 4.2 Sidebar – Forenzní analýza
1. `FORENSIC_DATASET_MAP` definuje 4 dny × 4 dataset IDs.
2. `renderForensicDropdowns()` generuje dropdown pro každý den (počítá dostupné vs. vybrané datové sady).
3. `setLoadingState()` aktivuje tlačítka Načíst/Vyčistit.
4. Načtené dataset ID se ukládají do `window.sshrDatasetCache`, animace se nespouští.

### 4.3 Controls widget (RUN/PAUSE/STOP)
1. RUN → `SSHRParallel.startSession(cache.datasets, {mode})`.
2. PAUSE → `SSHRParallel.pauseSession()`.
3. STOP → `SSHRParallel.stopSession({ reason: 'manual' })` a `SSHRCardManager.promptExitForDataset()` nabídne EXIT pro aktivní karty.

### 4.4 Návštěvnické karty
1. `SSHRCardManager` registruje drop zóny (`registerDropZone`) pro každý panel.
2. Drag karty na panel otevře modální formulář (Osoba / Kamion).
3. Potvrzením se karta označí `assigned`, počet volných karet (pool-counter) se sníží.
4. `recordIncident(datasetName)` ukládá průběžně incidenty k dané kartě.
5. EXIT → uloží návštěvu do localStorage a vrátí kartu do poolu.

---

## 5. Závislosti a signály

### 5.1 Globální objekty
- `window.leafletMap` – Leaflet instance pro mapu.
- `window.SSHR` – centrální API (map, persons, cards, zones, incidents).
- `window.SSHRParallel` – parallel engine singleton.
- `window.SSHRCardManager` – card manager (nový systém).
- `window.sshrDatasetCache` – buffer pro volbu datasetů ze sidebaru.
- `window.sshrPersons`, `window.sshrLayers` – interní mapy s lidmi a Leaflet vrstvami.

### 5.2 Eventy
- `session-start`, `session-stop`, `tracks-finished`, `speed-change` (ParallelEngine).
- `incident-start`, `incident-resolve` (IncidentEngine → `setupParallelControls`).
- `sshr-zone-added`, `sshr-zone-deleted`, `sshr-mode-changed` (Polygon manager).
- `beforeunload` (card manager varuje, pokud jsou přiřazené karty).

---

## 6. Rizika & doporučení

1. **Duální card systém** – `visitor-cards.js` vs. `SSHR_card_manager.js`. Aktuálně se používá nový manager, starý modul ponechán kvůli historii. Při dalších úpravách zajistit, že staré hooky (`window.sshrCards`, `renderCardPool`) nejsou volány (v rendereru stále existují helpery z původního systému).
2. **Inline CSS v HTML** – widget 2 má styl přímo v `index_SSHR.html` kvůli přesnému layoutu. Při úpravách stylů dávat pozor na duplicitní deklarace v `sshr_styles.css`.
3. **Perimeter fence** – je potřeba vždy zkontrolovat, že `initSSHRPolygonManager` vrací instanci a `loadPerimeterFence()` se volá po inicializaci. Pokud polygon manager vyhodí chybu, fence se neukáže.
4. **Sidebar generování** – změny v `FORENSIC_DATASET_MAP` se musí propsat i do `renderForensicDropdowns()`. Kontrola, zda `window.realData_SSHR_DATA#` existuje, jinak dropdown ukáže, že dataset není k dispozici.
5. **Incident logging** – `SSHRCardManager.recordIncident()` očekává `datasetName` shodné se jménem tracku (např. `SSHR_DATA3`). Pokud se změní naming, incidenty se nepřipíšou kartám.

---

## 7. Check-list pro budoucí zásahy

1. **Widget 2 / karty**
   - Uprav pouze CSS v `index_SSHR.html`, ne v `sshr_styles.css`.
   - Pokud se mění počet karet, aktualizuj `SSHR_card_manager.js` (`initialCardCount` a logiku generování ID).

2. **Sidebar / datasets**
   - Zachovej `FORENSIC_DATASET_MAP`.
   - Po přidání dataset souboru (`SSHR_DATA17`) aktualizuj mapu a ověř, že `parallel-engine.js` registruje nové soubory.

3. **Polygony / fence**
   - Při úpravách `ZONES_SSHR.js` dodrž pořadí souřadnic (clockwise) a uzavření polygonu.
   - `polygon-manager.js` má metody `addFenceLine` a `loadDefaultZones`; nesahej na `loadPerimeterFence()` bez prostudování incident enginu.

4. **Mapa & renderer**
   - Jakákoliv změna v `renderer_SSHR_Bohuslavice.js` ovlivňuje init, widgety i debug API. Kontroluj výpis `console.log("✅ [SSHR-INIT] ...")` v prohlížeči.

5. **Incidenty**
   - UX (widget 1) je v `incident-system.js`. API očekává, že incident engine posílá `incident-start`/`incident-resolve`.
   - Pokud přibude nový typ incidentu, rozšiř `IncidentManager` a `SSHRCardManager.recordIncident`.

---

## 8. Doporučený onboarding (pro nové agenty)

1. Otevři `SSHR.md` – přehled posledních zásahů (zejména widget 2).
2. Prostuduj `index_SSHR.html` (inline skript) – obsahuje prakticky celou UI logiku mimo rendereru.
3. Podívej se na `parallel-engine.js` + `parallel-tracking.js` – pochopíš animační pipeline.
4. Zkontroluj `SSHR_card_manager.js` – proces karty (init → assign → incident → exit).
5. Najdi si v `polygon-manager.js` funkci `loadPerimeterFence()` – pochopíš, jak se vykresluje RED line a jak se pracuje s Leafletem.
6. Pusť `test-integration.js` v prohlížeči (console `IntegrationTest.runAllTests()`) – ověří základní funkčnost.

---

### Otázky / TODO
- [ ] Rozhodnout, zda starý `visitor-cards.js` ponechat jen pro referenci, nebo ho odstranit a nahradit importy na nový manager.
- [ ] Dopsat API dokumentaci pro `window.SSHR` (aktuálně implicitní).
- [ ] Přidat guardy do `SSHR_card_manager.js`, aby si při initu nevytvářel karty dvakrát (pokud bude reload skriptu bez refresh).
- [ ] Revize incidence pipeline (sjednotit logování do jednoho úložiště).

---

> _Tento dokument udržuj aktuální při každé větší úpravě (animace, karty, polygon manager). Slouží jako rychlá orientace pro všechny agenty i návazné týmy._ 
