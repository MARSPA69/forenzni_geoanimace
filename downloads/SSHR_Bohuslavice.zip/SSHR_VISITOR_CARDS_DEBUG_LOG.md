# SSHR Visitor Cards - Kompletní Debug a Oprava Systému

## 📅 Datum: 2. listopadu 2025
## 🎯 Problém: Návštěvnické kartičky se zobrazí na okamžik, ale pak zmizí

---

## 🔍 **Analýza problému**

### **Původní symptomy:**
- ✅ Kartičky se na sekundu ukázaly ve widgetu č.2
- ❌ Poté zmizely a zůstal jen text "10/10 k dispozici"
- ❌ Widget byl prázdný bez kartiček

### **Root Cause Analysis:**
1. **Chybějící funkce `createDiv`** v `SSHR_card_manager.js`
2. **Konfliktní systémy správy kartiček** - starý vs. nový
3. **Přepisování obsahu** pomocí `renderCardPool()` funkcí

---

## 🛠️ **Provedené opravy**

### **1. Přidání chybějící funkce `createDiv`**
**Soubor:** `SSHR_card_manager.js` (řádky 34-40)
```javascript
function createDiv(className) {
  var div = document.createElement('div');
  if (className) {
    div.className = className;
  }
  return div;
}
```
**Důvod:** Funkce `renderPool()` volala nedefinovanou `createDiv()`, což způsobovalo JavaScript chybu.

### **2. Oprava HTML struktury**
**Soubor:** `index_SSHR.html` (řádky 670-684)
```html
<div id="visitor-card-pool-box">
  <div class="pool-counter text-muted" style="font-size: 0.7rem;">0/0 k dispozici</div>
  <div id="visitor-card-pool">
    <!-- Dynamické kartičky -->
  </div>
</div>
```
**Důvod:** `SSHRCardManager` očekává `#visitor-card-pool-box` element pro `updatePoolCounter()`.

### **3. Oprava počtu kartiček**
**Soubor:** `index_SSHR.html` (řádek 1183)
```javascript
window.SSHRCardManager.init({
  initialCardCount: 10  // Změna z 12 na 10
});
```

### **4. Zakázání konfliktních funkcí**
**Soubor:** `renderer_SSHR_Bohuslavice.js`

#### **4.1 Zakázání `updateVisitorCardWidget()`** (řádky 1807-1810)
```javascript
function updateVisitorCardWidget() {
  // DISABLED: Conflicts with SSHRCardManager
  // renderCardPool();
}
```

#### **4.2 Odstranění z `updateSSHRWidgets()`** (řádek 1773)
```javascript
function updateSSHRWidgets() {
  updatePersonCountWidget(window.sshrPersons.size);
  updateIncidentCountWidget(getActiveIncidents().length);
  updateAnchorStatusWidget('online');
  // updateVisitorCardWidget(); // DISABLED: Conflicts with SSHRCardManager
  updateSystemStatus();
}
```

#### **4.3 Zakázání všech `renderCardPool()` volání:**
- `assignCard()` - řádek 1533
- `unassignCard()` - řádek 1559
- `updateCardStatus()` - řádek 1578
- `refreshCardPool()` - řádek 1916

```javascript
// renderCardPool(); // DISABLED: Using SSHRCardManager instead
```

---

## 🎯 **Systémové změny**

### **Starý systém (zakázáno):**
- `initSSHRVisitorCards()` - zakomentováno
- `renderCardPool()` - všechna volání zakázána
- `window.sshrCards` - používán starým systémem
- `updateVisitorCardWidget()` - vypnuto

### **Nový systém (aktivní):**
- `SSHRCardManager.init()` - hlavní inicializace
- `createDefaultCards()` - generuje SSHR001-SSHR010
- `renderPool()` - zobrazuje kartičky s CSS
- `updatePoolCounter()` - zobrazuje "X/10 k dispozici"

---

## 📊 **Výsledný stav**

### **✅ Funkční systém:**
```
Widget č.2: Návštěvnické karty
├── Pool Counter: "10/10 k dispozici"
├── Card Pool: 10 kartiček (SSHR001-SSHR010)
├── CSS Styling: Cyan text, white background
├── Grid Layout: 5×2 uspořádání
└── Drag & Drop: Funkční pro přiřazení
```

### **🔧 Technické specifikace:**
- **Manager:** `SSHRCardManager` (hlavní systém)
- **Kartičky:** 10ks (SSHR001-SSHR010)
- **CSS:** Sjednocené definice v `index_SSHR.html`
- **Layout:** 5 sloupců × 2 řady
- **Konflikty:** Všechny odstraněny

---

## 🧪 **Testovací výsledky**

### **Před opravou:**
❌ Kartičky se zobrazí na okamžik, pak zmizí
❌ Pool counter: "0/0 k dispozici"
❌ JavaScript chyby v konzoli

### **Po opravě:**
✅ Kartičky trvale viditelné
✅ Pool counter: "10/10 k dispozici"
✅ Bez JavaScript chyb
✅ Drag & drop funkční

---

## 📋 **Souhrn všech úprav**

| Soubor | Řádky | Akce | Popis |
|--------|-------|------|--------|
| `SSHR_card_manager.js` | 34-40 | Přidáno | Funkce `createDiv()` |
| `index_SSHR.html` | 670-684 | Upraveno | HTML struktura `#visitor-card-pool-box` |
| `index_SSHR.html` | 1183 | Upraveno | `initialCardCount: 10` |
| `renderer_SSHR_Bohuslavice.js` | 1773 | Zakomentováno | `updateVisitorCardWidget()` volání |
| `renderer_SSHR_Bohuslavice.js` | 1807-1810 | Zakomentováno | `updateVisitorCardWidget()` funkce |
| `renderer_SSHR_Bohuslavice.js` | 1533,1559,1578,1916 | Zakomentováno | Všechna `renderCardPool()` volání |

---

## 🎉 **Závěr**

**Problém s mizejícími kartičkami byl úspěšně vyřešen!**

Hlavní příčina byla **konflik mezi dvěma systémy správy kartiček:**
1. **Starý systém** (`renderCardPool()`, `window.sshrCards`)
2. **Nový systém** (`SSHRCardManager`)

Po zakázání starého systému a opravě technických problémů (chybějící `createDiv()`) je **Widget č.2 plně funkční** s trvalým zobrazením 10 návštěvnických kartiček.

**🎯 Status: VYŘEŠENO ✅**

---
## 📌 **Poznámky pro budoucnost**

- Při přidávání nových funkcí do visitor card systému používat pouze `SSHRCardManager`
- Starý systém ponechat zakomentovaný pro případnou referenci
- CSS definice udržovat centralizované v `index_SSHR.html`
- Testovat drag & drop funkcionalita při změnách