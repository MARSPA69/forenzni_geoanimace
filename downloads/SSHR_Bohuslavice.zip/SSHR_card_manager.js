/**
 * SSHR Card Manager
 * -----------------
 * Samostatná správa návštěvnických karet pro SSHR Bohuslavice.
 * Zaměření: pouze UI pool, přiřazení na panely Parallel módu,
 * formuláře pro vstup/exit a incident tracking.
 */
(function() {
  'use strict';

  var CARD_STATUS = {
    FREE: 'free',
    ASSIGNED: 'assigned'
  };

  var CARD_TYPES = {
    PERSON: 'person',
    TRUCK: 'truck'
  };

  var STORAGE_PREFIX = 'SSHR_visitLog_';

  function pad2(value) {
    return String(value).padStart(2, '0');
  }

  function formatTime(date) {
    if (!date) {
      date = new Date();
    }
    return pad2(date.getHours()) + ':' + pad2(date.getMinutes()) + ':' + pad2(date.getSeconds());
  }

  function createDiv(className) {
    var div = document.createElement('div');
    if (className) {
      div.className = className;
    }
    return div;
  }

  function createModalMarkup() {
    return '' +
      '<div id="sshr-card-assignment-modal" class="sshr-card-modal">' +
        '<div class="sshr-card-modal__backdrop"></div>' +
        '<div class="sshr-card-modal__dialog">' +
          '<h5>Přiřazení návštěvnické karty</h5>' +
          '<form id="sshr-card-assignment-form" novalidate>' +
            '<div class="mb-2">' +
              '<label class="form-label">Karta</label>' +
              '<input type="text" id="assignment-card-id" class="form-control form-control-sm" readonly>' +
            '</div>' +
            '<div class="mb-2">' +
              '<label class="form-label">Dataset</label>' +
              '<input type="text" id="assignment-dataset" class="form-control form-control-sm" readonly>' +
            '</div>' +
            '<div class="mb-2">' +
              '<label class="form-label" for="assignment-type">Typ návštěvy</label>' +
              '<select id="assignment-type" class="form-select form-select-sm" required>' +
                '<option value="person">Osoba</option>' +
                '<option value="truck">Kamion</option>' +
              '</select>' +
            '</div>' +
            '<div id="assignment-person-fields">' +
              '<div class="row g-2">' +
                '<div class="col-6">' +
                  '<label class="form-label" for="assignment-first-name">Jméno</label>' +
                  '<input type="text" class="form-control form-control-sm" id="assignment-first-name" autocomplete="off" required>' +
                '</div>' +
                '<div class="col-6">' +
                  '<label class="form-label" for="assignment-last-name">Příjmení</label>' +
                  '<input type="text" class="form-control form-control-sm" id="assignment-last-name" autocomplete="off" required>' +
                '</div>' +
              '</div>' +
              '<div class="mt-2">' +
                '<label class="form-label" for="assignment-op-number">Číslo OP (9 číslic)</label>' +
                '<input type="text" class="form-control form-control-sm" id="assignment-op-number" maxlength="9" autocomplete="off" required>' +
              '</div>' +
            '</div>' +
            '<div id="assignment-truck-fields" class="d-none">' +
              '<div class="mb-2">' +
                '<label class="form-label" for="assignment-driver-name">Jméno řidiče</label>' +
                '<input type="text" class="form-control form-control-sm" id="assignment-driver-name" autocomplete="off">' +
              '</div>' +
              '<div class="mb-2">' +
                '<label class="form-label" for="assignment-plate">SPZ</label>' +
                '<input type="text" class="form-control form-control-sm text-uppercase" id="assignment-plate" autocomplete="off">' +
              '</div>' +
            '</div>' +
            '<div class="mb-2">' +
              '<label class="form-label" for="assignment-recorded-by">Zapsal</label>' +
              '<input type="text" class="form-control form-control-sm" id="assignment-recorded-by" autocomplete="off" required>' +
            '</div>' +
            '<div class="mb-2">' +
              '<label class="form-label" for="assignment-entry-time">Čas vstupu</label>' +
              '<input type="text" class="form-control form-control-sm" id="assignment-entry-time" readonly>' +
            '</div>' +
            '<div class="sshr-card-modal__actions mt-3">' +
              '<button type="button" class="btn btn-outline-light btn-sm" id="assignment-cancel-btn">Zrušit</button>' +
              '<button type="submit" class="btn btn-success btn-sm">Potvrdit</button>' +
            '</div>' +
          '</form>' +
        '</div>' +
      '</div>' +
      '<div id="sshr-card-exit-modal" class="sshr-card-modal">' +
        '<div class="sshr-card-modal__backdrop"></div>' +
        '<div class="sshr-card-modal__dialog">' +
          '<h5>Ukončení návštěvy</h5>' +
          '<form id="sshr-card-exit-form" novalidate>' +
            '<div class="mb-2">' +
              '<label class="form-label" for="exit-card-id">Karta</label>' +
              '<input type="text" class="form-control form-control-sm" id="exit-card-id" readonly>' +
            '</div>' +
            '<div class="mb-2">' +
              '<label class="form-label" for="exit-card-label">Návštěvní informace</label>' +
              '<input type="text" class="form-control form-control-sm" id="exit-card-label" readonly>' +
            '</div>' +
            '<div class="mb-2">' +
              '<label class="form-label" for="exit-entry-time">Čas vstupu</label>' +
              '<input type="text" class="form-control form-control-sm" id="exit-entry-time" readonly>' +
            '</div>' +
            '<div class="mb-2">' +
              '<label class="form-label" for="exit-exit-time">Čas výstupu (HH:MM:SS)</label>' +
              '<input type="text" class="form-control form-control-sm" id="exit-exit-time" autocomplete="off" required>' +
            '</div>' +
            '<div class="mb-2">' +
              '<span class="badge bg-warning text-dark" id="exit-incident-info">0 incidentů</span>' +
            '</div>' +
            '<div class="sshr-card-modal__actions mt-3">' +
              '<button type="button" class="btn btn-outline-light btn-sm" id="exit-cancel-btn">Zrušit</button>' +
              '<button type="submit" class="btn btn-danger btn-sm">Ukončit</button>' +
            '</div>' +
          '</form>' +
        '</div>' +
      '</div>';
  }

  var manager = {
    initialized: false,
    cards: [],
    cardMap: null,
    panelCardMap: null,
    options: null,
    poolElement: null,
    poolBoxElement: null,
    dropZones: null,
    assignmentContext: null,
    exitContext: null,

    init: function(options) {
      if (this.initialized) {
        return;
      }

      var defaults = {
        poolSelector: '#visitor-card-pool',
        poolBoxSelector: '#visitor-card-pool-box',
        initialCardCount: 10
      };

      this.options = Object.assign({}, defaults, options || {});
      this.poolElement = document.querySelector(this.options.poolSelector);
      this.poolBoxElement = document.querySelector(this.options.poolBoxSelector);

      if (!this.poolElement) {
        console.warn('🟡 [SSHR-CARD] Pool element not found, skipping init.');
        return;
      }

      this.cardMap = new Map();
      this.dropZones = new Map();
      this.panelCardMap = new Map();
      this.cards = [];

      if (!document.getElementById('sshr-card-assignment-modal')) {
        document.body.insertAdjacentHTML('beforeend', createModalMarkup());
      }

      this.cacheModalElements();
      this.bindModalHandlers();
      this.setupIncidentListeners(); // Nová funkce pro propojení s IncidentEngine
      this.createDefaultCards(this.options.initialCardCount);
      this.renderPool();
      this.setupPoolDropZone();

      this.initialized = true;
      console.log('🎴 [SSHR-CARD] Initialised (' + this.cards.length + ' cards).');
    },

    cacheModalElements: function() {
      this.assignmentModal = document.getElementById('sshr-card-assignment-modal');
      this.assignmentForm = document.getElementById('sshr-card-assignment-form');
      this.assignmentTypeSelect = document.getElementById('assignment-type');
      this.assignmentCancelBtn = document.getElementById('assignment-cancel-btn');

      this.exitModal = document.getElementById('sshr-card-exit-modal');
      this.exitForm = document.getElementById('sshr-card-exit-form');
      this.exitCancelBtn = document.getElementById('exit-cancel-btn');
    },

    createDefaultCards: function(count) {
      for (var i = 1; i <= count; i++) {
        var cardId = 'SSHR' + String(i).padStart(3, '0');
        var card = {
          id: cardId,
          baseId: cardId,
          displayId: cardId,
          status: CARD_STATUS.FREE,
          type: null,
          datasetName: null,
          panelId: null,
          entryTime: null,
          exitTime: null,
          recordedBy: null,
          person: null,
          truck: null,
          incidents: []
        };

        this.cards.push(card);
        this.cardMap.set(cardId, card);
      }
    },

    renderPool: function() {
      var _this = this;
      this.poolElement.innerHTML = '';
      this.cards.forEach(function(card) {
        var cardEl = createDiv('visitor-card' + (card.status === CARD_STATUS.ASSIGNED ? ' visitor-card-disabled' : ''));
        cardEl.dataset.cardId = card.id;
        cardEl.innerHTML =
          '<div class="visitor-card-id">' + card.displayId + '</div>' +
          '<div class="visitor-card-info">' + (card.status === CARD_STATUS.FREE ? 'K dispozici' : 'Obsazeno') + '</div>';

        if (card.status === CARD_STATUS.FREE) {
          cardEl.setAttribute('draggable', 'true');
          cardEl.addEventListener('dragstart', function(evt) {
            _this.handlePoolDragStart(evt, card);
          });
          cardEl.addEventListener('dragend', function() {
            cardEl.classList.remove('dragging');
          });
        }

        _this.poolElement.appendChild(cardEl);
      });

      this.updatePoolCounter();
    },

    handlePoolDragStart: function(event, card) {
      event.dataTransfer.effectAllowed = 'move';
      event.dataTransfer.setData('application/json', JSON.stringify({
        cardId: card.id,
        source: 'pool'
      }));
      event.currentTarget.classList.add('dragging');
    },

    setupPoolDropZone: function() {
      var _this = this;
      this.poolElement.addEventListener('dragover', function(event) {
        if (!event.dataTransfer) return;
        event.preventDefault();
        _this.poolElement.classList.add('card-pool-active');
      });
      this.poolElement.addEventListener('dragleave', function() {
        _this.poolElement.classList.remove('card-pool-active');
      });
      this.poolElement.addEventListener('drop', function(event) {
        event.preventDefault();
        _this.poolElement.classList.remove('card-pool-active');

        var payload = null;
        try {
          payload = JSON.parse(event.dataTransfer.getData('application/json') || '{}');
        } catch (_) {
          payload = null;
        }

        if (!payload || !payload.cardId) {
          return;
        }

        var card = _this.getCard(payload.cardId);
        if (!card || card.status !== CARD_STATUS.ASSIGNED) {
          return;
        }

        var dropZone = _this.dropZones.get(card.panelId);
        if (dropZone) {
          _this.resetDropZone(dropZone);
        }

        _this.resetCard(card, true);
        _this.renderPool();
      });
    },

    updatePoolCounter: function() {
      if (!this.poolBoxElement) return;
      var total = this.cards.length;
      var assigned = this.cards.filter(function(card) { return card.status === CARD_STATUS.ASSIGNED; }).length;
      var indicator = this.poolBoxElement.querySelector('.pool-counter');
      if (indicator) {
        indicator.textContent = (total - assigned) + '/' + total + ' k dispozici';
      }
    },

    registerDropZone: function(panelElement, trackMeta) {
      if (!panelElement) {
        return;
      }
      var dropZone = panelElement.querySelector('.card-drop-zone');
      if (!dropZone) {
        return;
      }

      var panelId = trackMeta && (trackMeta.panelId || trackMeta.id || trackMeta.name) ? (trackMeta.panelId || trackMeta.id || trackMeta.name) : ('panel-' + Date.now());
      console.log('🔧 [CARD-MANAGER] registerDropZone - panelId:', panelId, 'trackMeta:', trackMeta);
      dropZone.dataset.panelId = panelId;
      dropZone.dataset.datasetName = trackMeta ? trackMeta.name : '';
      dropZone.classList.remove('has-card', 'drag-over');
      dropZone.innerHTML = '<div class="drop-zone-placeholder">Přetáhněte kartu ze zásobníku</div>';

      if (dropZone._sshrHandlers) {
        dropZone.removeEventListener('dragover', dropZone._sshrHandlers.dragover);
        dropZone.removeEventListener('dragleave', dropZone._sshrHandlers.dragleave);
        dropZone.removeEventListener('drop', dropZone._sshrHandlers.drop);
      }

      var _this = this;
      var dragover = function(event) {
        if (!event.dataTransfer) return;
        event.preventDefault();
        dropZone.classList.add('drag-over');
      };
      var dragleave = function() {
        dropZone.classList.remove('drag-over');
      };
      var drop = function(event) {
        event.preventDefault();
        dropZone.classList.remove('drag-over');

        var readiness = _this.checkParallelAssignmentReadiness(panelId);
        if (!readiness.ok) {
          _this.notifyDropError(readiness.message);
          return;
        }

        var payload = null;
        try {
          payload = JSON.parse(event.dataTransfer.getData('application/json') || '{}');
        } catch (_) {
          payload = null;
        }

        if (!payload || !payload.cardId) {
          return;
        }

        var card = _this.getCard(payload.cardId);
        if (!card) {
          console.error('❌ [SSHR-CARD] Card not found:', payload.cardId);
          return;
        }

        if (card.status === CARD_STATUS.ASSIGNED) {
          _this.notifyDropError('Tato karta je již přiřazená. Nejprve ji vraťte do zásobníku.');
          return;
        }

        console.log('🔧 [CARD-MANAGER] Setting assignmentContext - panelId:', panelId);
        _this.assignmentContext = {
          card: card,
          dropZone: dropZone,
          panelId: panelId,
          datasetName: dropZone.dataset.datasetName || null
        };

        _this.openAssignmentModal();
      };

      dropZone.addEventListener('dragover', dragover);
      dropZone.addEventListener('dragleave', dragleave);
      dropZone.addEventListener('drop', drop);
      dropZone._sshrHandlers = { dragover: dragover, dragleave: dragleave, drop: drop };

      this.dropZones.set(panelId, dropZone);
    },

    checkParallelAssignmentReadiness: function(panelId) {
      if (!this.initialized) {
        return { ok: false, message: 'Zásobník návštěvnických karet není inicializovaný.' };
      }

      const engine = window.SSHRParallel || null;
      if (!engine) {
        return { ok: false, message: 'Parallel engine není připraven. Klikni na START v panelu Tracking.' };
      }

      let activeTracks = [];
      if (typeof engine.getActiveTracks === 'function') {
        activeTracks = engine.getActiveTracks() || [];
      } else if (engine.tracks instanceof Map) {
        activeTracks = Array.from(engine.tracks.values());
      }

      if (!activeTracks.length) {
        return { ok: false, message: 'Nejprve spusť animaci tlačítkem START, aby se vytvořily panely OSOBA.' };
      }

      const animationRunning =
        (typeof engine.isActive === 'function' && engine.isActive()) ||
        Boolean(typeof window.sshrAnimationActive !== 'undefined' ? window.sshrAnimationActive : false);

      if (animationRunning) {
        return { ok: false, message: 'Animace stále běží. Klikni na PAUSE, aby markery stály u vrátnice, a pak kartu přiřaď.' };
      }

      if (!panelId) {
        return { ok: false, message: 'Panel není připraven. Počkej, až se zobrazí informační panel OSOBA.' };
      }

      return { ok: true };
    },

    notifyDropError: function(message) {
      if (window.toastr && typeof window.toastr.error === 'function') {
        window.toastr.error(message, 'Návštěvnické karty', { timeOut: 6000, closeButton: true });
      } else if (window.SSHR && window.SSHR.toast && typeof window.SSHR.toast.error === 'function') {
        window.SSHR.toast.error(message);
      } else {
        alert(message);
      }
    },

    openAssignmentModal: function() {
      if (!this.assignmentContext) return;

      var card = this.assignmentContext.card;
      var datasetName = this.assignmentContext.datasetName || '—';

      document.getElementById('assignment-card-id').value = card.displayId;
      document.getElementById('assignment-dataset').value = datasetName;
      document.getElementById('assignment-entry-time').value = formatTime(new Date());
      document.getElementById('assignment-first-name').value = '';
      document.getElementById('assignment-last-name').value = '';
      document.getElementById('assignment-op-number').value = '';
      document.getElementById('assignment-driver-name').value = '';
      document.getElementById('assignment-plate').value = '';
      document.getElementById('assignment-recorded-by').value = '';

      this.assignmentTypeSelect.value = /SSHR_VEHICLE/i.test(datasetName) ? CARD_TYPES.TRUCK : CARD_TYPES.PERSON;
      this.toggleAssignmentType();

      this.assignmentModal.classList.add('is-active');
    },

    closeAssignmentModal: function(cancelled) {
      if (this.assignmentModal) {
        this.assignmentModal.classList.remove('is-active');
      }
      if (cancelled && this.assignmentContext) {
        this.resetDropZone(this.assignmentContext.dropZone);
        this.assignmentContext = null;
      }
    },

    toggleAssignmentType: function() {
      var type = this.assignmentTypeSelect.value;
      var personFields = document.getElementById('assignment-person-fields');
      var truckFields = document.getElementById('assignment-truck-fields');
      if (type === CARD_TYPES.PERSON) {
        personFields.classList.remove('d-none');
        truckFields.classList.add('d-none');
      } else {
        personFields.classList.add('d-none');
        truckFields.classList.remove('d-none');
      }
    },

    // Validace duplicitních dat před přiřazením
    validateDuplicates: function(type, data) {
      var errors = [];
      var _this = this;

      this.cards.forEach(function(card) {
        if (card.status === CARD_STATUS.ASSIGNED) {
          if (type === CARD_TYPES.PERSON && card.type === CARD_TYPES.PERSON && card.person) {
            var existing = card.person;

            // Unikátní č. OP (vždy musí být unikátní)
            if (data.opNumber && existing.opNumber === data.opNumber) {
              errors.push('Duplicitní č. OP: ' + data.opNumber + ' (už používá ' + existing.firstName + ' ' + existing.lastName + ')');
            }

            // Varianta: Stejné jméno = musí mít jiné č. OP
            if (data.firstName === existing.firstName && data.lastName === existing.lastName) {
              if (data.opNumber === existing.opNumber) {
                errors.push('Duplicitní osoba: ' + data.firstName + ' ' + data.lastName + ' s č. OP ' + data.opNumber);
              }
            }
          } else if (type === CARD_TYPES.TRUCK && card.type === CARD_TYPES.TRUCK && card.truck) {
            var existingTruck = card.truck;

            // Unikátní SPZ
            if (data.plate && existingTruck.plate === data.plate) {
              errors.push('Duplicitní SPZ: ' + data.plate + ' (už používá ' + existingTruck.driverName + ')');
            }
          }
        }
      });

      return errors;
    },

    bindModalHandlers: function() {
      var _this = this;
      this.assignmentTypeSelect.addEventListener('change', function() {
        _this.toggleAssignmentType();
      });
      this.assignmentCancelBtn.addEventListener('click', function() {
        _this.closeAssignmentModal(true);
      });
      this.assignmentForm.addEventListener('submit', function(event) {
        _this.handleAssignmentSubmit(event);
      });
      this.assignmentModal.querySelector('.sshr-card-modal__backdrop')
        .addEventListener('click', function() {
          _this.closeAssignmentModal(true);
        });

      this.exitCancelBtn.addEventListener('click', function() {
        _this.closeExitModal();
      });
      this.exitForm.addEventListener('submit', function(event) {
        _this.handleExitSubmit(event);
      });
      this.exitModal.querySelector('.sshr-card-modal__backdrop')
        .addEventListener('click', function() {
          _this.closeExitModal();
        });
    },

    handleAssignmentSubmit: function(event) {
      event.preventDefault();
      if (!this.assignmentContext) {
        this.closeAssignmentModal(false);
        return;
      }

      var type = this.assignmentTypeSelect.value;
      var recordedBy = document.getElementById('assignment-recorded-by').value.trim();
      var entryTime = document.getElementById('assignment-entry-time').value;

      if (!recordedBy) {
        alert('Vyplňte pole „Zapsal“.');
        return;
      }

      var card = this.assignmentContext.card;
      if (type === CARD_TYPES.PERSON) {
        var firstName = document.getElementById('assignment-first-name').value.trim();
        var lastName = document.getElementById('assignment-last-name').value.trim();
        var opNumber = document.getElementById('assignment-op-number').value.trim();

        if (!firstName || !lastName) {
          alert('Vyplňte jméno i příjmení.');
          return;
        }

        if (!/^\d{9}$/.test(opNumber)) {
          alert('Číslo OP musí mít 9 číslic.');
          return;
        }

        // Validace duplicitních dat pro osoby
        var duplicateErrors = this.validateDuplicates(CARD_TYPES.PERSON, {
          firstName: firstName,
          lastName: lastName,
          opNumber: opNumber
        });

        if (duplicateErrors.length > 0) {
          alert('Duplicitní data nalezena:\n\n' + duplicateErrors.join('\n'));
          return;
        }

        card.type = CARD_TYPES.PERSON;
        card.person = {
          firstName: firstName,
          lastName: lastName,
          opNumber: opNumber
        };
        card.truck = null;
      } else {
        var driverName = document.getElementById('assignment-driver-name').value.trim();
        var plate = document.getElementById('assignment-plate').value.trim().toUpperCase();
        if (!driverName || plate.length < 4) {
          alert('Vyplňte jméno řidiče i platnou SPZ.');
          return;
        }

        // Validace duplicitních dat pro kamiony
        var duplicateErrors = this.validateDuplicates(CARD_TYPES.TRUCK, {
          driverName: driverName,
          plate: plate
        });

        if (duplicateErrors.length > 0) {
          alert('Duplicitní data nalezena:\n\n' + duplicateErrors.join('\n'));
          return;
        }

        card.type = CARD_TYPES.TRUCK;
        card.truck = {
          driverName: driverName,
          plate: plate
        };
        card.person = null;
      }

      card.recordedBy = recordedBy;
      card.entryTime = entryTime;
      card.exitTime = null;
      card.datasetName = this.assignmentContext.datasetName;
      card.panelId = this.assignmentContext.panelId;
      console.log('🔧 [CARD-MANAGER] handleAssignmentSubmit - assigned card.panelId:', card.panelId);
      card.status = CARD_STATUS.ASSIGNED;
      card.incidents = [];
      card.displayId = this.buildDisplayId(card);

      this.renderPool();
      this.populateDropZone(this.assignmentContext.dropZone, card);

      // ✨ CRUCIAL: Store card in panelCardMap for Widget 4 recognition
      if (this.panelCardMap) {
        this.panelCardMap.set(card.panelId, card);
        console.log('✅ [CARD-MANAGER] Stored card in panelCardMap:', card.panelId, card);
      }

      // ✨ NOVÁ FUNKCE: Propagace jména do info panelu
      this.updateInfoPanelWithCardName(card);

      // ✨ NOVÁ FUNKCE: Aktualizace Widget 4 po registraci
      this.updateWidget4AfterRegistration();

      this.assignmentContext = null;
      this.closeAssignmentModal(false);
    },

    updateInfoPanelWithCardName: function(card) {
      if (!card || !card.panelId) {
        console.warn('⚠️ [CARD-MANAGER] Cannot update info panel - missing card or panelId');
        return;
      }

      try {
        // Najít odpovídající info panel podle panelId
        var infoPanel = document.getElementById(card.panelId);
        if (!infoPanel) {
          console.warn('⚠️ [CARD-MANAGER] Info panel not found:', card.panelId);
          return;
        }

        // Sestavit jméno podle typu karty
        var displayName = '';
        if (card.type === CARD_TYPES.PERSON) {
          displayName = card.person.firstName + ' ' + card.person.lastName;
        } else if (card.type === CARD_TYPES.TRUCK) {
          displayName = card.truck.driverName + ' (SPZ ' + card.truck.plate + ')';
        }

        // Najít a aktualizovat OSOBA č. text
        var headerSpan = infoPanel.querySelector('.text-xs.font-semibold.text-gray-800');
        if (headerSpan) {
          // Extrahovat číslo osoby z původního textu
          var originalText = headerSpan.textContent || '';
          var numberMatch = originalText.match(/OSOBA č\.(\d+)/);
          var personNumber = numberMatch ? numberMatch[1] : '?';

          // Aktualizovat text s jménem z formuláře
          headerSpan.textContent = displayName;

          console.log('✅ [CARD-MANAGER] Updated info panel header:', {
            panelId: card.panelId,
            personNumber: personNumber,
            displayName: displayName,
            newText: headerSpan.textContent
          });
        } else {
          console.warn('⚠️ [CARD-MANAGER] Header span not found in panel:', card.panelId);
        }

        // Volitelně: aktualizovat i návštěvnickou kartu zónu
        var cardDropZone = infoPanel.querySelector('.card-drop-zone');
        if (cardDropZone) {
          cardDropZone.innerHTML = '💳 ' + displayName + '<br><small class="text-gray-500">ID: ' + card.displayId + '</small><br><button type="button" class="btn btn-danger btn-sm w-100 mt-2" onclick="window.SSHRCardManager.openExitModal(window.SSHRCardManager.getCardByPanel(\'' + card.panelId + '\'))">🚪 UKONČIT</button>';
          cardDropZone.classList.add('text-success');
          cardDropZone.classList.remove('text-gray-500');
        }

        // Trigger event pro ostatní systémy
        if (window.dispatchEvent) {
          window.dispatchEvent(new CustomEvent('sshr-card-name-updated', {
            detail: {
              cardId: card.id,
              panelId: card.panelId,
              displayName: displayName,
              personNumber: headerSpan ? headerSpan.textContent.match(/OSOBA č\.(\d+)/) : null
            }
          }));
        }

      } catch (error) {
        console.error('❌ [CARD-MANAGER] Error updating info panel:', error);
      }
    },

    buildDisplayId: function(card) {
      var suffix = '00';
      if (card.datasetName) {
        var match = card.datasetName.match(/(\d+)/);
        if (match) {
          suffix = pad2(parseInt(match[1], 10));
        }
      }
      return card.baseId || card.id;
    },

    populateDropZone: function(dropZone, card) {
      if (!dropZone) return;
      console.log('🔧 [CARD-MANAGER] populateDropZone called with:', {card: card.displayId, panelId: card.panelId});
      console.log('🔧 [CARD-MANAGER] Creating HTML with EXIT button for card:', card.displayId);
      dropZone.classList.add('has-card');
      dropZone.dataset.cardId = card.id;

      var headline = card.type === CARD_TYPES.PERSON
        ? card.person.firstName + ' ' + card.person.lastName
        : card.truck.driverName + ' (SPZ ' + card.truck.plate + ')';

      var meta = 'ID: ' + card.displayId + '<br>Vstup: ' + (card.entryTime || '—');
      if (card.type === CARD_TYPES.PERSON) {
        meta += '<br>OP: ' + card.person.opNumber;
      } else {
        meta += '<br>SPZ: ' + card.truck.plate;
      }

      // Přidáme EXIT tlačítko přímo do meta informací
      meta += '<br><button type="button" class="btn btn-danger btn-sm" data-action="exit-inline" style="margin-top: 8px; width: 100%;">🚪 UKONČIT NÁVŠTĚVU</button>';

      dropZone.innerHTML = ''
        + '<div class="assigned-card" draggable="true">'
        +   '<div class="assigned-card__header">'
        +     '<span>' + headline + '</span>'
        +     '<button type="button" class="btn btn-danger btn-sm" data-action="exit-header" style="padding: 2px 8px; font-size: 10px;">EXIT</button>'
        +   '</div>'
        +   '<div class="assigned-card__meta">' + meta + '</div>'
        +   '<div class="assigned-card__actions">'
        +     '<button type="button" class="btn btn-outline-light btn-sm" data-action="remove">Odebrat</button>'
        +     '<button type="button" class="btn btn-success btn-sm" data-action="exit">EXIT</button>'
        +   '</div>'
        + '</div>'
        + '<div style="margin-top: 8px;">'
        +   '<button type="button" class="btn btn-danger btn-sm w-100" data-action="exit-fallback">🚪 Ukončit návštěvu</button>'
        + '</div>';

      console.log('🔧 [CARD-MANAGER] HTML created, looking for EXIT button...');
      var assignedEl = dropZone.querySelector('.assigned-card');
      var _this = this;
      assignedEl.addEventListener('dragstart', function(event) {
        event.dataTransfer.effectAllowed = 'move';
        event.dataTransfer.setData('application/json', JSON.stringify({ cardId: card.id, source: 'panel' }));
        assignedEl.classList.add('dragging');
      });
      assignedEl.addEventListener('dragend', function() {
        assignedEl.classList.remove('dragging');
      });

      dropZone.querySelector('[data-action="remove"]').addEventListener('click', function() {
        if (confirm('Odebrat kartu bez uložení?')) {
          _this.resetCard(card, false);
          _this.renderPool();
          _this.resetDropZone(dropZone);
        }
      });

      const exitButton = dropZone.querySelector('[data-action="exit"]');
      if (exitButton) {
        exitButton.addEventListener('click', function() {
          console.log('🔧 [CARD-MANAGER] EXIT button clicked for:', card.displayId);
          _this.openExitModal(card);
        });
        console.log('✅ [CARD-MANAGER] EXIT button event listener attached for:', card.displayId);
      } else {
        console.error('❌ [CARD-MANAGER] EXIT button not found in dropZone HTML');
      }

      // Fallback EXIT button
      const fallbackExitButton = dropZone.querySelector('[data-action="exit-fallback"]');
      if (fallbackExitButton) {
        fallbackExitButton.addEventListener('click', function() {
          console.log('🔧 [CARD-MANAGER] Fallback EXIT button clicked for:', card.displayId);
          _this.openExitModal(card);
        });
        console.log('✅ [CARD-MANAGER] Fallback EXIT button event listener attached for:', card.displayId);
      }

      // Inline EXIT button (in meta section)
      const inlineExitButton = dropZone.querySelector('[data-action="exit-inline"]');
      if (inlineExitButton) {
        inlineExitButton.addEventListener('click', function() {
          console.log('🔧 [CARD-MANAGER] Inline EXIT button clicked for:', card.displayId);
          _this.openExitModal(card);
        });
        console.log('✅ [CARD-MANAGER] Inline EXIT button event listener attached for:', card.displayId);
      }
    },

    resetDropZone: function(dropZone) {
      dropZone.classList.remove('has-card');
      dropZone.dataset.cardId = '';
      dropZone.innerHTML = '<div class="drop-zone-placeholder">💳 Návštěvnická karta</div>';

      // ✨ NOVÁ FUNKCE: Vrátit info panel na anonymní "OSOBA č. X"
      this.anonymizeInfoPanel(dropZone);

      // ✨ NOVÁ FUNKCE: Aktualizace Widget 4 po odregistraci
      this.updateWidget4AfterRegistration();
    },

    unregisterDropZone: function(panelId) {
      if (!panelId) return;
      const dropZone = this.dropZones && this.dropZones.get(panelId);
      if (dropZone) {
        this.resetDropZone(dropZone);
        this.dropZones.delete(panelId);
      }
    },

    openExitModal: function(card) {
      document.getElementById('exit-card-id').value = card.displayId;
      document.getElementById('exit-card-label').value = card.type === CARD_TYPES.PERSON
        ? card.person.firstName + ' ' + card.person.lastName
        : card.truck.driverName + ' (SPZ ' + card.truck.plate + ')';
      document.getElementById('exit-entry-time').value = card.entryTime || '—';
      document.getElementById('exit-exit-time').value = formatTime(new Date());
      document.getElementById('exit-incident-info').textContent = card.incidents.length + ' incidentů';

      this.exitContext = { card: card };
      this.exitModal.classList.add('is-active');
    },

    closeExitModal: function() {
      if (this.exitModal) {
        this.exitModal.classList.remove('is-active');
      }
      this.exitContext = null;
    },

    handleExitSubmit: function(event) {
      event.preventDefault();
      if (!this.exitContext) {
        this.closeExitModal();
        return;
      }

      var exitTime = document.getElementById('exit-exit-time').value.trim();
      if (!/^([0-1]\d|2[0-3]):[0-5]\d:[0-5]\d$/.test(exitTime)) {
        alert('Zadejte čas ve formátu HH:MM:SS.');
        return;
      }

      var card = this.exitContext.card;
      card.exitTime = exitTime;
      this.appendVisitLog(card);

      var dropZone = this.dropZones.get(card.panelId);
      if (dropZone) {
        this.resetDropZone(dropZone);
      }
      this.resetCard(card, false);
      this.renderPool();
      this.closeExitModal();
    },

    appendVisitLog: function(card) {
      if (!card.entryTime || !card.exitTime) {
        return;
      }
      var dateKey = new Date().toISOString().split('T')[0];
      var storageKey = STORAGE_PREFIX + dateKey;

      var entry = {
        cardId: card.displayId,
        dataset: card.datasetName,
        type: card.type,
        entryTime: card.entryTime,
        exitTime: card.exitTime,
        recordedBy: card.recordedBy,
        incidents: card.incidents.length,
        incidentDetails: card.incidents || [], // Detaily incidentů pro MQTT
        panelId: card.panelId,
        timestamp: new Date().toISOString()
      };
      if (card.person) {
        entry.person = card.person;
      }
      if (card.truck) {
        entry.truck = card.truck;
      }

      try {
        // 1. Lokální uložení (jako dosud)
        var existing = JSON.parse(localStorage.getItem(storageKey) || '[]');
        existing.push(entry);
        localStorage.setItem(storageKey, JSON.stringify(existing));

        console.log('✅ [CARD-MANAGER] Visit log saved to localStorage:', entry.cardId);

        // 2. 🆕 MQTT publikování podle CEPRO vzoru
        this.publishVisitLogToMqtt(entry);

      } catch (error) {
        console.error('❌ [SSHR-CARD] Unable to save visit log:', error);
      }
    },

    /**
     * 🆕 MQTT publikování visit logu podle CEPRO struktury
     */
    publishVisitLogToMqtt: function(entry) {
      try {
        // Použít MQTT klient z SSHR Visit Service nebo globální
        var mqttClient = null;

        if (window.SSHRVisitService && window.SSHRVisitService.mqttClient) {
          mqttClient = window.SSHRVisitService.mqttClient;
        } else if (window.CEPROMqtt && window.CEPROMqtt.client) {
          mqttClient = window.CEPROMqtt.client; // Fallback na CEPRO klient
        }

        if (!mqttClient || !mqttClient.connected) {
          console.warn('⚠️ [CARD-MANAGER] MQTT client not available for visit log publication');
          // Uložit do fronty pro pozdější odeslání
          this.queueMqttMessage('sshr/visit/complete', entry);
          return;
        }

        // MQTT zpráva podle CEPRO formátu (FE_BE.md řádek 42-50)
        var mqttMessage = {
          messageType: 'visit-complete',
          sessionId: 'sshr-visit-' + Date.now(),
          timestamp: entry.timestamp,
          source: 'SSHR_Bohuslavice',
          data: {
            visit: entry,
            summary: {
              duration: this.calculateVisitDuration(entry.entryTime, entry.exitTime),
              totalIncidents: entry.incidents,
              riskLevel: entry.incidents > 2 ? 'high' : (entry.incidents > 0 ? 'medium' : 'low')
            }
          }
        };

        // Publikovat na MQTT topik
        var topic = 'sshr/visit/complete';
        var payload = JSON.stringify(mqttMessage);

        mqttClient.publish(topic, payload, { qos: 1 }, function(err) {
          if (err) {
            console.error('❌ [CARD-MANAGER] MQTT publish error:', err);
            // Fallback uložení
            this.queueMqttMessage(topic, mqttMessage);
          } else {
            console.log('📡 [CARD-MANAGER] Visit log published to MQTT:', {
              topic: topic,
              cardId: entry.cardId,
              incidents: entry.incidents
            });
          }
        }.bind(this));

      } catch (error) {
        console.error('❌ [CARD-MANAGER] Error publishing visit log to MQTT:', error);
        // Fallback uložení
        this.queueMqttMessage('sshr/visit/complete', entry);
      }
    },

    /**
     * Fronta pro MQTT zprávy (když není připojení)
     */
    queueMqttMessage: function(topic, message) {
      if (!this.mqttQueue) {
        this.mqttQueue = [];
      }

      this.mqttQueue.push({
        topic: topic,
        message: message,
        timestamp: new Date().toISOString()
      });

      console.log('📋 [CARD-MANAGER] MQTT message queued for later delivery:', topic);

      // Uložit do localStorage pro persistenci
      try {
        localStorage.setItem('SSHR_mqttQueue', JSON.stringify(this.mqttQueue));
      } catch (e) {
        console.warn('⚠️ [CARD-MANAGER] Unable to persist MQTT queue:', e);
      }
    },

    /**
     * Vypočítá délku návštěvy v sekundách
     */
    calculateVisitDuration: function(entryTime, exitTime) {
      try {
        var entry = new Date('1970-01-01T' + entryTime);
        var exit = new Date('1970-01-01T' + exitTime);
        return Math.round((exit - entry) / 1000);
      } catch (e) {
        return 0;
      }
    },

    resetCard: function(card, saveLog) {
      if (saveLog) {
        this.appendVisitLog(card);
      }

      card.status = CARD_STATUS.FREE;
      card.type = null;
      card.datasetName = null;
      card.panelId = null;
      card.entryTime = null;
      card.exitTime = null;
      card.recordedBy = null;
      card.person = null;
      card.truck = null;
      card.incidents = [];
      card.displayId = card.baseId || card.id;

      this.updatePoolCounter();
    },

    recordIncident: function(datasetName, incidentData) {
      // DEPRECATED: Tato metoda byla odstraněna, protože vytvářela duplicitní záznamy
      // Incidenty se nyní spravují pouze přes IncidentRegistry

      console.warn('⚠️ [CARD-MANAGER] recordIncident is deprecated - incidents are managed by IncidentRegistry');

      // Pouze zachovat integraci s visit service
      if (window.SSHRVisitService && incidentData) {
        window.SSHRVisitService.recordIncident(datasetName, incidentData);
      }
    },

    promptExitForDataset: function(datasetName) {
      var card = this.cards.find(function(c) {
        return c.datasetName === datasetName && c.status === CARD_STATUS.ASSIGNED;
      });
      if (card && !this.exitContext) {
        this.openExitModal(card);
      }
    },

    clearAllAssignments: function() {
      var _this = this;
      this.cards.forEach(function(card) {
        if (card.status === CARD_STATUS.ASSIGNED) {
          var dropZone = _this.dropZones.get(card.panelId);
          if (dropZone) {
            _this.resetDropZone(dropZone);
          }
          _this.resetCard(card, false);
        }
      });
      this.renderPool();
    },

    /**
     * Assign card to dataset/panel (CEPRO compatibility API)
     */
    assignCard: function(cardId, datasetName, panelId, visitorData) {
      const card = this.getCard(cardId);
      if (!card || card.status === CARD_STATUS.ASSIGNED) {
        console.warn(`❌ [SSHR-CARD] Cannot assign card ${cardId}: not found or already assigned`);
        return false;
      }

      const dropZone = this.dropZones.get(panelId);
      if (!dropZone) {
        console.warn(`❌ [SSHR-CARD] Cannot assign card ${cardId}: drop zone ${panelId} not found`);
        return false;
      }

      // Assign card data
      card.status = CARD_STATUS.ASSIGNED;
      card.datasetName = datasetName;
      card.panelId = panelId;
      card.entryTime = formatTime(new Date());
      card.recordedBy = visitorData?.recordedBy || 'System';

      if (visitorData?.type === 'person') {
        card.type = CARD_TYPES.PERSON;
        card.person = {
          firstName: visitorData.firstName,
          lastName: visitorData.lastName,
          opNumber: visitorData.opNumber
        };
        card.displayId = `${visitorData.firstName} ${visitorData.lastName}`;
      } else if (visitorData?.type === 'truck') {
        card.type = CARD_TYPES.TRUCK;
        card.truck = {
          driverName: visitorData.driverName,
          plate: visitorData.plate
        };
        card.displayId = `${visitorData.driverName} (${visitorData.plate})`;
      }

      // Update UI
      this.updateDropZone(dropZone, card);
      this.setPanelVisitorName(panelId, card.displayId);
      this.updatePersonMetadata(datasetName, card);
      this.renderPool();
      if (this.panelCardMap) {
        this.panelCardMap.set(panelId, card);
      }

      // Start visit in visit service
      if (window.SSHRVisitService) {
        window.SSHRVisitService.startVisit(card);
      }

      console.log(`✅ [SSHR-CARD] Card ${cardId} assigned to panel ${panelId}`);
      return true;
    },

    /**
     * Unassign card from panel (CEPRO compatibility API)
     */
    unassignCard: function(cardId, saveLog = false) {
      const card = this.getCard(cardId);
      if (!card || card.status !== CARD_STATUS.ASSIGNED) {
        console.warn(`❌ [SSHR-CARD] Cannot unassign card ${cardId}: not found or not assigned`);
        return false;
      }

      const dropZone = this.dropZones.get(card.panelId);
      if (dropZone) {
        this.resetDropZone(dropZone);
      }

      if (this.panelCardMap) {
        this.panelCardMap.delete(card.panelId);
      }

      // End visit in visit service
      if (window.SSHRVisitService) {
        window.SSHRVisitService.endVisit(cardId, {
          exitTime: new Date().toTimeString().substr(0, 8),
          recordedBy: 'System'
        });
      }

      // Clear person metadata
      this.clearPersonMetadata(card.datasetName);
      this.resetPanelVisitorName(card.panelId);

      this.resetCard(card, saveLog);
      this.renderPool();

      console.log(`✅ [SSHR-CARD] Card ${cardId} unassigned`);
      return true;
    },

    /**
     * Set panel visitor name in header
     */
    setPanelVisitorName: function(panelId, visitorName) {
      console.log(`🔧 [CARD-MANAGER] setPanelVisitorName - panelId: ${panelId}, visitorName: ${visitorName}`);
      const panel = document.getElementById(panelId);
      if (!panel) {
        console.error(`❌ [CARD-MANAGER] Panel not found: ${panelId}`);
        return;
      }

      // Try multiple selectors for the header span
      let header = panel.querySelector('.panel-header span');
      if (!header) {
        // Fallback: try different selectors
        header = panel.querySelector('.panel-header .text-xs');
        if (!header) {
          header = panel.querySelector('.text-xs.font-semibold');
          if (!header) {
            header = panel.querySelector('[class*="OSOBA"]');
          }
        }
      }

      console.log(`🔧 [CARD-MANAGER] Found header element:`, header);

      if (header && visitorName) {
        console.log(`✅ [CARD-MANAGER] Updating panel name from "${header.textContent}" to "${visitorName}"`);
        header.textContent = visitorName;
        header.style.color = '#059669'; // emerald-600
        header.style.fontWeight = 'bold';
      } else if (!header) {
        console.error(`❌ [CARD-MANAGER] Header element not found in panel ${panelId}`);
        console.log(`🔍 [CARD-MANAGER] Available selectors:`, {
          'panel-header span': !!panel.querySelector('.panel-header span'),
          'panel-header .text-xs': !!panel.querySelector('.panel-header .text-xs'),
          'text-xs.font-semibold': !!panel.querySelector('.text-xs.font-semibold')
        });
      } else {
        console.warn(`⚠️ [CARD-MANAGER] Header found but no visitorName provided`);
      }
    },

    /**
     * Reset panel to default name
     */
    resetPanelVisitorName: function(panelId) {
      const panel = document.getElementById(panelId);
      if (!panel) return;

      const header = panel.querySelector('.panel-header span');
      if (header) {
        // Extract original person number
        const personNumber = panelId.replace('person-info-', '').replace(/\D/g, '') || '1';
        header.textContent = `OSOBA č.${personNumber}`;
        header.style.color = '';
        header.style.fontWeight = '';
      }
    },

    /**
     * Update person metadata for parallel tracking
     */
    updatePersonMetadata: function(datasetName, card) {
      if (window.SSHR?.parallelEngine?.persons) {
        const persons = window.SSHR.parallelEngine.persons;
        const person = persons.find(p => p.datasetName === datasetName);
        if (person) {
          person.metadata = person.metadata || {};
          person.metadata.visitor = {
            cardId: card.id,
            name: card.displayId,
            type: card.type,
            entryTime: card.entryTime,
            recordedBy: card.recordedBy,
            person: card.person,
            truck: card.truck
          };
          console.log(`👤 [SSHR-CARD] Person metadata updated for ${datasetName}`);
        }
      }
    },

    /**
     * Clear person metadata
     */
    clearPersonMetadata: function(datasetName) {
      if (window.SSHR?.parallelEngine?.persons) {
        const persons = window.SSHR.parallelEngine.persons;
        const person = persons.find(p => p.datasetName === datasetName);
        if (person && person.metadata) {
          delete person.metadata.visitor;
        }
      }
    },

    /**
     * Get incident summary for card
     */
    getIncidentSummary: function(cardId) {
      const card = this.getCard(cardId);
      if (!card) return null;

      return {
        count: card.incidents.length,
        incidents: card.incidents,
        lastIncident: card.incidents[card.incidents.length - 1] || null
      };
    },

    /**
     * Get person incident count - REFAKTOROVÁNO pro IncidentRegistry
     */
    getPersonIncidentCount: function(datasetName, panelId) {
      // Nejprve zkusit kartu pro zachování kompatibility s návštěvníky
      let card = null;
      if (panelId && this.panelCardMap) {
        card = this.panelCardMap.get(panelId) || null;
      }
      if (!card && datasetName) {
        card = this.cards.find(c => c.datasetName === datasetName && c.status === CARD_STATUS.ASSIGNED) || null;
      }

      // Pokud máme kartu, VŽDY číst z IncidentRegistry místo card.incidents
      // Tím se eliminují duplicity
      if (card && window.SSHR?.incidentRegistry) {
        const personId = this.getPersonIdFromDataset(datasetName);
        if (personId) {
          const count = window.SSHR.incidentRegistry.getTotalCount(personId);
          console.log(`📊 [CARD-MANAGER] Incident count for ${datasetName} from IncidentRegistry: ${count}`);
          return count;
        }
      }

      // Fallback na původní logiku pro zpětnou kompatibilitu
      return card ? card.incidents.length : 0;
    },

    /**
     * Pomocná metoda pro získání personId z datasetName
     */
    getPersonIdFromDataset: function(datasetName) {
      if (!datasetName) return null;

      const tracker = window.personTracker || window.SSHR?.personTracker || null;
      if (tracker) {
        let person = null;

        if (typeof tracker.getAllPersons === 'function') {
          person = tracker.getAllPersons().find(p => (p.datasetName || p.metadata?.dataset) === datasetName);
        } else if (tracker.persons) {
          if (typeof tracker.persons.get === 'function') {
            tracker.persons.forEach((value) => {
              if (!person && (value.datasetName || value.metadata?.dataset) === datasetName) {
                person = value;
              }
            });
          } else if (Array.isArray(tracker.persons)) {
            person = tracker.persons.find(p => (p.datasetName || p.metadata?.dataset) === datasetName) || null;
          }
        }

        if (person) {
          return person.id;
        }
      }

      // Fallback: extrakt čísla z SSHR_DATA1 -> "1"
      const match = datasetName.match(/SSHR_DATA(\d+)/);
      return match ? match[1] : null;
    },

    getCard: function(cardId) {
      return this.cardMap.get(cardId) || null;
    },

    getCardByPanel: function(panelId) {
      if (!this.panelCardMap) return null;
      return this.panelCardMap.get(panelId) || null;
    },

    /**
     * Nová funkce: Nastavení poslechu incidentů ze SSHRIncidentEngine
     */
    setupIncidentListeners: function() {
      console.log('🎧 [CARD-MANAGER] Setting up incident listeners...');

      // POZOR: Odstranili jsme duplicitní poslouchání incident-resolve!
      // Card manager už NEPOSLOUCHÁ incident eventy - data čte přímo z IncidentRegistry

      console.log('ℹ️ [CARD-MANAGER] Incident listeners removed - using IncidentRegistry for data');
    },

    /**
     * Najít kartu podle personId nebo datasetName
     */
    findCardByPersonId: function(personId, datasetName) {
      // Pokusit se najít podle datasetName (SSHR_DATA1, SSHR_DATA2, etc.)
      if (datasetName) {
        var card = this.cards.find(function(c) {
          return c.datasetName === datasetName && c.status === CARD_STATUS.ASSIGNED;
        });
        if (card) {
          return card;
        }
      }

      // Fallback: najít podle personId v panel ID
      var card = this.cards.find(function(c) {
        return c.panelId && c.panelId.includes(personId) && c.status === CARD_STATUS.ASSIGNED;
      });

      return card || null;
    },

    /**
     * Anonymizace info panelu po EXIT - vrátit na "OSOBA č. X"
     */
    anonymizeInfoPanel: function(dropZone) {
      try {
        var panelId = dropZone.dataset.panelId;
        if (!panelId) {
          console.warn('⚠️ [CARD-MANAGER] anonymizeInfoPanel: panelId not found in dropZone');
          return;
        }

        var infoPanel = document.getElementById(panelId);
        if (!infoPanel) {
          console.warn('⚠️ [CARD-MANAGER] Info panel not found:', panelId);
          return;
        }

        // Najít header span a vrátit na anonymní text
        var headerSpan = infoPanel.querySelector('.text-xs.font-semibold.text-gray-800');
        if (headerSpan) {
          // Extrahovat číslo osoby ze současného textu
          var currentText = headerSpan.textContent || '';
          var numberMatch = currentText.match(/OSOBA č\.(\d+)/);
          var personNumber = numberMatch ? numberMatch[1] : '?';

          // Vrátit na anonymní formát
          headerSpan.textContent = 'OSOBA č.' + personNumber;

          console.log('✅ [CARD-MANAGER] Anonymized info panel header:', {
            panelId: panelId,
            personNumber: personNumber,
            newText: headerSpan.textContent
          });
        } else {
          console.warn('⚠️ [CARD-MANAGER] Header span not found in panel for anonymization:', panelId);
        }

        // Reset drop zone zpět na výchozí stav
        var cardDropZone = infoPanel.querySelector('.card-drop-zone');
        if (cardDropZone) {
          cardDropZone.innerHTML = '💳 Návštěvnická karta';
          cardDropZone.classList.remove('text-success');
          cardDropZone.classList.add('text-gray-500');
        }

        // Trigger event pro ostatní systémy
        if (window.dispatchEvent) {
          window.dispatchEvent(new CustomEvent('sshr-card-anonymized', {
            detail: {
              panelId: panelId,
              personNumber: headerSpan ? headerSpan.textContent.match(/OSOBA č\.(\d+)/) : null
            }
          }));
        }

      } catch (error) {
        console.error('❌ [CARD-MANAGER] Error anonymizing info panel:', error);
      }
    },

    /**
     * ✨ NOVÁ FUNKCE: Aktualizace Widget 4 po změně registrace
     */
    updateWidget4AfterRegistration: function() {
      try {
        // Zavolat globální funkci pro aktualizaci widget 4
        if (typeof window.updateWidget4PersonStats === 'function') {
          // Krátká prodleva pro zajištění, že DOM je aktualizován
          setTimeout(function() {
            window.updateWidget4PersonStats();
            console.log('🔄 [CARD-MANAGER] Widget 4 updated after card registration change');
          }, 100);
        } else {
          console.warn('⚠️ [CARD-MANAGER] updateWidget4PersonStats function not available');
        }
      } catch (error) {
        console.error('❌ [CARD-MANAGER] Error updating Widget 4:', error);
      }
    }
  };

  window.SSHRCardManager = manager;

})();
