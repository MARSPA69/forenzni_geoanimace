# STREAM-Variabilní povolené zóny - Nový design

## Přehled
Tento dokument popisuje nový design pro STREAM-Variabilní povolené zóny, který nahrazuje problematický Management zón systém.

## Hlavní změny
- ✅ **ODSTRANĚNO**: Popup panel "POTVRZENÍ ZÓN" a všechny navazující funkce
- ✅ **ODSTRANĚNO**: Leaflet.draw dropdown tlačítka (Delete layers, Edit layers, Draw rectangle, Draw polygon)
- ✅ **ZAKÁZÁNO**: FLOAT mode - způsoboval nekonečné smyčky
- ✅ **ZAKÁZÁNO**: Variabilní povolené zóny - dočasně vypnuto

## Nový STREAM přístup

### 1. Architektura
```
STREAM-Variabilní zóny = {
  - Streaming data sources (real-time)
  - Variable zone boundaries (dynamic)
  - No manual drawing/confirmation workflow
  - Automated zone management
}
```

### 2. Klíčové komponenty
- **Stream Engine**: Real-time data processing
- **Zone Calculator**: Dynamic boundary calculation
- **Auto-Manager**: Automated zone lifecycle
- **Event System**: Real-time updates without UI rebuilds

### 3. Technická implementace
- WebSocket streams pro real-time data
- Geospatial calculations pro dynamic boundaries
- Event-driven updates místo cyklických rebuild funkcí
- Stateless zone management

## Migrace plan
1. **Phase 1**: ✅ Cleanup starého systému (dokončeno)
2. **Phase 2**: Design nového STREAM API
3. **Phase 3**: Implementace streaming engine
4. **Phase 4**: Integration s existujícím SSHR systémem
5. **Phase 5**: Testing a deployment

## API Placeholder
```javascript
// Budoucí STREAM API
window.SSHR.streamZones = {
  enable: () => {},
  disable: () => {},
  setStreamSource: (url) => {},
  onZoneUpdate: (callback) => {},
  getActiveZones: () => [],
  clearAll: () => {}
};
```

---
**Status**: Management zón cleanup dokončen ✅
**Next**: Čekání na specifikace nového STREAM systému