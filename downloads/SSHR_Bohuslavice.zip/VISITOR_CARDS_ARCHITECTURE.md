## 🎫 Visitor Card System Architecture

### 📋 System Overview
Kompletně rekonstruovaný systém návštěvnických karet s plnou CEPRO kompatibilitou a backend readiness.

### 🏗️ Architecture Components

#### **1. Core Card Manager (SSHR_card_manager.js)**
```javascript
// === CARD LIFECYCLE API ===
assignCard(cardId, datasetName, panelId, visitorData)    // ENTRY workflow
unassignCard(cardId, saveLog)                           // EXIT workflow
setPanelVisitorName(panelId, visitorName)               // UI updates
updatePersonMetadata(datasetName, card)                 // Tracking integration

// === INCIDENT INTEGRATION ===
recordIncident(datasetName, incidentData)               // Auto-logging
getIncidentSummary(cardId)                              // Analytics
getPersonIncidentCount(datasetName)                     // Real-time stats

// === DROP ZONE MANAGEMENT ===
registerDropZone(panel, metadata)                       // Panel registration
updateDropZone(dropZone, card)                         // Visual updates
resetDropZone(dropZone)                                // Clean state
```

#### **2. Visit Service (sshr-visit-service.js)**
```javascript
// === VISIT TRACKING ===
startVisit(visitorData)                                 // Begin tracking
endVisit(cardId, exitData)                            // Complete visit
recordMovement(datasetName, movementData)              // Position logs
recordIncident(datasetName, incidentData)              // Security events

// === ANALYTICS & REPORTING ===
getVisitStats()                                        // Current stats
getMonthlyAnalytics(year, month)                       // Historical data
exportForensicDataset(startDate, endDate)             // Forensic export
calculateVisitAnalytics(visit)                        // Risk assessment

// === BACKEND INTEGRATION ===
publishVisitStart(visit)                               // MQTT: sshr/visit/start
publishVisitEnd(visit)                                 // MQTT: sshr/visit/stop
publishIncident(visit, incident)                      // MQTT: sshr/incident/eval
```

#### **3. Panel Integration (parallel-tracking.js)**
```javascript
// === DROP ZONE REGISTRATION ===
createPersonInfoPanel(person) {
  // ...panel HTML creation...

  // Register with card manager
  window.SSHR.cardManager.registerDropZone(panel, {
    panelId: `person-info-${person.id}`,
    datasetName: person.datasetName,
    personId: person.id,
    personNumber: personNumber
  });
}

// === INCIDENT DISPLAY ===
updatePersonInfoPanel(person, panel) {
  // Prefer card manager for incident count
  if (window.SSHR?.cardManager?.getPersonIncidentCount) {
    totalCount = window.SSHR.cardManager.getPersonIncidentCount(person.datasetName);
  }
}
```

#### **4. Incident Engine Integration (incident-engine.js)**
```javascript
// === AUTO INCIDENT RECORDING ===
startIncident(personId, context) {
  // Record in card manager
  if (window.SSHR?.cardManager?.recordIncident) {
    window.SSHR.cardManager.recordIncident(dataset, {
      type: 'zone-violation-start',
      startTime: timestamp,
      startGPS: { lat, lng },
      zone: zoneInfo.zone?.name,
      message: message
    });
  }
}

resolveIncident(personId, context) {
  // Record resolution with analytics
  if (window.SSHR?.cardManager?.recordIncident) {
    window.SSHR.cardManager.recordIncident(dataset, {
      type: 'zone-violation-end',
      startTime: state.startedAt,
      endTime: endedAt,
      duration: durationSeconds,
      maxDistance: maxDistanceMeters,
      zone: state.startSample.zoneInfo?.zone?.name
    });
  }
}
```

### 🔄 Data Flow Architecture

#### **Entry Workflow**
```
1. User drags card from pool → info panel drop zone
2. Card manager detects drop → opens assignment modal
3. User fills form (name, OP, recorded by) → submits
4. assignCard() API called:
   ├── Card status = ASSIGNED
   ├── Panel renamed to visitor name
   ├── Person metadata updated
   └── Visit service starts tracking
5. Incident engine auto-links to card for recording
```

#### **Incident Flow**
```
1. Person enters RED zone → Incident engine detects
2. startIncident() called → Card manager records
3. Visit service logs incident with GPS/zone/time
4. Panel updates incident count in real-time
5. resolveIncident() → Complete incident record
6. Analytics calculate risk level
```

#### **Exit Workflow**
```
1. Animation ends → Card manager prompts exit
2. User confirms exit → unassignCard() called
3. Visit service ends visit with analytics
4. Visit log stored with complete data:
   ├── Duration, zones visited, incidents
   ├── Risk level assessment
   ├── Movement patterns
   └── Proximity to INFRA elements
5. Card returns to pool, panel reset
```

### 💾 Data Persistence

#### **Local Storage Structure**
```javascript
// Daily visit logs
localStorage['SSHR_visitLog_2025-11-04'] = [{
  visitId: "visit_1730736000000_abc123def",
  cardId: "KARTA-05",
  person: { firstName: "Jan", lastName: "Novák", opNumber: "123456789" },
  startTime: "2025-11-04T08:30:00.000Z",
  endTime: "2025-11-04T10:15:00.000Z",
  incidents: [
    {
      type: "zone-violation-start",
      startTime: 1730738400000,
      startGPS: { lat: 49.1234, lng: 16.5678 },
      zone: "Restricted Area A"
    }
  ],
  riskLevel: "medium",
  totalDuration: 6300000,
  zones: ["GREEN-01", "GREEN-03"],
  maxDistance: 245.67
}]

// Monthly aggregations
localStorage['SSHR_monthly_2025-11'] = {
  totalVisits: 156,
  totalIncidents: 23,
  riskLevels: { normal: 140, medium: 12, high: 4 },
  riskyVisitors: ["Jan Novák", "Marie Svoboda"]
}
```

### 🔗 Backend Integration Points

#### **MQTT Topics**
- `sshr/visit/start` - Visitor entry with full metadata
- `sshr/visit/stop` - Visitor exit with analytics
- `sshr/incident/eval` - Real-time incident evaluation

#### **REST Endpoints**
- `POST /api/sshr/visits` - Visit data synchronization
- `GET /api/sshr/incidents` - Incident history queries
- `GET /api/sshr/reports` - Monthly/yearly analytics

#### **Queue System**
```javascript
visitQueue = [
  { type: 'visit-start', data: visitObject, timestamp: 1730736000000 },
  { type: 'visit-end', data: visitObject, timestamp: 1730742300000 },
  { type: 'incident', data: incidentObject, timestamp: 1730738400000 }
]
```

### 📊 Analytics & Risk Assessment

#### **Risk Scoring Algorithm**
```javascript
calculateVisitAnalytics(visit) {
  let riskScore = 0;

  // Incident frequency risk
  if (visit.incidents.length >= 3) riskScore += 3;
  else if (visit.incidents.length > 0) riskScore += 1;

  // Duration risk (2+ hours)
  if (visit.totalDuration > 7200000) riskScore += 2;

  // INFRA proximity risk (<50m)
  if (visit.infraProximity) riskScore += 2;

  // Zone variety risk (suspicious movement)
  if (visit.zones.length > 5) riskScore += 1;

  visit.riskLevel = riskScore >= 4 ? 'high' :
                   riskScore >= 2 ? 'medium' : 'normal';
}
```

#### **Forensic Export Structure**
```javascript
exportForensicDataset(startDate, endDate) {
  return {
    metadata: {
      generatedAt: "2025-11-04T12:00:00.000Z",
      dateRange: { startDate, endDate },
      totalVisits: 45,
      riskyVisits: 8
    },
    visits: [...], // Complete visit objects
    analytics: {
      riskFactors: [
        ["zone-violation", 12],
        ["long-duration", 5],
        ["infra-proximity", 3]
      ],
      patterns: {
        peakHours: [["08", 15], ["14", 12], ["16", 8]],
        riskZones: [["Restricted Area A", 8], ["Storage Zone", 4]]
      ],
      recommendations: [
        "Monitor Restricted Area A more frequently",
        "Review access permissions for repeat violators"
      ]
    }
  }
}
```

### 🎯 System Benefits

1. **🔄 Complete Lifecycle**: Drop-in → assignment → tracking → analytics → exit
2. **📊 Real-time Analytics**: Risk assessment, incident correlation, movement patterns
3. **🔍 Forensic Ready**: Complete audit trail for security investigations
4. **🌐 Backend Ready**: MQTT/REST integration prepared for server deployment
5. **⚡ Performance**: Local caching with background sync for responsive UI
6. **🛡️ Security**: Complete incident correlation with visitor identification
7. **📈 Scalable**: Designed for enterprise deployment with data retention policies

---

## 🔧 Implementation Details

### **File Structure**
```
SSHR_Bohuslavice/
├── SSHR_card_manager.js      # Core card management & UI
├── sshr-visit-service.js     # Visit logging & analytics
├── parallel-tracking.js     # Panel integration & drop zones
├── incident-engine.js       # Automatic incident recording
├── index_SSHR.html          # System initialization & scripts
└── SSHR.md                  # Complete documentation
```

### **Dependencies**
- **Leaflet**: Map functionality
- **Turf.js**: Geospatial calculations
- **Anime.js**: Smooth animations
- **LocalStorage**: Data persistence
- **Custom Events**: Inter-module communication

### **Testing Strategy**
1. **Unit Tests**: Card lifecycle, visit tracking, analytics
2. **Integration Tests**: Drop zones, incident recording, panel updates
3. **End-to-End Tests**: Complete visitor journey simulation
4. **Performance Tests**: Multiple concurrent visitors
5. **Data Validation**: Storage integrity, export accuracy

### **Future Enhancements**
1. **Server Integration**: Replace localStorage with REST/MQTT
2. **Mobile App**: Visitor self-registration via QR codes
3. **AI Analytics**: Predictive risk assessment
4. **Real-time Alerts**: Push notifications for security staff
5. **Biometric Integration**: Photo capture and facial recognition

---

**🎯 Status**: ✅ COMPLETED - Ready for production deployment**