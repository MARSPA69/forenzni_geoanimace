/**
 * SSHR Bohuslavice - Zone definitions & runtime API
 * -------------------------------------------------
 * - Maintains default (fixed) GREEN polygons derived from the site survey.
 * - Computes dynamic RED zones as the fenced perimeter minus all GREEN areas.
 * - Exposes runtime helpers for the UI (management mode) to override GREEN zones.
 * - Emits `sshr-zones-updated` events whenever the topology changes so that the
 *   renderer and incident engine can refresh their caches.
 */

(function defineSshrZones(global) {
  const turfAvailable = typeof turf !== 'undefined';

  const FENCE_COORDS = [
    [50.328088307819414, 16.0913477895888],
    [50.33289123277615, 16.096910931466788],
    [50.33247319198437, 16.09789285374428],
    [50.32767573491579, 16.092371852035793],
    [50.328088307819414, 16.0913477895888]
  ];

  const DEFAULT_GREEN_RAW = [
    {
      id: 'GREEN_ENTRY',
      name: 'GREEN ENTRY',
      coordinates: [
        [50.32802700536366, 16.091518739803767],
        [50.32797241136224, 16.091629471214745],
        [50.329739592123474, 16.093636325343223],
        [50.329785497784684, 16.093496248693228],
        [50.32802700536366, 16.091518739803767]
      ]
    },
    {
      id: 'GREEN_A',
      name: 'GREEN ZONE A',
      coordinates: [
        [50.32981313855813, 16.093543491170593],
        [50.32974965361522, 16.093647089923323],
        [50.332520910594226, 16.096861068075473],
        [50.33258225302885, 16.096631535348507],
        [50.32981313855813, 16.093543491170593]
      ]
    },
    {
      id: 'GREEN_B',
      name: 'GREEN ZONE B',
      coordinates: [
        [50.331408375942324, 16.09644390546972],
        [50.33161553138562, 16.09665126525265],
        [50.33188029841725, 16.096110474753054],
        [50.33169627602661, 16.095858238010223],
        [50.331408375942324, 16.09644390546972]
      ]
    },
    {
      id: 'GREEN_C',
      name: 'GREEN ZONE C',
      coordinates: [
        [50.32868307326477, 16.09322132059359],
        [50.32860810057086, 16.093424459764396],
        [50.33219400296278, 16.09748907484758],
        [50.33225716724023, 16.097392993267203],
        [50.32868307326477, 16.09322132059359]
      ]
    },
    {
      id: 'GREEN_D',
      name: 'GREEN ZONE D',
      coordinates: [
        [50.32975225709849, 16.0936575128202],
        [50.329435257763976, 16.0942437866706],
        [50.329847787832875, 16.094704564843482],
        [50.33014393007723, 16.094104757906052],
        [50.32975225709849, 16.0936575128202]
      ]
    }
  ];

  const ensureClosed = (coords = []) => {
    if (!coords.length) return [];
    const closed = coords.map(([lat, lng]) => [Number(lat), Number(lng)]);
    const [firstLat, firstLng] = closed[0];
    const [lastLat, lastLng] = closed[closed.length - 1];
    if (firstLat !== lastLat || firstLng !== lastLng) {
      closed.push([firstLat, firstLng]);
    }
    return closed;
  };

  const toLngLat = (coords = []) => coords.map(([lat, lng]) => [lng, lat]);
  const toLatLng = (coords = []) => coords.map(([lng, lat]) => [lat, lng]);

  const deepCopy = (value) => JSON.parse(JSON.stringify(value));

  function buildFenceFeature() {
    const coordinates = ensureClosed(FENCE_COORDS);
    const lngLat = toLngLat(coordinates);
    return {
      id: 'FENCE',
      name: 'Perimeter Fence',
      type: 'fence',
      coordinates,
      lngLat,
      turf: turfAvailable ? turf.polygon([lngLat]) : null
    };
  }

  function normaliseGreens(rawGreens = []) {
    return rawGreens.map((entry, index) => {
      const coordinates = ensureClosed(entry.coordinates || []);
      const lngLat = toLngLat(coordinates);
      const polygon = turfAvailable ? turf.polygon([lngLat]) : null;
      const bbox = polygon ? turf.bbox(polygon) : null;
      return {
        id: entry.id || `GREEN_${index + 1}`,
        name: entry.name || `Green Zone ${index + 1}`,
        type: 'green',
        coordinates,
        lngLat,
        turf: polygon,
        bbox
      };
    });
  }

  function buildRedPolygons(fenceLngLat, greens) {
    if (!turfAvailable) return [];
    let base = turf.polygon([fenceLngLat]);
    greens.forEach((green) => {
      if (green.turf) {
        const updated = turf.difference(base, green.turf);
        if (updated) {
          base = updated;
        }
      }
    });

    if (!base) {
      return [];
    }

    const coordinateSets = base.geometry.type === 'Polygon'
      ? [base.geometry.coordinates]
      : base.geometry.coordinates;

    return coordinateSets.map((coords, index) => {
      const latLngRings = coords.map((ring) => toLatLng(ring));
      const polygon = turf.polygon(coords);
      const bbox = turf.bbox(polygon);
      return {
        id: `RED_${index + 1}`,
        name: `Restricted Zone ${index + 1}`,
        type: 'red',
        coordinates: latLngRings,
        lngLat: coords,
        turf: polygon,
        bbox
      };
    });
  }

  function buildHelpers(fence, greens, reds) {
    return {
      pointInFence(lat, lng) {
        if (turfAvailable && fence.turf) {
          return turf.booleanPointInPolygon(turf.point([lng, lat]), fence.turf);
        }
        return false;
      },
      pointInGreen(lat, lng) {
        if (!turfAvailable) return false;
        const point = turf.point([lng, lat]);
        return greens.some((green) => green.turf && turf.booleanPointInPolygon(point, green.turf));
      },
      pointInRed(lat, lng) {
        if (!turfAvailable) {
          return this.pointInFence(lat, lng) && !this.pointInGreen(lat, lng);
        }
        const point = turf.point([lng, lat]);
        if (!reds.length) {
          return this.pointInFence(lat, lng) && !this.pointInGreen(lat, lng);
        }
        return reds.some((red) => red.turf && turf.booleanPointInPolygon(point, red.turf));
      }
    };
  }

  function buildZoneState(rawGreens, metadata) {
    const fence = buildFenceFeature();
    const greens = normaliseGreens(rawGreens);
    const reds = buildRedPolygons(fence.lngLat, greens);
    const helpers = buildHelpers(fence, greens, reds);

    return Object.freeze({
      fence,
      greens,
      reds,
      helpers,
      metadata: {
        ...metadata,
        generatedAt: new Date().toISOString(),
        source: metadata?.source || 'runtime'
      }
    });
  }

  let currentGreenRaw = deepCopy(DEFAULT_GREEN_RAW);
  let currentState = null;
  let currentMode = 'default';

  function dispatchUpdate(detail = {}) {
    if (typeof global.dispatchEvent === 'function') {
      global.dispatchEvent(new CustomEvent('sshr-zones-updated', {
        detail: {
          mode: currentMode,
          ...detail
        }
      }));
    }
  }

  function applyState(state, detail = {}) {
    currentState = state;
    currentMode = detail.mode || currentMode;
    global.SSHR_ZONES = state;
    dispatchUpdate(detail);
  }

  function resetToDefault() {
    currentGreenRaw = deepCopy(DEFAULT_GREEN_RAW);
    const state = buildZoneState(currentGreenRaw, { source: 'default' });
    applyState(state, { mode: 'default', reason: 'reset' });
    return state;
  }

  function setManagementGreens(rawGreens = [], options = {}) {
    if (!Array.isArray(rawGreens) || rawGreens.length === 0) {
      throw new Error('setManagementGreens requires at least one polygon');
    }

    currentGreenRaw = rawGreens.map((zone, idx) => ({
      id: zone.id || `MANAGEMENT_GREEN_${idx + 1}`,
      name: zone.name || `Management Green ${idx + 1}`,
      coordinates: ensureClosed(zone.coordinates || [])
    }));

    const state = buildZoneState(currentGreenRaw, {
      source: 'management',
      count: currentGreenRaw.length,
      ...options
    });

    applyState(state, { mode: 'management', reason: 'set-management', count: currentGreenRaw.length });
    return state;
  }

  function getState() {
    return {
      mode: currentMode,
      greens: deepCopy(currentGreenRaw),
      zones: currentState
    };
  }

  const API = Object.freeze({
    resetToDefault,
    setManagementGreens,
    getState,
    getDefaultGreens: () => deepCopy(DEFAULT_GREEN_RAW),
    getFence: () => deepCopy(FENCE_COORDS)
  });

  global.SSHR_ZONES_API = API;
  resetToDefault();

  console.log('✅ [ZONES] SSHR zone definitions loaded');
})(window);
