// SSHR Dataset Analyzer
// Analyzuje SSHR_DATA1-7.js pro GPS koordináty, pohyb osob a kvalitu dat

// RED FENCE perimeter koordináty (lat, lng)
const RED_FENCE_COORDS = [
    [50.328088307819414, 16.0913477895888],
    [50.33289123277615, 16.096910931466788],
    [50.33247319198437, 16.09789285374428],
    [50.32767573491579, 16.092371852035793],
    [50.328088307819414, 16.0913477895888]
];

// Point-in-polygon algoritmus (Ray casting)
function pointInPolygon(lat, lng, polygon) {
    let inside = false;
    const x = lng;
    const y = lat;

    for (let i = 0, j = polygon.length - 1; i < polygon.length; j = i++) {
        const xi = polygon[i][1]; // longitude
        const yi = polygon[i][0]; // latitude
        const xj = polygon[j][1];
        const yj = polygon[j][0];

        if (((yi > y) !== (yj > y)) && (x < (xj - xi) * (y - yi) / (yj - yi) + xi)) {
            inside = !inside;
        }
    }
    return inside;
}

// Výpočet vzdálenosti mezi dvěma GPS body (Haversine formula)
function calculateDistance(lat1, lng1, lat2, lng2) {
    const R = 6371000; // Poloměr Země v metrech
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLng = (lng2 - lng1) * Math.PI / 180;
    const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
              Math.cos(lat1 * Math.PI/180) * Math.cos(lat2 * Math.PI/180) *
              Math.sin(dLng/2) * Math.sin(dLng/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return R * c; // vzdálenost v metrech
}

// Výpočet rychlosti mezi dvěma body
function calculateSpeed(lat1, lng1, timestamp1, lat2, lng2, timestamp2) {
    const distance = calculateDistance(lat1, lng1, lat2, lng2);
    const time1 = new Date(timestamp1).getTime();
    const time2 = new Date(timestamp2).getTime();
    const timeDiff = Math.abs(time2 - time1) / 1000; // rozdíl v sekundách

    if (timeDiff === 0) return 0;

    const speedMs = distance / timeDiff; // m/s
    const speedKmh = speedMs * 3.6; // km/h

    return {
        distance: distance,
        timeDiff: timeDiff,
        speedMs: speedMs,
        speedKmh: speedKmh
    };
}

// Analýza jednoho datasetu
function analyzeDataset(data, datasetName) {
    console.log(`\n📊 Analýza ${datasetName}`);
    console.log("=" + "=".repeat(50));

    if (!Array.isArray(data) || data.length === 0) {
        console.log("❌ Chyba: Dataset je prázdný nebo není pole");
        return null;
    }

    const results = {
        datasetName: datasetName,
        totalPoints: data.length,
        pointsOutsideFence: [],
        speeds: [],
        anomalies: [],
        timestampIssues: [],
        minSpeed: Infinity,
        maxSpeed: -Infinity,
        avgSpeed: 0
    };

    console.log(`📍 Celkový počet GPS bodů: ${results.totalPoints}`);

    // Kontrola GPS bodů vůči RED FENCE perimetru
    console.log("\n🔍 Kontrola GPS bodů vůči RED FENCE perimetru...");
    for (let i = 0; i < data.length; i++) {
        const point = data[i];
        const isInside = pointInPolygon(point.lat, point.lng, RED_FENCE_COORDS);

        if (!isInside) {
            results.pointsOutsideFence.push({
                index: i,
                timestamp: point.timestamp,
                lat: point.lat,
                lng: point.lng
            });
        }
    }

    console.log(`❌ Počet bodů mimo RED FENCE: ${results.pointsOutsideFence.length}`);
    if (results.pointsOutsideFence.length > 0) {
        console.log("   Detaily bodů mimo perimeter:");
        results.pointsOutsideFence.slice(0, 5).forEach(point => {
            console.log(`   - Index ${point.index}: [${point.lat.toFixed(8)}, ${point.lng.toFixed(8)}] v ${point.timestamp}`);
        });
        if (results.pointsOutsideFence.length > 5) {
            console.log(`   ... a dalších ${results.pointsOutsideFence.length - 5} bodů`);
        }
    }

    // Kontrola timestamps a výpočet rychlostí
    console.log("\n⏱️ Analýza časových razítek a rychlostí...");
    let previousPoint = null;
    let totalSpeed = 0;
    let speedCount = 0;

    for (let i = 0; i < data.length; i++) {
        const currentPoint = data[i];

        // Kontrola timestamp formátu a pořadí
        const currentTime = new Date(currentPoint.timestamp);
        if (isNaN(currentTime.getTime())) {
            results.timestampIssues.push({
                index: i,
                timestamp: currentPoint.timestamp,
                issue: "Neplatný formát časového razítka"
            });
        }

        if (previousPoint) {
            const prevTime = new Date(previousPoint.timestamp);
            if (currentTime < prevTime) {
                results.timestampIssues.push({
                    index: i,
                    timestamp: currentPoint.timestamp,
                    previousTimestamp: previousPoint.timestamp,
                    issue: "Časové razítko není v rostoucím pořadí"
                });
            }

            // Výpočet rychlosti
            const speedData = calculateSpeed(
                previousPoint.lat, previousPoint.lng, previousPoint.timestamp,
                currentPoint.lat, currentPoint.lng, currentPoint.timestamp
            );

            results.speeds.push({
                fromIndex: i-1,
                toIndex: i,
                ...speedData
            });

            totalSpeed += speedData.speedKmh;
            speedCount++;

            if (speedData.speedKmh < results.minSpeed) {
                results.minSpeed = speedData.speedKmh;
            }
            if (speedData.speedKmh > results.maxSpeed) {
                results.maxSpeed = speedData.speedKmh;
            }

            // Detekce anomálních rychlostí (>20 km/h)
            if (speedData.speedKmh > 20) {
                results.anomalies.push({
                    type: "Nereálná rychlost",
                    fromIndex: i-1,
                    toIndex: i,
                    fromTimestamp: previousPoint.timestamp,
                    toTimestamp: currentPoint.timestamp,
                    fromCoords: [previousPoint.lat, previousPoint.lng],
                    toCoords: [currentPoint.lat, currentPoint.lng],
                    speed: speedData.speedKmh,
                    distance: speedData.distance,
                    timeDiff: speedData.timeDiff
                });
            }
        }

        previousPoint = currentPoint;
    }

    results.avgSpeed = speedCount > 0 ? totalSpeed / speedCount : 0;

    console.log(`📈 Rychlosti pohybu:`);
    console.log(`   - Minimální: ${results.minSpeed.toFixed(2)} km/h`);
    console.log(`   - Maximální: ${results.maxSpeed.toFixed(2)} km/h`);
    console.log(`   - Průměrná: ${results.avgSpeed.toFixed(2)} km/h`);

    console.log(`⚠️ Anomálie - rychlosti >20 km/h: ${results.anomalies.length}`);
    if (results.anomalies.length > 0) {
        console.log("   Detaily anomálií:");
        results.anomalies.slice(0, 3).forEach(anomaly => {
            console.log(`   - Index ${anomaly.fromIndex}→${anomaly.toIndex}: ${anomaly.speed.toFixed(2)} km/h`);
            console.log(`     Od: [${anomaly.fromCoords[0].toFixed(8)}, ${anomaly.fromCoords[1].toFixed(8)}] v ${anomaly.fromTimestamp}`);
            console.log(`     Do: [${anomaly.toCoords[0].toFixed(8)}, ${anomaly.toCoords[1].toFixed(8)}] v ${anomaly.toTimestamp}`);
            console.log(`     Vzdálenost: ${anomaly.distance.toFixed(2)}m, Čas: ${anomaly.timeDiff}s`);
        });
        if (results.anomalies.length > 3) {
            console.log(`   ... a dalších ${results.anomalies.length - 3} anomálií`);
        }
    }

    console.log(`🕐 Problémy s časovými razítky: ${results.timestampIssues.length}`);
    if (results.timestampIssues.length > 0) {
        results.timestampIssues.slice(0, 3).forEach(issue => {
            console.log(`   - Index ${issue.index}: ${issue.issue}`);
        });
    }

    // Hodnocení kvality dat
    let qualityScore = 100;
    let qualityIssues = [];

    if (results.pointsOutsideFence.length > 0) {
        const outsideRatio = results.pointsOutsideFence.length / results.totalPoints;
        const penalty = Math.min(outsideRatio * 50, 30);
        qualityScore -= penalty;
        qualityIssues.push(`${results.pointsOutsideFence.length} bodů mimo perimeter (-${penalty.toFixed(1)} bodů)`);
    }

    if (results.anomalies.length > 0) {
        const anomalyRatio = results.anomalies.length / results.totalPoints;
        const penalty = Math.min(anomalyRatio * 100, 40);
        qualityScore -= penalty;
        qualityIssues.push(`${results.anomalies.length} anomálních rychlostí (-${penalty.toFixed(1)} bodů)`);
    }

    if (results.timestampIssues.length > 0) {
        const timestampRatio = results.timestampIssues.length / results.totalPoints;
        const penalty = Math.min(timestampRatio * 50, 20);
        qualityScore -= penalty;
        qualityIssues.push(`${results.timestampIssues.length} problémů s časy (-${penalty.toFixed(1)} bodů)`);
    }

    results.qualityScore = Math.max(qualityScore, 0);
    results.qualityIssues = qualityIssues;

    console.log(`\n🎯 Celkové hodnocení kvality dat: ${results.qualityScore.toFixed(1)}/100`);
    if (qualityIssues.length > 0) {
        console.log("   Důvody snížení skóre:");
        qualityIssues.forEach(issue => console.log(`   - ${issue}`));
    }

    return results;
}

// Hlavní analýza všech datasetů
function runAnalysis() {
    console.log("🚀 SSHR Dataset Analyzer");
    console.log("========================");
    console.log("Začínám analýzu SSHR_DATA1-7.js souborů...");

    const datasets = [
        { name: "SSHR_DATA1", data: window.realData_SSHR_DATA1 },
        { name: "SSHR_DATA2", data: window.realData_SSHR_DATA2 },
        { name: "SSHR_DATA3", data: window.realData_SSHR_DATA3 },
        { name: "SSHR_DATA4", data: window.realData_SSHR_DATA4 },
        { name: "SSHR_DATA5", data: window.realData_SSHR_DATA5 },
        { name: "SSHR_DATA6", data: window.realData_SSHR_DATA6 },
        { name: "SSHR_DATA7", data: window.realData_SSHR_DATA7 }
    ];

    const results = [];

    for (const dataset of datasets) {
        if (dataset.data) {
            const result = analyzeDataset(dataset.data, dataset.name);
            if (result) {
                results.push(result);
            }
        } else {
            console.log(`\n❌ ${dataset.name}: Dataset nenalezen`);
        }
    }

    // Souhrnný report
    console.log("\n\n📋 SOUHRNNÝ REPORT");
    console.log("==================");
    console.log("Dataset\t\t\tBody\tMimo fence\tAnomélie\tKvalita");
    console.log("-".repeat(75));

    results.forEach(result => {
        const name = result.datasetName.padEnd(20);
        const points = result.totalPoints.toString().padStart(6);
        const outside = result.pointsOutsideFence.length.toString().padStart(6);
        const anomalies = result.anomalies.length.toString().padStart(6);
        const quality = result.qualityScore.toFixed(1).padStart(6);
        console.log(`${name}\t${points}\t${outside}\t\t${anomalies}\t\t${quality}/100`);
    });

    // Celkové statistiky
    if (results.length > 0) {
        const totalPoints = results.reduce((sum, r) => sum + r.totalPoints, 0);
        const totalOutside = results.reduce((sum, r) => sum + r.pointsOutsideFence.length, 0);
        const totalAnomalies = results.reduce((sum, r) => sum + r.anomalies.length, 0);
        const avgQuality = results.reduce((sum, r) => sum + r.qualityScore, 0) / results.length;

        console.log("-".repeat(75));
        console.log(`CELKEM\t\t\t${totalPoints}\t${totalOutside}\t\t${totalAnomalies}\t\t${avgQuality.toFixed(1)}/100`);

        console.log(`\n🎯 Celkové hodnocení:`);
        console.log(`- Analyzováno datasetů: ${results.length}`);
        console.log(`- Celkový počet GPS bodů: ${totalPoints.toLocaleString()}`);
        console.log(`- Celkový počet bodů mimo perimeter: ${totalOutside} (${(totalOutside/totalPoints*100).toFixed(2)}%)`);
        console.log(`- Celkový počet anomálních rychlostí: ${totalAnomalies} (${(totalAnomalies/totalPoints*100).toFixed(2)}%)`);
        console.log(`- Průměrná kvalita dat: ${avgQuality.toFixed(1)}/100`);

        if (avgQuality >= 90) {
            console.log("✅ Vynikající kvalita dat");
        } else if (avgQuality >= 70) {
            console.log("✅ Dobrá kvalita dat");
        } else if (avgQuality >= 50) {
            console.log("⚠️ Průměrná kvalita dat - doporučeny opravy");
        } else {
            console.log("❌ Nízká kvalita dat - nutné opravy");
        }
    }

    return results;
}

// Export pro použití
window.SSHRAnalyzer = {
    runAnalysis: runAnalysis,
    analyzeDataset: analyzeDataset,
    pointInPolygon: pointInPolygon,
    calculateSpeed: calculateSpeed
};

console.log("📍 SSHR Dataset Analyzer načten. Spusťte analýzu pomocí: SSHRAnalyzer.runAnalysis()");