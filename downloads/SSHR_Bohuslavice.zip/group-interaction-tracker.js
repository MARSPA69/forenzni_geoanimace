/**
 * GroupInteractionTracker - Sledování interakcí mezi osobami v SSHR systému
 * Sleduje kdy se osoby přiblíží (≤5m) a vytváří skupiny, zaznamenává kdo se připojí/odpojí
 */

class GroupInteractionTracker {
  constructor() {
    this.activeGroups = new Map(); // groupId -> groupData
    this.interactionHistory = new Map(); // personId -> [interaction records]
    this.proximityThreshold = 5; // metry
    this.groupSizeThreshold = 2; // minimální velikost skupiny
    this.groupIdCounter = 1;
    this.maxHistoryPerPerson = 100;
    this.closeContactConfig = {
      distance: 3,         // ≤3 m
      minDurationMs: 5000  // ≥5 s
    };
    this.activeCloseContacts = new Map(); // key -> contactData

    console.log('👥 [GROUP-INTERACTION-TRACKER] Initialized');
  }

  /**
   * Hlavní metoda volaná při každém ticku PersonTrackeru
   */
  processTick(persons, timestamp) {
    if (!persons || persons.length === 0) return;

    // Spočítat všechny párové vzdálenosti
    const proximities = this.calculateProximities(persons);
    const personLookup = new Map();
    persons.forEach(person => {
      if (person?.id) {
        personLookup.set(person.id, person);
      }
    });

    // Najít skupiny osob v blízkosti
    const currentGroups = this.findGroups(proximities, timestamp);

    // Aktualizovat aktivní skupiny
    this.updateActiveGroups(currentGroups, timestamp);

    // Vyčistit neaktivní skupiny
    this.cleanupInactiveGroups(timestamp);

    // Vyhodnotit těsné kontakty (≤3 m, ≥5 s)
    const tightProximities = proximities.filter(prox => prox.distance <= this.closeContactConfig.distance);
    this.updateCloseContacts(tightProximities, personLookup, timestamp);

    return {
      activeGroupsCount: this.activeGroups.size,
      currentProximities: proximities.length
    };
  }

  /**
   * Spočítá vzdálenosti mezi všemi páry osob
   */
  calculateProximities(persons) {
    const proximities = [];

    for (let i = 0; i < persons.length; i++) {
      for (let j = i + 1; j < persons.length; j++) {
        const personA = persons[i];
        const personB = persons[j];

        if (!personA.position || !personB.position) continue;

        const distance = this.calculateDistance(
          personA.position.lat, personA.position.lng,
          personB.position.lat, personB.position.lng
        );

        if (distance <= this.proximityThreshold) {
          proximities.push({
            personA: personA.id,
            personB: personB.id,
            datasetA: personA.datasetName,
            datasetB: personB.datasetName,
            distance,
            locationA: personA.position,
            locationB: personB.position,
            anchorA: personA.lastActiveAnchor || null,
            anchorB: personB.lastActiveAnchor || null
          });
        }
      }
    }

    return proximities;
  }

  /**
   * Najde skupiny na základě blízkosti
   */
  findGroups(proximities, timestamp) {
    if (proximities.length === 0) return [];

    // Vytvořit graf souvislostí
    const connections = new Map();
    proximities.forEach(prox => {
      if (!connections.has(prox.personA)) connections.set(prox.personA, new Set());
      if (!connections.has(prox.personB)) connections.set(prox.personB, new Set());

      connections.get(prox.personA).add(prox.personB);
      connections.get(prox.personB).add(prox.personA);
    });

    // Najít connected components (skupiny)
    const visited = new Set();
    const groups = [];

    for (const [personId, neighbors] of connections) {
      if (visited.has(personId)) continue;

      const group = this.findConnectedComponent(personId, connections, visited);
      if (group.length >= this.groupSizeThreshold) {
        groups.push({
          members: group,
          proximities: proximities.filter(p =>
            group.includes(p.personA) && group.includes(p.personB)
          ),
          timestamp
        });
      }
    }

    return groups;
  }

  /**
   * Najde všechny propojené osoby (DFS)
   */
  findConnectedComponent(startPerson, connections, visited) {
    const component = [];
    const stack = [startPerson];

    while (stack.length > 0) {
      const person = stack.pop();
      if (visited.has(person)) continue;

      visited.add(person);
      component.push(person);

      const neighbors = connections.get(person) || new Set();
      for (const neighbor of neighbors) {
        if (!visited.has(neighbor)) {
          stack.push(neighbor);
        }
      }
    }

    return component;
  }

  /**
   * Aktualizuje aktivní skupiny
   */
  updateActiveGroups(currentGroups, timestamp) {
    // Porovnat s existujícími skupinami
    const newGroupIds = new Set();

    currentGroups.forEach(currentGroup => {
      const existingGroupId = this.findMatchingGroup(currentGroup.members);

      if (existingGroupId) {
        // Skupina už existuje - aktualizovat
        const existingGroup = this.activeGroups.get(existingGroupId);
        this.updateExistingGroup(existingGroup, currentGroup, timestamp);
        newGroupIds.add(existingGroupId);
      } else {
        // Nová skupina - vytvořit
        const newGroupId = this.createNewGroup(currentGroup, timestamp);
        newGroupIds.add(newGroupId);
      }
    });

    // Označit skupiny, které už nejsou aktivní
    for (const [groupId, group] of this.activeGroups) {
      if (!newGroupIds.has(groupId)) {
        this.endGroup(groupId, timestamp);
      }
    }
  }

  /**
   * Najde existující skupinu se stejnými členy
   */
  findMatchingGroup(members) {
    const memberSet = new Set(members);

    for (const [groupId, group] of this.activeGroups) {
      if (group.status !== 'active') continue;

      const existingSet = new Set(group.currentMembers);
      if (this.setsEqual(memberSet, existingSet)) {
        return groupId;
      }
    }

    return null;
  }

  /**
   * Aktualizuje existující skupinu
   */
  updateExistingGroup(existingGroup, currentGroup, timestamp) {
    existingGroup.lastUpdate = timestamp;
    existingGroup.tickCount++;

    // Zkontrolovat změny ve členech
    const oldMembers = new Set(existingGroup.currentMembers);
    const newMembers = new Set(currentGroup.members);

    // Nové členy
    for (const member of newMembers) {
      if (!oldMembers.has(member)) {
        existingGroup.events.push({
          type: 'member-joined',
          personId: member,
          timestamp,
          members: [...newMembers]
        });
        console.log(`👥 [GROUP-INTERACTION] Person ${member} joined group ${existingGroup.id}`);
      }
    }

    // Odešlí členy
    for (const member of oldMembers) {
      if (!newMembers.has(member)) {
        existingGroup.events.push({
          type: 'member-left',
          personId: member,
          timestamp,
          members: [...newMembers]
        });
        console.log(`👥 [GROUP-INTERACTION] Person ${member} left group ${existingGroup.id}`);
      }
    }

    existingGroup.currentMembers = currentGroup.members;
    existingGroup.proximities = currentGroup.proximities;
  }

  /**
   * Vytvoří novou skupinu
   */
  createNewGroup(groupData, timestamp) {
    const groupId = `group-${this.groupIdCounter++}`;

    const group = {
      id: groupId,
      startTime: timestamp,
      lastUpdate: timestamp,
      currentMembers: groupData.members,
      proximities: groupData.proximities,
      status: 'active',
      tickCount: 1,
      events: [{
        type: 'group-formed',
        timestamp,
        members: groupData.members
      }],
      anchorContext: this.extractAnchorContext(groupData.proximities),
      infraContext: null // TODO: přidat později
    };

    this.activeGroups.set(groupId, group);

    console.log(`👥 [GROUP-INTERACTION] New group formed: ${groupId}`, {
      members: groupData.members,
      size: groupData.members.length
    });

    return groupId;
  }

  /**
   * Ukončí skupinu
   */
  endGroup(groupId, timestamp) {
    const group = this.activeGroups.get(groupId);
    if (!group || group.status !== 'active') return;

    group.status = 'ended';
    group.endTime = timestamp;
    group.duration = (timestamp - group.startTime) / 1000; // sekundy

    group.events.push({
      type: 'group-ended',
      timestamp,
      duration: group.duration
    });

    // Přesunout do historie pro každého člena
    group.currentMembers.forEach(personId => {
      this.recordInteractionHistory(personId, group);
    });

    // Odeslat na NAS přes MQTT
    if (window.SSHR?.mqttClient) {
      window.SSHR.mqttClient.publishGroupInteraction({
        type: 'group-ended',
        groupId,
        group: {
          startTime: group.startTime,
          endTime: group.endTime,
          duration: group.duration,
          members: group.currentMembers,
          events: group.events,
          anchorContext: group.anchorContext
        }
      }).catch(error => {
        console.error('❌ [GROUP-INTERACTION] Failed to publish group interaction to NAS:', error);
      });
    }

    console.log(`👥 [GROUP-INTERACTION] Group ended: ${groupId}`, {
      duration: group.duration,
      members: group.currentMembers
    });

    // Ponechat v activeGroups s status 'ended' pro debugování
    // Vyčištění proběhne v cleanupInactiveGroups
  }

  /**
   * Zaznamenává interakci do historie osoby
   */
  recordInteractionHistory(personId, group) {
    if (!this.interactionHistory.has(personId)) {
      this.interactionHistory.set(personId, []);
    }

    const history = this.interactionHistory.get(personId);
    const interaction = {
      groupId: group.id,
      startTime: group.startTime,
      endTime: group.endTime,
      duration: group.duration,
      members: [...group.currentMembers],
      otherMembers: group.currentMembers.filter(id => id !== personId),
      anchorContext: group.anchorContext,
      infraContext: group.infraContext,
      events: group.events
    };

    history.push(interaction);

    // Omezit velikost historie
    if (history.length > this.maxHistoryPerPerson) {
      history.splice(0, history.length - this.maxHistoryPerPerson);
    }

    this.interactionHistory.set(personId, history);
  }

  /**
   * Vyčistí neaktivní skupiny (starší než 30 sekund)
   */
  cleanupInactiveGroups(timestamp) {
    const cleanupThreshold = 30000; // 30 sekund

    for (const [groupId, group] of this.activeGroups) {
      if (group.status === 'ended' &&
          (timestamp - group.endTime) > cleanupThreshold) {
        this.activeGroups.delete(groupId);
        console.log(`🧹 [GROUP-INTERACTION] Cleaned up old group: ${groupId}`);
      }
    }
  }

  /**
   * Close contact detection (≤3 m, ≥5 s)
   */
  updateCloseContacts(tightProximities, personLookup, timestamp) {
    const currentKeys = new Set();

    if (tightProximities.length > 0) {
      const closeGroups = this.findGroups(tightProximities, timestamp);
      closeGroups.forEach(group => {
        if (!Array.isArray(group.members) || group.members.length < 2) {
          return;
        }

        const key = this.getCloseContactKey(group.members);
        currentKeys.add(key);
        const centroid = this.computeCentroid(group.members, personLookup);
        if (!centroid) {
          return;
        }

        const participants = group.members.map((memberId, index) => {
          const person = personLookup.get(memberId) || {};
          const label = person.datasetName || person.name || `Osoba ${memberId}`;
          return {
            id: memberId,
            dataset: person.datasetName || null,
            label,
            order: index
          };
        });

        const existing = this.activeCloseContacts.get(key);
        if (existing) {
          existing.lastUpdate = timestamp;
          existing.centroid = centroid;
          existing.participants = participants;
          existing.members = group.members;
          existing.durationSeconds = (timestamp - existing.startedAt) / 1000;

          if (!existing.reported &&
              (timestamp - existing.startedAt) >= this.closeContactConfig.minDurationMs) {
            existing.reported = true;
            this.emitCloseContactEvent('started', existing);
          } else if (existing.reported) {
            this.emitCloseContactEvent('updated', existing);
          }
        } else {
          this.activeCloseContacts.set(key, {
            id: key,
            members: group.members,
            participants,
            centroid,
            startedAt: timestamp,
            lastUpdate: timestamp,
            durationSeconds: 0,
            reported: false
          });
        }
      });
    }

    // Cleanup stale contacts
    for (const [key, contact] of this.activeCloseContacts.entries()) {
      if (!currentKeys.has(key)) {
        this.finalizeCloseContact(key, contact, timestamp);
      }
    }
  }

  computeCentroid(memberIds, personLookup) {
    if (!Array.isArray(memberIds) || memberIds.length === 0) {
      return null;
    }
    let latSum = 0;
    let lngSum = 0;
    let count = 0;

    memberIds.forEach(id => {
      const person = personLookup.get(id);
      const position = person?.position;
      if (position && Number.isFinite(position.lat) && Number.isFinite(position.lng)) {
        latSum += position.lat;
        lngSum += position.lng;
        count++;
      }
    });

    if (!count) {
      return null;
    }

    return {
      lat: latSum / count,
      lng: lngSum / count
    };
  }

  finalizeCloseContact(key, contact, timestamp) {
    if (!contact) {
      this.activeCloseContacts.delete(key);
      return;
    }

    contact.lastUpdate = timestamp;
    contact.durationSeconds = (timestamp - contact.startedAt) / 1000;

    if (contact.reported) {
      this.emitCloseContactEvent('ended', contact);
    }

    this.activeCloseContacts.delete(key);
  }

  emitCloseContactEvent(eventType, contact) {
    if (typeof window === 'undefined' || !contact) return;
    window.dispatchEvent(new CustomEvent(`sshr-close-contact-${eventType}`, {
      detail: {
        id: contact.id,
        members: contact.members,
        participants: contact.participants,
        centroid: contact.centroid,
        startedAt: contact.startedAt,
        lastUpdate: contact.lastUpdate,
        durationSeconds: contact.durationSeconds,
        size: contact.members.length
      }
    }));
  }

  getCloseContactKey(members) {
    return members.slice().sort().join('::');
  }

  /**
   * Pomocné metody
   */
  calculateDistance(lat1, lng1, lat2, lng2) {
    const R = 6371000; // Poloměr Země v metrech
    const dLat = this.toRad(lat2 - lat1);
    const dLng = this.toRad(lng2 - lng1);
    const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
              Math.cos(this.toRad(lat1)) * Math.cos(this.toRad(lat2)) *
              Math.sin(dLng/2) * Math.sin(dLng/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return R * c;
  }

  toRad(deg) {
    return deg * (Math.PI / 180);
  }

  setsEqual(setA, setB) {
    return setA.size === setB.size && [...setA].every(x => setB.has(x));
  }

  extractAnchorContext(proximities) {
    const anchors = new Set();
    proximities.forEach(p => {
      if (p.anchorA) anchors.add(p.anchorA);
      if (p.anchorB) anchors.add(p.anchorB);
    });
    return anchors.size > 0 ? Array.from(anchors) : null;
  }

  /**
   * API metody pro reporty
   */
  getPersonInteractionHistory(personId) {
    return this.interactionHistory.get(personId) || [];
  }

  getActiveGroups() {
    return Array.from(this.activeGroups.values()).filter(g => g.status === 'active');
  }

  getPersonGroupContext(personId) {
    if (!personId) return null;

    for (const group of this.activeGroups.values()) {
      if (group.status === 'active' && Array.isArray(group.currentMembers) && group.currentMembers.includes(personId)) {
        return {
          groupId: group.id,
          size: group.currentMembers.length,
          members: [...group.currentMembers],
          startedAt: group.startTime,
          anchorContext: group.anchorContext || null
        };
      }
    }

    const history = this.interactionHistory.get(personId);
    if (history && history.length > 0) {
      const latest = history[history.length - 1];
      return {
        groupId: latest.groupId || null,
        size: latest.members.length,
        members: [...latest.members],
        lastInteractionEndedAt: latest.endTime,
        lastDuration: latest.duration
      };
    }

    return null;
  }

  getPersonInteractionSummary(personId) {
    const history = this.getPersonInteractionHistory(personId);

    return {
      totalInteractions: history.length,
      totalInteractionTime: history.reduce((sum, i) => sum + i.duration, 0),
      uniquePeople: new Set(history.flatMap(i => i.otherMembers)).size,
      averageGroupSize: history.length > 0 ?
        history.reduce((sum, i) => sum + i.members.length, 0) / history.length : 0,
      longestInteraction: history.length > 0 ?
        Math.max(...history.map(i => i.duration)) : 0,
      interactions: history
    };
  }

  getAllPersonsWithInteractions() {
    const persons = [];
    for (const personId of this.interactionHistory.keys()) {
      persons.push({
        personId,
        summary: this.getPersonInteractionSummary(personId)
      });
    }
    return persons;
  }

  /**
   * Diagnostika
   */
  getDebugInfo() {
    return {
      activeGroups: this.activeGroups.size,
      personsWithHistory: this.interactionHistory.size,
      totalInteractions: Array.from(this.interactionHistory.values())
        .reduce((sum, history) => sum + history.length, 0),
      currentActiveGroups: this.getActiveGroups()
    };
  }
}

// Globální instance
window.SSHR = window.SSHR || {};
window.SSHR.groupInteractionTracker = new GroupInteractionTracker();

console.log('👥 [GROUP-INTERACTION-TRACKER] Global instance created at window.SSHR.groupInteractionTracker');
