/**
 * Incident Engine for SSHR Bohuslavice
 * ====================================
 *
 * Bridges raw position updates to the higher-level IncidentManager while
 * respecting the current polygon configuration (FIXED/FLOAT) provided by
 * SSHRPolygonManager. This keeps the renderer lean and aligns the structure
 * with the mature CEPRO implementation.
 */

(function registerIncidentEngine(global) {
  function now() {
    return new Date();
  }

  function toGeoPoint(lat, lng) {
    if (typeof turf === 'undefined') {
      return null;
    }
    return turf.point([lng, lat]);
  }

  /**
   * When the polygon manager is not initialised yet, fall back to static zones
   * declared in renderer_SSHR_Bohuslavice.js (window.SSHR_ZONES).
   */
  function fallbackZoneCheck(lat, lng, zoneDataset = null) {
    const result = {
      type: 'neutral',
      zone: null
    };

    if (typeof turf === 'undefined') {
      return result;
    }

    const dataset = zoneDataset || global.SSHR_ZONES;
    if (!dataset) {
      return result;
    }

    const fence = dataset.fence;
    const greens = dataset.greens || [];
    const reds = dataset.reds || [];
    const point = turf.point([lng, lat]);

    // BUSINESS LOGIC: RED = Fence area MINUS GREEN zones
    // 1. First check if in GREEN zones (highest priority)
    if (greens.length) {
      for (const zone of greens) {
        if (!zone?.lngLat) continue;
        const greenPolygon = zone.turf || turf.polygon([zone.lngLat]);
        if (turf.booleanPointInPolygon(point, greenPolygon)) {
          result.type = 'green';
          result.zone = zone;
          console.log(`🟢 [INCIDENT-ENGINE] Point in GREEN zone: ${zone.name || 'Unnamed'}`);
          return result;
        }
      }
    }

    // 2. If not in GREEN, check if inside fence perimeter = RED zone
    if (fence?.lngLat) {
      const fencePoly = fence.turf || turf.polygon([fence.lngLat]);
      if (turf.booleanPointInPolygon(point, fencePoly)) {
        result.type = 'red';
        result.zone = fence;
        console.log(`🔴 [INCIDENT-ENGINE] Point in RED zone: inside fence but not in GREEN`);
        return result;
      }
    }

    // 3. Explicit RED zones (legacy - normally not used with fence logic)
    if (reds.length) {
      for (const zone of reds) {
        if (!zone?.lngLat) continue;
        const redPolygon = zone.turf || turf.polygon(zone.lngLat);
        if (turf.booleanPointInPolygon(point, redPolygon)) {
          result.type = 'red';
          result.zone = zone;
          console.log(`🔴 [INCIDENT-ENGINE] Point in explicit RED zone: ${zone.name || 'Unnamed'}`);
          return result;
        }
      }
    }

    // 4. Outside fence = neutral
    console.log(`⚪ [INCIDENT-ENGINE] Point outside all zones (neutral)`);
    return result;
  }

function getTrackedPerson(personId) {
  if (!personId) {
    return null;
  }

  const tracker = global.SSHR?.personTracker || global.personTracker || null;
  if (!tracker) {
    return null;
  }

  if (typeof tracker.getPerson === 'function') {
    return tracker.getPerson(personId);
  }

  if (tracker.persons) {
    if (typeof tracker.persons.get === 'function') {
      return tracker.persons.get(personId) || null;
    }
    if (Array.isArray(tracker.persons)) {
      return tracker.persons.find(p => p.id === personId) || null;
    }
  }

  return null;
}

  class IncidentEngine {
    constructor() {
      this.polygonManager = null;
      this.incidentManager = null;
      this.activeIncidents = new Map(); // personId -> incidentState
      this.eventTarget = document.createElement('div');
      this.currentLayout = null;
      this.referenceZones = global.SSHR_ZONES || null;
      this.zonesMeta = this.referenceZones
        ? { source: 'global-init', updatedAt: now(), layoutId: null }
        : { source: 'uninitialised', updatedAt: null, layoutId: null };
      this.preferPolygonManager = false;
    }

    initialise(options = {}) {
      this.polygonManager = options.polygonManager ?? this.polygonManager;
      this.incidentManager = options.incidentManager ?? this.incidentManager;

      console.log('🛡️ [INCIDENT-ENGINE] Initialised', {
        hasPolygonManager: Boolean(this.polygonManager),
        hasIncidentManager: Boolean(this.incidentManager)
      });

      if (this.polygonManager) {
        this.preferPolygonManager = true;
      }

      if (!this.referenceZones && global.SSHR_ZONES) {
        this.referenceZones = global.SSHR_ZONES;
        this.zonesMeta = { source: 'global-init', updatedAt: now(), layoutId: null };
      }

      if (this.polygonManager && typeof this.polygonManager.getActiveLayout === 'function') {
        const layout = this.polygonManager.getActiveLayout();
        if (layout) {
          this.setLayoutContext(layout);
        }
      }
    }

    setLayoutContext(layout) {
      if (!layout) {
        this.currentLayout = null;
        if (this.zonesMeta) {
          this.zonesMeta.layoutId = null;
        }
        console.log('🧭 [INCIDENT-ENGINE] Layout context cleared');
        return;
      }
      this.currentLayout = layout;
      if (this.zonesMeta) {
        this.zonesMeta.layoutId = layout.id ?? null;
      }
      console.log('🧭 [INCIDENT-ENGINE] Layout context updated', {
        id: layout.id,
        mode: layout.mode,
        confirmedAt: layout.confirmedAt
      });
    }

    on(eventName, listener) {
      this.eventTarget.addEventListener(eventName, listener);
    }

    off(eventName, listener) {
      this.eventTarget.removeEventListener(eventName, listener);
    }

    emit(eventName, detail = {}) {
      this.eventTarget.dispatchEvent(new CustomEvent(eventName, { detail }));
    }

    /**
     * Update internal fallback dataset for zone checks (used when polygonManager unavailable)
     */
    updateZones(greens, options = {}) {
      if (Array.isArray(greens) && greens.length) {
        const fence = options.fence || global.SSHR_ZONES?.fence || null;
        const reds = options.reds || global.SSHR_ZONES?.reds || [];
        this.referenceZones = { fence, greens, reds };
        this.zonesMeta = {
          source: options.source || 'management-ui',
          updatedAt: now(),
          layoutId: options.layoutId ?? this.currentLayout?.id ?? null
        };
      } else if (global.SSHR_ZONES) {
        this.referenceZones = global.SSHR_ZONES;
        this.zonesMeta = {
          source: options.source || 'global-sync',
          updatedAt: now(),
          layoutId: options.layoutId ?? this.currentLayout?.id ?? null
        };
      }

      console.log('📦 [INCIDENT-ENGINE] Reference zones updated', this.zonesMeta);
      return this.referenceZones;
    }

    /**
     * Core evaluation entry-point called from ParallelEngine or other motion
     * sources to keep incident state in sync with current positions.
     */
    evaluatePosition(payload = {}) {
      const {
        personId,
        lat,
        lng,
        timestamp = now(),
        dataset = null,
        sample = null,
        zoneStatus = null
      } = payload;

      if (!personId || !Number.isFinite(lat) || !Number.isFinite(lng)) {
        return;
      }

      // Use zone status from authoritative source (info panel) if available
      let isInRedZone = false;
      let isInGreenZone = false;
      let zoneInfo = null;

      if (zoneStatus) {
        isInRedZone = zoneStatus.inRed === true;
        isInGreenZone = zoneStatus.inGreen === true;
        console.log(`🔍 [INCIDENT-ENGINE] Person ${personId} zone status: inGreen=${isInGreenZone}, inRed=${isInRedZone}`);
      } else {
        // Fallback to own detection if zone status not provided
        zoneInfo = this.getZoneInfo(lat, lng);
        isInRedZone = zoneInfo.type === 'red';
        isInGreenZone = zoneInfo.type === 'green';
        console.log(`⚠️ [INCIDENT-ENGINE] Person ${personId} using fallback detection: inGreen=${isInGreenZone}, inRed=${isInRedZone}`);
      }

      const activeIncident = this.getActiveIncidentState(personId);

      // Position evaluation - debug log removed for performance

      if (isInRedZone) {
        if (!activeIncident) {
          console.log(`🚨 [INCIDENT-ENGINE] Starting incident for person ${personId}: RED zone entry`);
          this.startIncident(personId, { lat, lng, timestamp, dataset, sample, isInRedZone, isInGreenZone, zoneInfo });
        } else {
          // update last seen timestamp/position while still in violation.
          activeIncident.lastSample = { lat, lng, timestamp, dataset, sample, isInRedZone, isInGreenZone };

          let distanceMeters = null;
          if (typeof turf !== 'undefined' && activeIncident.entryPoint) {
            const startPoint = turf.point([activeIncident.entryPoint.lng, activeIncident.entryPoint.lat]);
            const currentPoint = turf.point([lng, lat]);
            distanceMeters = turf.distance(startPoint, currentPoint, { units: 'meters' });
            if (Number.isFinite(distanceMeters) && distanceMeters > (activeIncident.maxDistanceMeters || 0)) {
              activeIncident.maxDistanceMeters = distanceMeters;
              activeIncident.maxDistanceSample = { lat, lng, timestamp, zoneInfo, dataset, sample };
            }
          }

          if (window.SSHR?.incidentRegistry) {
            const updatePayload = {
              sample: { lat, lng, timestamp, zoneInfo, dataset, sample }
            };
            if (typeof distanceMeters === 'number' && Number.isFinite(distanceMeters)) {
              updatePayload.distance = distanceMeters;
            }
            window.SSHR.incidentRegistry.updateActiveIncident(personId, updatePayload);
          }

          this.activeIncidents.set(personId, activeIncident);
        }
      } else if (activeIncident) {
        console.log(`✅ [INCIDENT-ENGINE] Resolving incident for person ${personId}: GREEN zone entry`);
        this.resolveIncident(personId, { lat, lng, timestamp, dataset, sample, isInRedZone, isInGreenZone });
      } else if (isInGreenZone) {
        // Mark person as seen GREEN zone to enable incident counting
        if (window.SSHR?.incidentRegistry) {
          window.SSHR.incidentRegistry.markPersonSeenGreenZone(personId);
        }
      }
    }

    getZoneInfo(lat, lng) {
      if (this.polygonManager && typeof this.polygonManager.getZoneTypeForPoint === 'function') {
        const info = this.polygonManager.getZoneTypeForPoint(lat, lng);
        if (info && info.type) {
          return info;
        }
      }

      return fallbackZoneCheck(lat, lng, this.referenceZones);
    }

    getActiveIncidentState(personId) {
      let state = this.activeIncidents.get(personId) || null;
      if (!state && window.SSHR?.incidentRegistry?.getActiveIncident) {
        const registryActive = window.SSHR.incidentRegistry.getActiveIncident(personId);
        if (registryActive) {
          state = this.hydrateActiveIncidentFromRegistry(registryActive);
          if (state) {
            this.activeIncidents.set(personId, state);
          }
        }
      }
      return state;
    }

    hydrateActiveIncidentFromRegistry(registryIncident) {
      if (!registryIncident) {
        return null;
      }
      const startTime = registryIncident.startTime ? new Date(registryIncident.startTime) : now();
      const startSample = registryIncident.startSample || {
        lat: registryIncident.startGPS?.lat,
        lng: registryIncident.startGPS?.lng,
        timestamp: startTime
      };

      return {
        personId: registryIncident.personId,
        incidentId: registryIncident.id,
        dataset: registryIncident.dataset || null,
        startedAt: startTime,
        entryPoint: {
          lat: startSample.lat,
          lng: startSample.lng,
          timestamp: startTime
        },
        startSample,
        lastSample: registryIncident.lastSample || startSample,
        maxDistanceMeters: registryIncident.maxDistance || 0,
        maxDistanceSample: registryIncident.maxDistanceSample || startSample,
        layoutId: registryIncident.layoutId || this.currentLayout?.id || null,
        zoneInfo: registryIncident.zoneInfo || null
      };
    }

    createLocalIncidentState(personId, context, incidentId = null) {
      const timestamp = context.timestamp || now();
      const startSample = context.sample || {
        lat: context.lat,
        lng: context.lng,
        timestamp
      };

      return {
        personId,
        incidentId,
        dataset: context.dataset || null,
        startedAt: timestamp,
        entryPoint: {
          lat: context.lat,
          lng: context.lng,
          timestamp
        },
        startSample,
        lastSample: startSample,
        maxDistanceMeters: 0,
        maxDistanceSample: startSample,
        layoutId: this.currentLayout?.id || null,
        zoneInfo: context.zoneInfo || null
      };
    }

    startIncident(personId, context) {
      console.log(`🚨 [INCIDENT-ENGINE] Starting incident for ${personId}: RED zone entry`);
      const {
        lat,
        lng,
        timestamp,
        dataset,
        sample,
        isInRedZone,
        isInGreenZone,
        zoneInfo = null
      } = context;

      const layoutId = this.currentLayout?.id || null;

      // Získat movement type z PersonTrackeru pro registry
      let movementType = null;
      let anchorId = null;
      const trackedPerson = getTrackedPerson(personId);
      if (trackedPerson) {
        movementType = trackedPerson.movementType || null;
        anchorId = trackedPerson.lastActiveAnchor || null;
      }

      // Delegovat na IncidentRegistry
      if (window.SSHR?.incidentRegistry) {
        const registryContext = {
          timestamp: context.timestamp,
          lat: context.lat,
          lng: context.lng,
          movementType,
          anchorId,
          dataset: context.dataset
        };

        const startedIncident = window.SSHR.incidentRegistry.startIncident(personId, registryContext);

        if (startedIncident) {
          // Legacy incident manager acknowledgement
          if (this.incidentManager) {
            try {
              this.incidentManager.acknowledgeIncident(startedIncident.id, 'IncidentEngine');
            } catch (err) {
              console.error('❌ [INCIDENT-ENGINE] Failed to acknowledge incident', err);
            }
          }

          const localState = this.createLocalIncidentState(personId, context, startedIncident.id);
          this.activeIncidents.set(personId, localState);

          this.emit('incident-start', {
            personId,
            incident: startedIncident,
            dataset: startedIncident.dataset,
            startSample: {
              lat: startedIncident.startGPS.lat,
              lng: startedIncident.startGPS.lng,
              GPS_lat: startedIncident.startGPS.lat,
              GPS_lng: startedIncident.startGPS.lng,
              timestamp: startedIncident.startTime
            }
          });

          console.log('🚨 [INCIDENT-ENGINE] Zone violation started via IncidentRegistry', {
            personId,
            incidentId: startedIncident.id,
            startTime: startedIncident.startTime
          });

          return startedIncident;
        }
      } else {
        console.error('❌ [INCIDENT-ENGINE] IncidentRegistry not available - falling back to legacy behavior');
        // Fallback na původní logiku
        return this.legacyResolveIncident(personId, context);
      }
    }

    resolveIncident(personId, context) {
      const {
        lat,
        lng,
        timestamp,
        dataset,
        sample,
        isInRedZone,
        isInGreenZone
      } = context;

      // Delegovat na IncidentRegistry
      if (window.SSHR?.incidentRegistry) {
        const registryContext = {
          timestamp: context.timestamp,
          lat: context.lat,
          lng: context.lng,
          dataset: context.dataset
        };

        const resolvedIncident = window.SSHR.incidentRegistry.resolveIncident(personId, registryContext);

        if (resolvedIncident) {
          console.log('✅ [INCIDENT-ENGINE] Incident resolved via IncidentRegistry', {
            personId,
            incidentId: resolvedIncident.id,
            duration: resolvedIncident.duration
          });
          this.activeIncidents.delete(personId);
          return resolvedIncident;
        }
      } else {
        console.error('❌ [INCIDENT-ENGINE] IncidentRegistry not available - falling back to legacy behavior');
        // Fallback na původní logiku
        return this.legacyResolveIncident(personId, context);
      }
    }

    // LEGACY FALLBACK METODY - pouze pro případ selhání IncidentRegistry

    legacyStartIncident(personId, context) {
      const {
        lat,
        lng,
        timestamp,
        zoneInfo,
        dataset,
        sample
      } = context;

      const layoutId = this.currentLayout?.id || null;
      const message = zoneInfo.zone?.name
        ? `Osoba ${personId} vstoupila do zakázané zóny (${zoneInfo.zone.name})`
        : `Osoba ${personId} vstoupila do zakázané zóny`;

      let incidentRecord = null;
      if (this.incidentManager && typeof this.incidentManager.handleIncident === 'function') {
        incidentRecord = this.incidentManager.handleIncident({
          type: 'zone-violation',
          person: personId,
          message,
          priority: 'high',
          location: { lat, lng },
          dataset
        });
      }

      const incidentState = {
        personId,
        startedAt: timestamp,
        dataset,
        startSample: sample,
        lastSample: context,
        entryPoint: { lat, lng, timestamp },
        maxDistanceMeters: 0,
        maxDistanceSample: context,
        incidentId: incidentRecord?.id ?? null,
        layoutId,
        zoneInfo
      };

      this.activeIncidents.set(personId, incidentState);

      if (window.SSHR?.cardManager?.recordIncident) {
        window.SSHR.cardManager.recordIncident(dataset, {
          type: 'zone-violation-start',
          startTime: timestamp,
          startGPS: { lat, lng },
          zone: zoneInfo.zone?.name,
          message: message,
          layoutId
        });
      }

      this.emit('incident-start', {
        personId,
        zone: zoneInfo.zone,
        timestamp,
        dataset,
        layoutId,
        layout: this.currentLayout
      });

      console.log('🚨 [INCIDENT-ENGINE] LEGACY: Zone violation detected', {
        personId,
        zone: zoneInfo.zone?.name,
        timestamp
      });
    }

    legacyResolveIncident(personId, context) {
      const state = this.activeIncidents.get(personId);
      if (!state) {
        return;
      }

      const endedAt = context.timestamp;
      const durationMs = Math.max(0, endedAt - state.startedAt);
      const durationSeconds = Number((durationMs / 1000).toFixed(2));
      const dataset = context.dataset || state.dataset || state.lastSample?.dataset || state.startSample?.dataset || null;
      const maxDistanceMeters = state.maxDistanceMeters || 0;
      const startLat = state.startSample?.lat ?? state.entryPoint?.lat ?? context.lat;
      const startLng = state.startSample?.lng ?? state.entryPoint?.lng ?? context.lng;
      const endLat = context.lat ?? state.lastSample?.lat ?? startLat;
      const endLng = context.lng ?? state.lastSample?.lng ?? startLng;

      if (state.incidentId && this.incidentManager) {
        try {
          this.incidentManager.acknowledgeIncident(state.incidentId, 'IncidentEngine');
        } catch (err) {
          console.error('❌ [INCIDENT-ENGINE] Failed to acknowledge incident', err);
        }
      }

      this.activeIncidents.delete(personId);

      if (window.SSHR?.cardManager?.recordIncident) {
        window.SSHR.cardManager.recordIncident(dataset, {
          type: 'zone-violation-end',
          startTime: state.startedAt,
          endTime: endedAt,
          startGPS: { lat: startLat, lng: startLng },
          endGPS: { lat: endLat, lng: endLng },
          duration: durationSeconds,
          maxDistance: maxDistanceMeters,
          zone: state.zoneInfo?.zone?.name,
          layoutId: state.layoutId
        });
      }

      this.emit('incident-resolve', {
        personId,
        dataset,
        durationSeconds,
        endedAt,
        startSample: state.startSample,
        endSample: context,
        maxDistanceMeters,
        layoutId: state.layoutId,
        layout: this.currentLayout
      });

      console.log('✅ [INCIDENT-ENGINE] LEGACY: Zone violation resolved', {
        personId,
        durationSeconds,
        maxDistanceMeters: Number(maxDistanceMeters.toFixed ? maxDistanceMeters.toFixed(2) : maxDistanceMeters)
      });

      return {
        personId,
        dataset,
        duration: durationSeconds,
        startGPS: { lat: startLat, lng: startLng },
        endGPS: { lat: endLat, lng: endLng },
        maxDistance: maxDistanceMeters
      };
    }
  }

  const incidentEngine = new IncidentEngine();
  global.SSHRIncidentEngine = incidentEngine;

  if (typeof global.addEventListener === 'function') {
    global.addEventListener('sshr-layout-activated', (event) => {
      const layout = event?.detail?.layout;
      if (layout) {
        incidentEngine.setLayoutContext(layout);
      }
    });
    global.addEventListener('sshr-zones-updated', (event) => {
      const greens = event?.detail?.zones;
      const source = event?.detail?.type || 'zones-event';
      const layoutId = event?.detail?.layoutId ?? null;
      if (Array.isArray(greens)) {
        incidentEngine.updateZones(greens, { source, layoutId });
      } else if (global.SSHR_ZONES) {
        incidentEngine.updateZones(null, { source, layoutId });
      }
    });
  }
})(window);

console.log('✅ [INCIDENT-ENGINE] SSHR Incident Engine loaded');
