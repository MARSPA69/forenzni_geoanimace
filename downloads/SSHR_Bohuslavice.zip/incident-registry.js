/**
 * IncidentRegistry - Centrální správce incidentů pro SSHR systém
 * Sjednocuje duplicitní logiku z IncidentEngine, SSHR_card_manager a parallel-tracking
 */

class IncidentRegistry {
  constructor() {
    this.activeIncidents = new Map(); // personId -> activeIncident
    this.completedIncidents = new Map(); // personId -> [completed incidents]
    this.listeners = new Map(); // eventType -> [callbacks]
    this.maxIncidentHistory = 50; // Zachovat posledních N incidentů per person
    this.hasSeenGreenZone = new Map(); // personId -> boolean (tracking first GREEN zone)

    console.log('🗃️ [INCIDENT-REGISTRY] Initialized');
  }

  /**
   * Spustí nový incident pro osobu
   */
  startIncident(personId, context) {
    const {
      dataset,
      timestamp,
      lat,
      lng,
      zoneInfo,
      sample,
      layoutId,
      movementType = null,
      anchorId = null,
      infraElementId = null
    } = context;

    // Zkontrolovat zda osoba už viděla GREEN zónu (prevent counting if starts in RED)
    if (!this.hasSeenGreenZone.get(personId)) {
      console.log('⏸️ [INCIDENT-REGISTRY] Waiting for first GREEN zone before starting incidents for person', personId);
      return;
    }

    // Zkontrolovat zda již není aktivní incident
    if (this.activeIncidents.has(personId)) {
      console.warn('⚠️ [INCIDENT-REGISTRY] Active incident already exists for person', personId);
      return;
    }

    const incidentId = `incident-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;

    const activeIncident = {
      id: incidentId,
      personId,
      dataset,
      type: 'zone-violation',
      startTime: timestamp,
      startGPS: { lat, lng },
      movementTypeAtStart: movementType,
      entryAnchor: anchorId,
      infraContext: infraElementId,
      zoneInfo: zoneInfo,
      layoutId: layoutId || null,
      maxDistance: 0,
      maxDistanceSample: sample,
      lastSample: context,
      startSample: sample
    };

    this.activeIncidents.set(personId, activeIncident);

    console.log('🚨 [INCIDENT-REGISTRY] Started incident', {
      personId,
      incidentId,
      zone: zoneInfo?.zone?.name,
      timestamp
    });

    this.emit('incident-start', { personId, incident: activeIncident });

    return activeIncident;
  }

  /**
   * Aktualizuje aktivní incident (např. při změně max. vzdálenosti)
   */
  updateActiveIncident(personId, updateData) {
    const activeIncident = this.activeIncidents.get(personId);
    if (!activeIncident) return;

    // Aktualizovat max vzdálenost
    if (updateData.distance && updateData.distance > activeIncident.maxDistance) {
      activeIncident.maxDistance = updateData.distance;
      activeIncident.maxDistanceSample = updateData.sample;
    }

    // Aktualizovat poslední pozici
    if (updateData.sample) {
      activeIncident.lastSample = updateData.sample;
    }

    this.activeIncidents.set(personId, activeIncident);
  }

  /**
   * Ukončí aktivní incident a přesune ho do historie
   */
  resolveIncident(personId, context) {
    const activeIncident = this.activeIncidents.get(personId);
    if (!activeIncident) {
      console.warn('⚠️ [INCIDENT-REGISTRY] No active incident to resolve for person', personId);
      return;
    }

    const {
      timestamp: endTime,
      lat: endLat,
      lng: endLng,
      movementType = null,
      anchorId = null,
      dataset
    } = context;

    const resolvedIncident = {
      ...activeIncident,
      endTime,
      endGPS: { lat: endLat, lng: endLng },
      movementTypeAtReturn: movementType,
      exitAnchor: anchorId,
      duration: Math.max(0, (endTime - activeIncident.startTime) / 1000), // v sekundách
      redDuration: Math.max(0, (endTime - activeIncident.startTime) / 1000), // v sekundách
      dataset: dataset || activeIncident.dataset
    };

    // Odstranit z aktivních
    this.activeIncidents.delete(personId);

    // Přidat do historie
    if (!this.completedIncidents.has(personId)) {
      this.completedIncidents.set(personId, []);
    }

    const history = this.completedIncidents.get(personId);
    history.push(resolvedIncident);

    // Omezit historii na max. počet záznamů
    if (history.length > this.maxIncidentHistory) {
      history.splice(0, history.length - this.maxIncidentHistory);
    }

    this.completedIncidents.set(personId, history);

    console.log('✅ [INCIDENT-REGISTRY] Resolved incident', {
      personId,
      incidentId: resolvedIncident.id,
      duration: resolvedIncident.duration
    });

    this.emit('incident-resolve', { personId, incident: resolvedIncident });

    // Odeslat na NAS přes MQTT
    if (window.SSHR?.mqttClient) {
      window.SSHR.mqttClient.publishIncidentAlert({
        type: 'incident-resolved',
        personId,
        incident: resolvedIncident
      }).catch(error => {
        console.error('❌ [INCIDENT-REGISTRY] Failed to publish incident to NAS:', error);
      });
    }
    this.syncIncidentToVisit(resolvedIncident);

    return resolvedIncident;
  }

  /**
   * Získá počet dokončených incidentů pro osobu
   */
  getCompletedCount(personId) {
    const history = this.completedIncidents.get(personId);
    return history ? history.length : 0;
  }

  /**
   * Zkontroluje zda má osoba aktivní incident
   */
  isActive(personId) {
    return this.activeIncidents.has(personId);
  }

  /**
   * Získá celkový počet incidentů (dokončené + aktivní)
   */
  getTotalCount(personId) {
    const completedCount = this.getCompletedCount(personId);
    const activeCount = this.isActive(personId) ? 1 : 0;
    return completedCount + activeCount;
  }

  /**
   * Získá aktivní incident pro osobu
   */
  getActiveIncident(personId) {
    return this.activeIncidents.get(personId) || null;
  }

  /**
   * Získá historii dokončených incidentů pro osobu
   */
  getCompletedIncidents(personId) {
    return this.completedIncidents.get(personId) || [];
  }

  /**
   * Získá nejnovější incident (dokončený nebo aktivní)
   */
  getLatestIncident(personId) {
    // Nejprve zkusit aktivní incident
    const activeIncident = this.getActiveIncident(personId);
    if (activeIncident) return activeIncident;

    // Jinak nejnovější dokončený
    const completed = this.getCompletedIncidents(personId);
    return completed.length > 0 ? completed[completed.length - 1] : null;
  }

  /**
   * Získá agregovaná data pro osobu (pro reporting)
   */
  getPersonSummary(personId) {
    const completed = this.getCompletedIncidents(personId);
    const active = this.getActiveIncident(personId);

    const totalRedTime = completed.reduce((sum, inc) => sum + (inc.redDuration || 0), 0);
    const maxDistance = completed.reduce((max, inc) => Math.max(max, inc.maxDistance || 0), 0);
    const lastIncident = this.getLatestIncident(personId);

    return {
      totalIncidents: completed.length + (active ? 1 : 0),
      completedIncidents: completed.length,
      activeIncident: active,
      totalRedTimeSeconds: totalRedTime,
      maxDistanceMeters: maxDistance,
      lastIncident,
      incidents: completed
    };
  }

  /**
   * Získá všechny osoby s incidenty (pro globální přehled)
   */
  getAllPersonsWithIncidents() {
    const persons = new Set();

    // Aktivní incidenty
    for (const personId of this.activeIncidents.keys()) {
      persons.add(personId);
    }

    // Dokončené incidenty
    for (const personId of this.completedIncidents.keys()) {
      persons.add(personId);
    }

    return Array.from(persons).map(personId => ({
      personId,
      summary: this.getPersonSummary(personId)
    }));
  }

  /**
   * Označí osobu jako viděla první GREEN zónu (povoluje následné počítání incidentů)
   */
  markPersonSeenGreenZone(personId) {
    if (!this.hasSeenGreenZone.get(personId)) {
      this.hasSeenGreenZone.set(personId, true);
      console.log('✅ [INCIDENT-REGISTRY] Person marked as seen GREEN zone, incident counting enabled for person', personId);
    }
  }

  /**
   * Event system
   */
  on(eventType, callback) {
    if (!this.listeners.has(eventType)) {
      this.listeners.set(eventType, []);
    }
    this.listeners.get(eventType).push(callback);
  }

  off(eventType, callback) {
    const callbacks = this.listeners.get(eventType);
    if (callbacks) {
      const index = callbacks.indexOf(callback);
      if (index > -1) {
        callbacks.splice(index, 1);
      }
    }
  }

  emit(eventType, data) {
    const callbacks = this.listeners.get(eventType);
    if (callbacks) {
      callbacks.forEach(callback => {
        try {
          callback(data);
        } catch (error) {
          console.error('❌ [INCIDENT-REGISTRY] Event callback error:', error);
        }
      });
    }
  }

  /**
   * Diagnostika pro debugging
   */
  getDebugInfo() {
    return {
      activeIncidentsCount: this.activeIncidents.size,
      personsWithHistory: this.completedIncidents.size,
      totalCompletedIncidents: Array.from(this.completedIncidents.values())
        .reduce((sum, incidents) => sum + incidents.length, 0),
      activeIncidents: Array.from(this.activeIncidents.entries()),
      listeners: Object.fromEntries(
        Array.from(this.listeners.entries()).map(([type, callbacks]) => [type, callbacks.length])
      )
    };
  }

  /**
   * Propaguje dokončené incidenty do VisitService pro reporting
   */
  syncIncidentToVisit(incident) {
    if (!incident?.dataset || !window.SSHRVisitService || typeof window.SSHRVisitService.recordIncident !== 'function') {
      return;
    }

    try {
      window.SSHRVisitService.recordIncident(incident.dataset, {
        type: incident.type || 'zone-violation',
        startTime: incident.startTime,
        endTime: incident.endTime,
        duration: incident.duration,
        startGPS: incident.startGPS,
        endGPS: incident.endGPS,
        movementTypeAtStart: incident.movementTypeAtStart || null,
        movementTypeAtReturn: incident.movementTypeAtReturn || null,
        entryAnchor: incident.entryAnchor || null,
        exitAnchor: incident.exitAnchor || null,
        maxDistance: incident.maxDistance || 0,
        layoutId: incident.layoutId || null
      });
    } catch (error) {
      console.error('⚠️ [INCIDENT-REGISTRY] Failed to sync incident to VisitService:', error);
    }
  }

  /**
   * Vyčistí data pro osobu (při odchodu)
   */
  clearPersonData(personId) {
    const hadActive = this.activeIncidents.delete(personId);
    const hadCompleted = this.completedIncidents.delete(personId);

    if (hadActive || hadCompleted) {
      console.log(`🧹 [INCIDENT-REGISTRY] Cleared data for person ${personId}`);
    }
  }
}

// Globální instance
window.SSHR = window.SSHR || {};
window.SSHR.incidentRegistry = new IncidentRegistry();

console.log('🗃️ [INCIDENT-REGISTRY] Global instance created at window.SSHR.incidentRegistry');
