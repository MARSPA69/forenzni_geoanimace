/**
 * Incident System Module for SSHR Bohuslavice
 * ===========================================
 *
 * IncidentManager Class - Complete incident detection and notification system
 * Features: Real-time alerts, incident logging, notification system
 *
 * Dependencies: Bootstrap 5, Toast notifications
 */

console.log("🚨 [INCIDENT-SYSTEM] Loading IncidentManager module...");

class IncidentManager {
    constructor(containerId = '#incidents-container') {
        this.container = document.querySelector(containerId);
        // Create container if it doesn't exist
        if (!this.container) {
            this.container = document.createElement('div');
            this.container.id = containerId.replace('#', '');
            this.container.style.display = 'none'; // Hidden by default
            document.body.appendChild(this.container);
        }
        this.incidents = new Map();
        this.activeAlerts = new Map();
        this.notificationQueue = [];

        // Configuration
        this.config = {
            maxIncidents: 100,
            autoAcknowledgeTime: 300000, // 5 minutes
            soundEnabled: true,
            toastDuration: 5000,
            incidentTypes: {
                'zone-violation': {
                    icon: 'fas fa-map-marker-alt',
                    color: 'danger',
                    priority: 'high',
                    sound: 'alert-high.mp3',
                    autoAcknowledge: false
                },
                'speed-violation': {
                    icon: 'fas fa-tachometer-alt',
                    color: 'warning',
                    priority: 'medium',
                    sound: 'alert-medium.mp3',
                    autoAcknowledge: true
                },
                'person-stationary': {
                    icon: 'fas fa-user-clock',
                    color: 'info',
                    priority: 'low',
                    sound: 'alert-low.mp3',
                    autoAcknowledge: true
                },
                'card-unassigned': {
                    icon: 'fas fa-id-card',
                    color: 'secondary',
                    priority: 'low',
                    sound: null,
                    autoAcknowledge: true
                },
                'system-error': {
                    icon: 'fas fa-exclamation-triangle',
                    color: 'danger',
                    priority: 'critical',
                    sound: 'alert-critical.mp3',
                    autoAcknowledge: false
                }
            }
        };

        this.init();
        console.log("✅ [INCIDENT-SYSTEM] Initialized successfully");
    }

    /**
     * Initialize the incident system
     */
    init() {
        if (!this.container) {
            console.error("❌ [INCIDENT-SYSTEM] Container not found");
            return;
        }

        this.setupContainer();
        this.setupEventListeners();
        this.setupToastContainer();
        this.startIncidentProcessor();
    }

    /**
     * Setup the container structure
     */
    setupContainer() {
        this.container.innerHTML = `
            <div class="incidents-header mb-3">
                <div class="d-flex justify-content-between align-items-center">
                    <h6 class="mb-0"><i class="fas fa-exclamation-circle"></i> Incidents</h6>
                    <div class="incident-actions">
                        <button class="btn btn-sm btn-outline-warning" id="acknowledge-all-btn">
                            <i class="fas fa-check-double"></i> Ack All
                        </button>
                        <button class="btn btn-sm btn-outline-secondary" id="clear-acknowledged-btn">
                            <i class="fas fa-trash"></i> Clear
                        </button>
                        <button class="btn btn-sm btn-outline-primary" id="export-incidents-btn">
                            <i class="fas fa-download"></i> Export
                        </button>
                    </div>
                </div>
            </div>

            <div class="incidents-stats mb-3">
                <div class="row text-center">
                    <div class="col-3">
                        <div class="stat-item">
                            <div class="stat-value text-danger" id="critical-count">0</div>
                            <div class="stat-label">Critical</div>
                        </div>
                    </div>
                    <div class="col-3">
                        <div class="stat-item">
                            <div class="stat-value text-danger" id="high-count">0</div>
                            <div class="stat-label">High</div>
                        </div>
                    </div>
                    <div class="col-3">
                        <div class="stat-item">
                            <div class="stat-value text-warning" id="medium-count">0</div>
                            <div class="stat-label">Medium</div>
                        </div>
                    </div>
                    <div class="col-3">
                        <div class="stat-item">
                            <div class="stat-value text-info" id="low-count">0</div>
                            <div class="stat-label">Low</div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="incidents-filter mb-3">
                <div class="btn-group btn-group-sm w-100" role="group">
                    <input type="radio" class="btn-check" name="incident-filter" id="filter-all" value="all" checked>
                    <label class="btn btn-outline-secondary" for="filter-all">All</label>

                    <input type="radio" class="btn-check" name="incident-filter" id="filter-active" value="active">
                    <label class="btn btn-outline-danger" for="filter-active">Active</label>

                    <input type="radio" class="btn-check" name="incident-filter" id="filter-acknowledged" value="acknowledged">
                    <label class="btn btn-outline-success" for="filter-acknowledged">Ack'd</label>
                </div>
            </div>

            <div class="incidents-list" id="incidents-list" style="max-height: 400px; overflow-y: auto;">
                <!-- Incidents will be rendered here -->
            </div>
        `;
    }

    /**
     * Setup toast container for notifications
     */
    setupToastContainer() {
        // Check if toast container exists
        let toastContainer = document.querySelector('#toast-container');
        if (!toastContainer) {
            toastContainer = document.createElement('div');
            toastContainer.id = 'toast-container';
            toastContainer.className = 'toast-container position-fixed top-0 end-0 p-3';
            toastContainer.style.zIndex = '9999';
            document.body.appendChild(toastContainer);
        }
        this.toastContainer = toastContainer;
    }

    /**
     * Setup event listeners
     */
    setupEventListeners() {
        // Acknowledge all button
        const ackAllBtn = this.container.querySelector('#acknowledge-all-btn');
        if (ackAllBtn) {
            ackAllBtn.addEventListener('click', () => this.acknowledgeAllIncidents());
        }

        // Clear acknowledged button
        const clearBtn = this.container.querySelector('#clear-acknowledged-btn');
        if (clearBtn) {
            clearBtn.addEventListener('click', () => this.clearAcknowledgedIncidents());
        }

        // Export button
        const exportBtn = this.container.querySelector('#export-incidents-btn');
        if (exportBtn) {
            exportBtn.addEventListener('click', () => this.exportIncidents());
        }

        // Filter radio buttons
        const filterInputs = this.container.querySelectorAll('input[name="incident-filter"]');
        filterInputs.forEach(input => {
            input.addEventListener('change', (e) => this.filterIncidents(e.target.value));
        });

        // Listen for external incident events
        window.addEventListener('sshr-incident-detected', (e) => {
            this.handleIncident(e.detail);
        });

        // Listen for person tracking events
        window.addEventListener('sshr-person-added', (e) => {
            this.logSystemEvent('person-added', `Person ${e.detail.person.id} added to tracking`);
        });

        window.addEventListener('sshr-person-removed', (e) => {
            this.logSystemEvent('person-removed', `Person ${e.detail.personId} removed from tracking`);
        });
    }

    /**
     * Start the incident processor
     */
    startIncidentProcessor() {
        // Process notification queue every second
        setInterval(() => {
            this.processNotificationQueue();
        }, 1000);

        // Check for auto-acknowledgment
        setInterval(() => {
            this.checkAutoAcknowledgment();
        }, 30000); // Every 30 seconds

        console.log("🔄 [INCIDENT-SYSTEM] Processor started");
    }

    /**
     * Handle incoming incident
     */
    handleIncident(incidentData) {
        try {
            const incident = this.createIncident(incidentData);
            this.logIncident(incident);
            this.triggerNotification(incident);
            this.updateDisplay();

            console.log(`🚨 [INCIDENT-SYSTEM] New incident: ${incident.type} - ${incident.message}`);

            return incident;
        } catch (error) {
            console.error(`❌ [INCIDENT-SYSTEM] Error handling incident:`, error);
            return null;
        }
    }

    /**
     * Create incident object
     */
    createIncident(data) {
        const incident = {
            id: data.id || `INC_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
            type: data.type || 'unknown',
            timestamp: data.timestamp || new Date(),
            message: data.message || this.generateMessage(data),
            person: data.person || null,
            location: data.location || null,
            value: data.value || null,
            threshold: data.threshold || null,
            priority: this.config.incidentTypes[data.type]?.priority || 'medium',
            status: 'active',
            acknowledgedAt: null,
            acknowledgedBy: null,
            metadata: {
                ...data
            }
        };

        return incident;
    }

    /**
     * Generate incident message
     */
    generateMessage(data) {
        switch (data.type) {
            case 'zone-violation':
                return `Person ${data.person} entered restricted zone`;
            case 'speed-violation':
                return `Person ${data.person} exceeding speed limit (${data.value?.toFixed(1)} km/h > ${data.threshold} km/h)`;
            case 'person-stationary':
                return `Person ${data.person} stationary for extended period`;
            case 'card-unassigned':
                return `Card ${data.cardId} unassigned from person ${data.person}`;
            case 'system-error':
                return `System error: ${data.error || 'Unknown error'}`;
            default:
                return `Incident detected: ${data.type}`;
        }
    }

    /**
     * Log incident to storage
     */
    logIncident(incident) {
        this.incidents.set(incident.id, incident);

        // Limit incident storage
        if (this.incidents.size > this.config.maxIncidents) {
            const oldestIncident = Array.from(this.incidents.values())
                .sort((a, b) => a.timestamp - b.timestamp)[0];
            this.incidents.delete(oldestIncident.id);
        }

        // Add to active alerts if not auto-acknowledge
        const incidentConfig = this.config.incidentTypes[incident.type];
        if (!incidentConfig?.autoAcknowledge) {
            this.activeAlerts.set(incident.id, incident);
        }
    }

    /**
     * Trigger notification for incident
     */
    triggerNotification(incident) {
        // Add to notification queue
        this.notificationQueue.push({
            incident,
            timestamp: new Date()
        });

        // Immediate visual notification for critical incidents
        if (incident.priority === 'critical') {
            this.showToast(incident);
            this.playSound(incident);
        }
    }

    /**
     * Process notification queue
     */
    processNotificationQueue() {
        if (this.notificationQueue.length === 0) return;

        const notification = this.notificationQueue.shift();
        this.showToast(notification.incident);
        this.playSound(notification.incident);
    }

    /**
     * Show toast notification
     */
    showToast(incident) {
        const incidentConfig = this.config.incidentTypes[incident.type];
        const toastId = `toast-${incident.id}`;

        const toastHtml = `
            <div id="${toastId}" class="toast" role="alert" aria-live="assertive" aria-atomic="true">
                <div class="toast-header bg-${incidentConfig?.color || 'secondary'} text-white">
                    <i class="${incidentConfig?.icon || 'fas fa-exclamation'} me-2"></i>
                    <strong class="me-auto">${incident.type.toUpperCase()}</strong>
                    <small>${incident.timestamp.toLocaleTimeString()}</small>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="toast"></button>
                </div>
                <div class="toast-body">
                    ${incident.message}
                    <div class="mt-2 pt-2 border-top">
                        <button type="button" class="btn btn-sm btn-primary acknowledge-toast-btn"
                                data-incident-id="${incident.id}">
                            Acknowledge
                        </button>
                    </div>
                </div>
            </div>
        `;

        this.toastContainer.insertAdjacentHTML('beforeend', toastHtml);

        // Initialize Bootstrap toast
        const toastElement = document.getElementById(toastId);
        const toast = new bootstrap.Toast(toastElement, {
            delay: this.config.toastDuration
        });

        // Setup acknowledge button
        const ackBtn = toastElement.querySelector('.acknowledge-toast-btn');
        if (ackBtn) {
            ackBtn.addEventListener('click', () => {
                this.acknowledgeIncident(incident.id);
                toast.hide();
            });
        }

        // Show toast
        toast.show();

        // Clean up after toast is hidden
        toastElement.addEventListener('hidden.bs.toast', () => {
            toastElement.remove();
        });
    }

    /**
     * Play sound notification
     */
    playSound(incident) {
        if (!this.config.soundEnabled) return;

        const incidentConfig = this.config.incidentTypes[incident.type];
        const soundFile = incidentConfig?.sound;

        if (soundFile) {
            // TODO: Implement sound playback
            // This would require audio files and proper audio handling
            console.log(`🔊 [INCIDENT-SYSTEM] Playing sound: ${soundFile}`);
        }
    }

    /**
     * Acknowledge incident
     */
    acknowledgeIncident(incidentId, acknowledgedBy = 'System') {
        const incident = this.incidents.get(incidentId);
        if (!incident) return false;

        try {
            incident.status = 'acknowledged';
            incident.acknowledgedAt = new Date();
            incident.acknowledgedBy = acknowledgedBy;

            // Remove from active alerts
            this.activeAlerts.delete(incidentId);

            // Update display
            this.updateDisplay();

            console.log(`✅ [INCIDENT-SYSTEM] Acknowledged incident ${incidentId}`);

            // Trigger event
            this.triggerEvent('incident-acknowledged', { incident });

            return true;
        } catch (error) {
            console.error(`❌ [INCIDENT-SYSTEM] Error acknowledging incident ${incidentId}:`, error);
            return false;
        }
    }

    /**
     * Acknowledge all active incidents
     */
    acknowledgeAllIncidents() {
        const activeIncidents = Array.from(this.incidents.values())
            .filter(incident => incident.status === 'active');

        let acknowledgedCount = 0;
        activeIncidents.forEach(incident => {
            if (this.acknowledgeIncident(incident.id, 'Bulk Operation')) {
                acknowledgedCount++;
            }
        });

        console.log(`✅ [INCIDENT-SYSTEM] Acknowledged ${acknowledgedCount} incidents`);
        return acknowledgedCount;
    }

    /**
     * Clear acknowledged incidents
     */
    clearAcknowledgedIncidents() {
        if (!confirm('Are you sure you want to clear all acknowledged incidents?')) {
            return 0;
        }

        const acknowledgedIncidents = Array.from(this.incidents.values())
            .filter(incident => incident.status === 'acknowledged');

        let clearedCount = 0;
        acknowledgedIncidents.forEach(incident => {
            this.incidents.delete(incident.id);
            clearedCount++;
        });

        this.updateDisplay();

        console.log(`🗑️ [INCIDENT-SYSTEM] Cleared ${clearedCount} acknowledged incidents`);
        return clearedCount;
    }

    /**
     * Check for auto-acknowledgment
     */
    checkAutoAcknowledgment() {
        const now = new Date();
        const autoAckTime = this.config.autoAcknowledgeTime;

        Array.from(this.incidents.values()).forEach(incident => {
            if (incident.status === 'active') {
                const incidentConfig = this.config.incidentTypes[incident.type];
                if (incidentConfig?.autoAcknowledge) {
                    const age = now - incident.timestamp;
                    if (age > autoAckTime) {
                        this.acknowledgeIncident(incident.id, 'Auto-Acknowledge');
                    }
                }
            }
        });
    }

    /**
     * Update display
     */
    updateDisplay() {
        this.updateStats();
        this.renderIncidents();
    }

    /**
     * Update statistics
     */
    updateStats() {
        const stats = {
            critical: 0,
            high: 0,
            medium: 0,
            low: 0
        };

        Array.from(this.incidents.values()).forEach(incident => {
            if (incident.status === 'active') {
                stats[incident.priority] = (stats[incident.priority] || 0) + 1;
            }
        });

        // Update DOM
        const criticalElement = this.container.querySelector('#critical-count');
        const highElement = this.container.querySelector('#high-count');
        const mediumElement = this.container.querySelector('#medium-count');
        const lowElement = this.container.querySelector('#low-count');

        if (criticalElement) criticalElement.textContent = stats.critical;
        if (highElement) highElement.textContent = stats.high;
        if (mediumElement) mediumElement.textContent = stats.medium;
        if (lowElement) lowElement.textContent = stats.low;
    }

    /**
     * Render incidents list
     */
    renderIncidents() {
        const incidentsList = this.container.querySelector('#incidents-list');
        if (!incidentsList) return;

        const currentFilter = this.container.querySelector('input[name="incident-filter"]:checked')?.value || 'all';

        let incidents = Array.from(this.incidents.values())
            .sort((a, b) => b.timestamp - a.timestamp); // Most recent first

        // Apply filter
        if (currentFilter === 'active') {
            incidents = incidents.filter(incident => incident.status === 'active');
        } else if (currentFilter === 'acknowledged') {
            incidents = incidents.filter(incident => incident.status === 'acknowledged');
        }

        // Clear current content
        incidentsList.innerHTML = '';

        // Render incidents
        incidents.forEach(incident => {
            const incidentHtml = this.renderIncident(incident);
            incidentsList.insertAdjacentHTML('beforeend', incidentHtml);
        });

        // Setup incident event listeners
        this.setupIncidentEventListeners();

        // Show empty message if no incidents
        if (incidents.length === 0) {
            incidentsList.innerHTML = `
                <div class="text-center text-muted py-4">
                    <i class="fas fa-check-circle fa-2x mb-2"></i>
                    <div>No incidents to display</div>
                </div>
            `;
        }
    }

    /**
     * Render single incident
     */
    renderIncident(incident) {
        const incidentConfig = this.config.incidentTypes[incident.type];
        const isActive = incident.status === 'active';

        return `
            <div class="incident-item ${isActive ? 'active' : 'acknowledged'} mb-2" data-incident-id="${incident.id}">
                <div class="card border-${incidentConfig?.color || 'secondary'}">
                    <div class="card-body p-2">
                        <div class="d-flex align-items-start">
                            <div class="incident-icon me-2">
                                <i class="${incidentConfig?.icon || 'fas fa-exclamation'} text-${incidentConfig?.color || 'secondary'}"></i>
                            </div>
                            <div class="incident-content flex-grow-1">
                                <div class="d-flex justify-content-between align-items-start mb-1">
                                    <div class="incident-type">
                                        <strong>${incident.type.replace('-', ' ').toUpperCase()}</strong>
                                        <span class="badge bg-${incidentConfig?.color || 'secondary'} ms-2">${incident.priority}</span>
                                    </div>
                                    <div class="incident-time">
                                        <small class="text-muted">${incident.timestamp.toLocaleTimeString()}</small>
                                    </div>
                                </div>
                                <div class="incident-message">${incident.message}</div>
                                ${incident.person ? `<small class="text-muted">Person: ${incident.person}</small>` : ''}
                                ${incident.acknowledgedAt ? `
                                    <div class="incident-ack mt-1">
                                        <small class="text-success">
                                            <i class="fas fa-check"></i> Acknowledged at ${incident.acknowledgedAt.toLocaleTimeString()}
                                            by ${incident.acknowledgedBy}
                                        </small>
                                    </div>
                                ` : ''}
                            </div>
                            <div class="incident-actions ms-2">
                                ${isActive ? `
                                    <button class="btn btn-sm btn-outline-success acknowledge-btn"
                                            data-incident-id="${incident.id}">
                                        <i class="fas fa-check"></i>
                                    </button>
                                ` : ''}
                                <button class="btn btn-sm btn-outline-secondary details-btn"
                                        data-incident-id="${incident.id}">
                                    <i class="fas fa-info"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }

    /**
     * Setup incident event listeners
     */
    setupIncidentEventListeners() {
        // Acknowledge buttons
        const ackButtons = this.container.querySelectorAll('.acknowledge-btn');
        ackButtons.forEach(btn => {
            btn.addEventListener('click', (e) => {
                const incidentId = e.target.closest('.acknowledge-btn').dataset.incidentId;
                this.acknowledgeIncident(incidentId, 'Manual');
            });
        });

        // Details buttons
        const detailsButtons = this.container.querySelectorAll('.details-btn');
        detailsButtons.forEach(btn => {
            btn.addEventListener('click', (e) => {
                const incidentId = e.target.closest('.details-btn').dataset.incidentId;
                this.showIncidentDetails(incidentId);
            });
        });
    }

    /**
     * Filter incidents
     */
    filterIncidents(filter) {
        console.log(`🔍 [INCIDENT-SYSTEM] Filtering incidents: ${filter}`);
        this.renderIncidents();
    }

    /**
     * Show incident details
     */
    showIncidentDetails(incidentId) {
        const incident = this.incidents.get(incidentId);
        if (!incident) return;

        // TODO: Implement details modal
        console.log(`📋 [INCIDENT-SYSTEM] Showing details for incident ${incidentId}:`, incident);
        alert(`Incident Details:\n\nType: ${incident.type}\nMessage: ${incident.message}\nTime: ${incident.timestamp}\nStatus: ${incident.status}`);
    }

    /**
     * Export incidents
     */
    exportIncidents() {
        const incidents = Array.from(this.incidents.values());
        const csvData = this.convertToCSV(incidents);
        this.downloadCSV(csvData, `incidents_${new Date().toISOString().split('T')[0]}.csv`);
    }

    /**
     * Convert incidents to CSV
     */
    convertToCSV(incidents) {
        const headers = ['ID', 'Type', 'Timestamp', 'Message', 'Person', 'Priority', 'Status', 'Acknowledged At', 'Acknowledged By'];
        const rows = incidents.map(incident => [
            incident.id,
            incident.type,
            incident.timestamp.toISOString(),
            incident.message,
            incident.person || '',
            incident.priority,
            incident.status,
            incident.acknowledgedAt ? incident.acknowledgedAt.toISOString() : '',
            incident.acknowledgedBy || ''
        ]);

        return [headers, ...rows].map(row => row.map(field => `"${field}"`).join(',')).join('\n');
    }

    /**
     * Download CSV file
     */
    downloadCSV(csvData, filename) {
        const blob = new Blob([csvData], { type: 'text/csv' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        a.click();
        window.URL.revokeObjectURL(url);
    }

    /**
     * Log system event
     */
    logSystemEvent(type, message) {
        this.handleIncident({
            type: 'system-event',
            message: message,
            priority: 'low'
        });
    }

    /**
     * Get all incidents
     */
    getAllIncidents() {
        return Array.from(this.incidents.values());
    }

    /**
     * Get active incidents
     */
    getActiveIncidents() {
        return Array.from(this.incidents.values()).filter(incident => incident.status === 'active');
    }

    /**
     * Event system for notifications
     */
    triggerEvent(eventType, data) {
        console.log(`📡 [INCIDENT-SYSTEM] Event: ${eventType}`, data);

        // Dispatch custom event
        if (typeof window !== 'undefined') {
            window.dispatchEvent(new CustomEvent(`sshr-${eventType}`, { detail: data }));
        }
    }

    /**
     * Get incident count for specific person
     */
    getPersonIncidentCount(personId) {
        try {
            let count = 0;

            // Count all incidents (active and acknowledged) for this person
            for (const [incidentId, incident] of this.incidents) {
                if (incident.metadata &&
                    (incident.metadata.personId === personId ||
                     incident.metadata.person === personId ||
                     incident.person === personId)) {
                    count++;
                }
            }

            console.log(`📊 [INCIDENT-SYSTEM] Person ${personId} has ${count} total incidents`);
            return count;
        } catch (error) {
            console.error(`❌ [INCIDENT-SYSTEM] Error counting incidents for person ${personId}:`, error);
            return 0;
        }
    }

    /**
     * Cleanup method
     */
    destroy() {
        console.log("🧹 [INCIDENT-SYSTEM] Cleaning up...");

        this.incidents.clear();
        this.activeAlerts.clear();
        this.notificationQueue = [];

        if (this.container) {
            this.container.innerHTML = '';
        }

        if (this.toastContainer) {
            this.toastContainer.innerHTML = '';
        }
    }
}

// Export for use in main renderer
if (typeof window !== 'undefined') {
    window.IncidentManager = IncidentManager;
}

console.log("✅ [INCIDENT-SYSTEM] IncidentManager class loaded successfully");