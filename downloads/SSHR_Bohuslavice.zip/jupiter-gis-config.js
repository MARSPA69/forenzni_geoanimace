/**
 * Jupiter GIS Configuration Module
 * ===============================
 *
 * Centralized configuration management for Jupiter GIS integration
 * Features: Environment configs, API settings, mode switching, real connection setup
 */

console.log("⚙️ [JUPITER-CONFIG] Loading Jupiter GIS Configuration...");

class JupiterGISConfig {
    constructor() {
        this.environments = {
            development: {
                apiUrl: 'http://localhost:8080/jupiter-api',
                websocketUrl: 'ws://localhost:8080/jupiter-ws',
                apiKey: 'dev-api-key-placeholder',
                timeout: 5000,
                retryAttempts: 3,
                mockMode: true
            },
            staging: {
                apiUrl: 'https://staging-jupiter.example.com/api',
                websocketUrl: 'wss://staging-jupiter.example.com/ws',
                apiKey: process.env.JUPITER_STAGING_API_KEY || 'staging-key-placeholder',
                timeout: 10000,
                retryAttempts: 5,
                mockMode: false
            },
            production: {
                apiUrl: 'https://jupiter-gis.example.com/api',
                websocketUrl: 'wss://jupiter-gis.example.com/ws',
                apiKey: process.env.JUPITER_PROD_API_KEY || 'prod-key-placeholder',
                timeout: 15000,
                retryAttempts: 3,
                mockMode: false
            }
        };

        // Default configuration
        this.currentEnv = 'development';
        this.config = { ...this.environments[this.currentEnv] };

        // Feature flags
        this.features = {
            realTimeAnalysis: true,
            reactiveEventHandling: true,
            auditLogging: true,
            geoprocessing: true,
            predictiveZones: false, // Pro future use
            behavioralAnalytics: false, // Pro future use
            heatMapOverlay: true,
            riskAlerts: true
        };

        // Analysis settings
        this.analysisConfig = {
            interval: 30000, // 30 sekund
            batchSize: 100,
            riskThresholds: {
                low: 70,
                medium: 40,
                high: 20
            },
            patternConfidenceThreshold: 0.6,
            anomalyThreshold: 0.8
        };

        // Event subscription settings
        this.eventSubscriptions = {
            'sshr-zones-updated': true,
            'incident-start': true,
            'incident-resolve': true,
            'zone-drawn': true,
            'zone-confirmed': true,
            'zone-deleted': true,
            'person-added': true,
            'person-removed': true,
            'layout-activated': true
        };

        this.loadConfigFromStorage();
        console.log(`⚙️ [JUPITER-CONFIG] Initialized for ${this.currentEnv} environment`);
    }

    /**
     * Switch environment
     */
    switchEnvironment(envName) {
        if (!this.environments[envName]) {
            console.error(`❌ [JUPITER-CONFIG] Unknown environment: ${envName}`);
            return false;
        }

        this.currentEnv = envName;
        this.config = { ...this.environments[envName] };
        this.saveConfigToStorage();

        console.log(`🔄 [JUPITER-CONFIG] Switched to ${envName} environment`);

        // Notify connector about environment change
        window.dispatchEvent(new CustomEvent('jupiter-environment-changed', {
            detail: { environment: envName, config: this.config }
        }));

        return true;
    }

    /**
     * Toggle mock mode
     */
    setMockMode(enabled) {
        this.config.mockMode = enabled;
        this.saveConfigToStorage();

        console.log(`🎭 [JUPITER-CONFIG] Mock mode ${enabled ? 'enabled' : 'disabled'}`);

        window.dispatchEvent(new CustomEvent('jupiter-mock-mode-changed', {
            detail: { mockMode: enabled }
        }));
    }

    /**
     * Update API credentials
     */
    setApiCredentials(apiKey, apiUrl = null) {
        this.config.apiKey = apiKey;
        if (apiUrl) {
            this.config.apiUrl = apiUrl;
        }
        this.saveConfigToStorage();

        console.log('🔐 [JUPITER-CONFIG] API credentials updated');
    }

    /**
     * Enable/disable specific features
     */
    setFeature(featureName, enabled) {
        if (this.features.hasOwnProperty(featureName)) {
            this.features[featureName] = enabled;
            this.saveConfigToStorage();

            console.log(`🎛️ [JUPITER-CONFIG] Feature '${featureName}' ${enabled ? 'enabled' : 'disabled'}`);

            window.dispatchEvent(new CustomEvent('jupiter-feature-changed', {
                detail: { feature: featureName, enabled: enabled }
            }));
        }
    }

    /**
     * Update analysis configuration
     */
    updateAnalysisConfig(updates) {
        this.analysisConfig = { ...this.analysisConfig, ...updates };
        this.saveConfigToStorage();

        console.log('📊 [JUPITER-CONFIG] Analysis configuration updated:', updates);
    }

    /**
     * Subscribe/unsubscribe from events
     */
    setEventSubscription(eventName, enabled) {
        this.eventSubscriptions[eventName] = enabled;
        this.saveConfigToStorage();

        console.log(`📡 [JUPITER-CONFIG] Event subscription '${eventName}' ${enabled ? 'enabled' : 'disabled'}`);
    }

    /**
     * Get current configuration
     */
    getConfig() {
        return {
            environment: this.currentEnv,
            ...this.config,
            features: this.features,
            analysis: this.analysisConfig,
            events: this.eventSubscriptions
        };
    }

    /**
     * Validate configuration
     */
    validateConfig() {
        const errors = [];

        if (!this.config.apiUrl) {
            errors.push('API URL is required');
        }

        if (!this.config.apiKey || this.config.apiKey.includes('placeholder')) {
            errors.push('Valid API key is required for production use');
        }

        if (this.config.timeout < 1000) {
            errors.push('Timeout should be at least 1000ms');
        }

        if (this.analysisConfig.interval < 5000) {
            errors.push('Analysis interval should be at least 5000ms');
        }

        return {
            valid: errors.length === 0,
            errors: errors
        };
    }

    /**
     * Initialize real connection (for production)
     */
    initializeRealConnection() {
        if (this.config.mockMode) {
            console.warn('⚠️ [JUPITER-CONFIG] Cannot initialize real connection in mock mode');
            return false;
        }

        const validation = this.validateConfig();
        if (!validation.valid) {
            console.error('❌ [JUPITER-CONFIG] Configuration validation failed:', validation.errors);
            return false;
        }

        console.log('🌐 [JUPITER-CONFIG] Initializing real Jupiter GIS connection...');

        // Trigger real connection initialization
        window.dispatchEvent(new CustomEvent('jupiter-initialize-real-connection', {
            detail: this.getConfig()
        }));

        return true;
    }

    /**
     * Save configuration to localStorage
     */
    saveConfigToStorage() {
        try {
            const configData = {
                environment: this.currentEnv,
                config: this.config,
                features: this.features,
                analysis: this.analysisConfig,
                events: this.eventSubscriptions,
                lastUpdated: Date.now()
            };

            localStorage.setItem('jupiter-gis-config', JSON.stringify(configData));
            console.log('💾 [JUPITER-CONFIG] Configuration saved to localStorage');
        } catch (error) {
            console.error('❌ [JUPITER-CONFIG] Failed to save configuration:', error);
        }
    }

    /**
     * Load configuration from localStorage
     */
    loadConfigFromStorage() {
        try {
            const stored = localStorage.getItem('jupiter-gis-config');
            if (stored) {
                const configData = JSON.parse(stored);

                if (configData.environment && this.environments[configData.environment]) {
                    this.currentEnv = configData.environment;
                    this.config = { ...this.environments[this.currentEnv], ...configData.config };
                }

                if (configData.features) {
                    this.features = { ...this.features, ...configData.features };
                }

                if (configData.analysis) {
                    this.analysisConfig = { ...this.analysisConfig, ...configData.analysis };
                }

                if (configData.events) {
                    this.eventSubscriptions = { ...this.eventSubscriptions, ...configData.events };
                }

                console.log('📁 [JUPITER-CONFIG] Configuration loaded from localStorage');
            }
        } catch (error) {
            console.warn('⚠️ [JUPITER-CONFIG] Failed to load stored configuration:', error);
        }
    }

    /**
     * Reset to default configuration
     */
    resetToDefaults() {
        this.currentEnv = 'development';
        this.config = { ...this.environments[this.currentEnv] };
        this.saveConfigToStorage();

        console.log('🔄 [JUPITER-CONFIG] Configuration reset to defaults');

        window.dispatchEvent(new CustomEvent('jupiter-config-reset'));
    }

    /**
     * Export configuration for backup
     */
    exportConfig() {
        const exportData = {
            version: '1.0',
            timestamp: new Date().toISOString(),
            environment: this.currentEnv,
            config: this.config,
            features: this.features,
            analysis: this.analysisConfig,
            events: this.eventSubscriptions
        };

        return JSON.stringify(exportData, null, 2);
    }

    /**
     * Import configuration from backup
     */
    importConfig(configJson) {
        try {
            const importData = JSON.parse(configJson);

            if (importData.environment && this.environments[importData.environment]) {
                this.currentEnv = importData.environment;
                this.config = { ...this.environments[this.currentEnv], ...importData.config };
            }

            if (importData.features) {
                this.features = { ...this.features, ...importData.features };
            }

            if (importData.analysis) {
                this.analysisConfig = { ...this.analysisConfig, ...importData.analysis };
            }

            if (importData.events) {
                this.eventSubscriptions = { ...this.eventSubscriptions, ...importData.events };
            }

            this.saveConfigToStorage();
            console.log('📥 [JUPITER-CONFIG] Configuration imported successfully');
            return true;
        } catch (error) {
            console.error('❌ [JUPITER-CONFIG] Failed to import configuration:', error);
            return false;
        }
    }
}

// Global instance
window.JupiterGISConfig = new JupiterGISConfig();

// Expose global API
window.SSHR = window.SSHR || {};
window.SSHR.jupiterConfig = window.JupiterGISConfig;

console.log("✅ [JUPITER-CONFIG] Jupiter GIS Configuration module ready!");
console.log("🔧 [JUPITER-CONFIG] Access via window.SSHR.jupiterConfig");

// Auto-export current config for debugging
console.log("📋 [JUPITER-CONFIG] Current configuration:", window.JupiterGISConfig.getConfig());