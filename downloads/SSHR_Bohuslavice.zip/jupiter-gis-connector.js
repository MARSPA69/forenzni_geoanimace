/**
 * Jupiter GIS Connector for SSHR Bohuslavice
 * ==========================================
 *
 * Connects SSHR tracking system with Jupiter GIS platform
 * Features: Data export, analytics, predictive insights, zone optimization
 *
 * Dependencies: SSHR renderer, polygon manager, incident engine
 */

console.log("🪐 [JUPITER-GIS] Loading Jupiter GIS Connector...");

class SSHRJupiterGISConnector {
    constructor(sshrRenderer) {
        this.renderer = sshrRenderer;
        this.dataBuffer = [];
        this.analyticsCache = new Map();
        this.exportInterval = 30000; // Výchozí hodnota, lze přepsat konfigurací
        this.isConnected = false;
        this.lastAnalysis = null;
        this.mockMode = true; // Výchozí režim, dokud není načtena konfigurace

        // Analytics counters
        this.metrics = {
            totalAnalyses: 0,
            riskAssessments: 0,
            patternDetections: 0,
            anomaliesFound: 0,
            zoneOptimizations: 0,
            dataExports: 0,
            auditLogs: 0,
            highPriorityAnalyses: 0
        };

        // Export/Audit system
        this.auditLog = [];
        this.exportHistory = [];
        this.maxAuditEntries = 1000;
        this.maxExportHistory = 100;

        // NAS / Jupiter configuration
        this.config = this.buildDefaultConfig();
        this.nasStatus = {
            connected: false,
            lastExport: null,
            lastAnalysis: null,
            lastError: null
        };

        this.applyEnvironmentConfiguration();
        this.setupReactiveEventListeners();

        if (this.mockMode) {
            console.log("🪐 [JUPITER-GIS] Connector initialised in mock mode");
            this.initializeMockConnection();
        } else {
            console.log("🪐 [JUPITER-GIS] Connector initialised in production mode");
            this.initializeProductionConnection();
        }
    }

    /**
     * Initialize mock connection to Jupiter GIS (for demo)
     */
    initializeMockConnection() {
        console.log("🔌 [JUPITER-GIS] Initializing mock connection...");
        this.mockMode = true;
        this.config.enabled = false;

        // Simulate connection delay
        setTimeout(() => {
            this.isConnected = true;
            this.nasStatus.connected = false;
            console.log("✅ [JUPITER-GIS] Mock connection established");

            // Start periodic analytics
            this.startPeriodicAnalysis();
        }, 2000);
    }

    buildDefaultConfig() {
        return {
            enabled: false,
            baseUrl: 'https://192.168.1.93:5050',
            endpoints: {
                export: '/sshr/jupiter/export',
                analysis: '/sshr/jupiter/analysis',
                latest: '/sshr/jupiter/analysis/latest'
            },
            authToken: null,
            websocketUrl: null,
            timeout: 15000
        };
    }

    applyEnvironmentConfiguration() {
        const envConfig =
            window.SSHR_CONFIG?.jupiter ||
            window.SSHR?.config?.jupiter ||
            window.SSHR?.jupiterConfig ||
            {};

        if (typeof envConfig.mockMode === 'boolean') {
            this.mockMode = envConfig.mockMode;
        }

        if (typeof envConfig.exportInterval === 'number') {
            this.exportInterval = envConfig.exportInterval;
        }

        if (envConfig.baseUrl) {
            this.config.baseUrl = envConfig.baseUrl;
        }

        if (envConfig.endpoints) {
            this.config.endpoints = {
                ...this.config.endpoints,
                ...envConfig.endpoints
            };
        }

        if (envConfig.websocketUrl) {
            this.config.websocketUrl = envConfig.websocketUrl;
        }

        if (typeof envConfig.timeout === 'number') {
            this.config.timeout = envConfig.timeout;
        }

        if (envConfig.token) {
            this.setNASAuthToken(envConfig.token);
        }

        if (typeof envConfig.enabled === 'boolean') {
            this.config.enabled = envConfig.enabled;
            this.mockMode = !envConfig.enabled;
        } else if (!this.mockMode) {
            this.config.enabled = true;
        }
    }

    setNASAuthToken(token) {
        this.config.authToken = token;
    }

    enableProductionMode(options = {}) {
        this.mockMode = false;
        this.config.enabled = true;

        if (options.baseUrl) {
            this.config.baseUrl = options.baseUrl;
        }
        if (options.token) {
            this.setNASAuthToken(options.token);
        }
        if (options.endpoints) {
            this.config.endpoints = {
                ...this.config.endpoints,
                ...options.endpoints
            };
        }
        if (options.websocketUrl) {
            this.config.websocketUrl = options.websocketUrl;
        }
        if (typeof options.timeout === 'number') {
            this.config.timeout = options.timeout;
        }
        if (typeof options.exportInterval === 'number') {
            this.exportInterval = options.exportInterval;
        }

        this.initializeProductionConnection();
    }

    async initializeProductionConnection() {
        console.log("🌐 [JUPITER-GIS] Initializing NAS/Jupiter production connection...");

        if (!this.config.authToken) {
            console.warn("⚠️ [JUPITER-GIS] Missing NAS auth token, staying in mock mode");
            this.fallbackToMockMode('missing-token');
            return;
        }

        try {
            await this.testNASAvailability();
            this.isConnected = true;
            this.nasStatus.connected = true;
            this.mockMode = false;
            console.log("✅ [JUPITER-GIS] NAS endpoints reachable, starting production workflow");

            this.startPeriodicAnalysis();

            if (this.config.websocketUrl) {
                this.initializeWebSocket(this.config.websocketUrl, this.config.authToken);
            }
        } catch (error) {
            this.handleRemoteError(error, 'initialization');
            this.fallbackToMockMode('nas-unreachable');
        }
    }

    async testNASAvailability() {
        const response = await this.callNAS(this.config.endpoints.latest, {
            method: 'GET',
            silent: true
        });

        if (!response || response.status === 'empty') {
            console.log("ℹ️ [JUPITER-GIS] NAS reachable but no analysis present yet");
        }

        return response;
    }

    async callNAS(endpointPath, options = {}) {
        const { method = 'GET', body = null, silent = false, timeout = this.config.timeout } = options;

        if (!this.config.baseUrl) {
            throw new Error('NAS baseUrl is not configured');
        }

        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), timeout);
        const url = new URL(endpointPath, this.config.baseUrl).toString();

        const headers = {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${this.config.authToken}`
        };

        try {
            const response = await fetch(url, {
                method,
                headers,
                body,
                signal: controller.signal,
                credentials: 'include',
                mode: 'cors'
            });
            clearTimeout(timer);

            if (!response.ok) {
                const message = `NAS request failed (${response.status})`;
                if (!silent) {
                    console.error(`❌ [JUPITER-GIS] ${message}`);
                }
                throw new Error(message);
            }

            if (response.status === 204) {
                return null;
            }

            const json = await response.json().catch(() => null);
            return json;
        } catch (error) {
            clearTimeout(timer);
            if (!silent) {
                console.error("❌ [JUPITER-GIS] NAS request error:", error);
            }
            throw error;
        }
    }

    async uploadExportToNAS(data) {
        const payload = JSON.stringify(data);
        await this.callNAS(this.config.endpoints.export, {
            method: 'POST',
            body: payload
        });

        this.metrics.dataExports++;
        this.nasStatus.lastExport = Date.now();
        this.recordNasEvent('export', { persons: data.tracking_data.persons.length, zones: data.tracking_data.zones.length });

        this.exportHistory.unshift({
            timestamp: this.nasStatus.lastExport,
            type: 'nas-export',
            size: payload.length,
            mode: this.mockMode ? 'mock' : 'remote'
        });
        if (this.exportHistory.length > this.maxExportHistory) {
            this.exportHistory = this.exportHistory.slice(0, this.maxExportHistory);
        }
    }

    async requestRemoteAnalysis(context = {}) {
        const payload = JSON.stringify(context);
        const response = await this.callNAS(this.config.endpoints.analysis, {
            method: 'POST',
            body: payload
        });

        this.nasStatus.lastAnalysis = Date.now();
        this.recordNasEvent('analysis-request', context);
        return response;
    }

    async fetchLatestAnalysis(force = false) {
        if (!this.config.enabled) {
            return null;
        }
        const latest = await this.callNAS(this.config.endpoints.latest, {
            method: 'GET',
            silent: true
        });
        if (latest && force) {
            this.recordNasEvent('analysis-fetch', latest);
        }
        return latest;
    }

    recordNasEvent(type, payload) {
        this.addAuditEntry(`nas:${type}`, payload);
        this.metrics.auditLogs++;
    }

    handleRemoteError(error, phase = 'runtime') {
        console.error(`❌ [JUPITER-GIS] NAS error during ${phase}:`, error);
        this.nasStatus.lastError = {
            phase,
            message: error.message,
            timestamp: Date.now()
        };
    }

    fallbackToMockMode(reason) {
        console.warn(`🎭 [JUPITER-GIS] Switching to mock mode (${reason})`);
        this.stopPeriodicAnalysis();
        this.initializeMockConnection();
    }

    /**
     * Export current SSHR data for Jupiter analysis
     */
    exportSSHRData() {
        const timestamp = Date.now();

        // Collect persons data from PersonTracker (for parallel mode) with fallback to window.sshrPersons
        const personTracker = window.SSHR?.personTracker || window.SSHRParallel?.personTracker;
        const personsSource = personTracker ? personTracker.getAllPersons() : (window.sshrPersons || new Map());

        const sourceCount = Array.isArray(personsSource)
            ? personsSource.length
            : (typeof personsSource.size === 'number' ? personsSource.size : 0);
        window.sshrDebugLog?.(`📚 [JUPITER-GIS] Collecting persons data from ${personTracker ? 'PersonTracker' : 'window.sshrPersons'} - found ${sourceCount} persons`);

        let personEntries = [];
        if (Array.isArray(personsSource)) {
            personEntries = personsSource
                .filter(person => person && (person.id || person.datasetName))
                .map(person => [person.id || person.datasetName || `person-${timestamp}`, person]);
        } else if (personsSource instanceof Map) {
            personEntries = Array.from(personsSource.entries());
        } else if (personsSource && typeof personsSource === 'object' && personsSource[Symbol.iterator]) {
            personEntries = Array.from(personsSource);
        } else if (personsSource && typeof personsSource === 'object') {
            personEntries = Object.entries(personsSource);
        } else {
            console.warn('📚 [JUPITER-GIS] Unsupported personsSource structure:', personsSource);
            return [];
        }

        const persons = personEntries.map(([id, person]) => {
            const cardInfo = window.sshrCards ? window.sshrCards.get(id) : null;

            // Handle different data structures between PersonTracker and window.sshrPersons
            let position, zoneStatus, anchorId;

            if (personTracker && person.position) {
                // PersonTracker structure
                position = {
                    lat: person.position[0] || 0,
                    lng: person.position[1] || 0
                };

                // Get zone status from PersonTracker
                const zoneStatusObj = personTracker.getPersonZoneStatus?.(id);
                zoneStatus = zoneStatusObj ? zoneStatusObj.zone : 'NEUTRAL';

                // Get latest anchor from lastActivatedAnchors
                anchorId = null;
                if (person.lastActivatedAnchors && person.lastActivatedAnchors.length > 0) {
                    const latestAnchor = person.lastActivatedAnchors[person.lastActivatedAnchors.length - 1];
                    anchorId = latestAnchor.anchorNumber || latestAnchor.id;
                }
            } else {
                // Legacy window.sshrPersons structure
                position = {
                    lat: person.lat || 0,
                    lng: person.lng || 0
                };
                zoneStatus = person.zoneStatus || 'NEUTRAL';
                anchorId = person.anchorId || person.lastAnchor;
            }

            return {
                personId: id,
                position: position,
                zoneStatus: zoneStatus,
                anchorId: anchorId,
                speed: person.speed || 0,
                registrationStatus: cardInfo ? 'registered' : 'unregistered',
                timestamp: timestamp
            };
        });

        // Collect zones data
        const polygonManager = window.sshrPolygonManager || window.SSHR?.polygonManager;
        const zones = polygonManager ? this.exportZoneConfiguration(polygonManager) : [];

        // Collect incidents data - try multiple sources
        let incidents = [];

        // Try PersonTracker incident details first
        if (personTracker) {
            console.log(`📊 [JUPITER-GIS] Collecting incidents from PersonTracker`);
            for (const [personId, person] of personEntries) {
                try {
                    const incidentDetails = personTracker.getPersonIncidentDetails?.(personId);
                    if (incidentDetails && incidentDetails.length > 0) {
                        incidentDetails.forEach(incident => {
                            incidents.push({
                                id: incident.id || `${personId}_${incident.timestamp}`,
                                type: incident.type || 'zone_violation',
                                timestamp: incident.timestamp || timestamp,
                                location: incident.startGPS || person.position,
                                severity: incident.severity || 'medium',
                                resolved: incident.resolved !== false,
                                personId: personId,
                                duration: incident.duration
                            });
                        });
                    }
                } catch (error) {
                    console.warn(`⚠️ [JUPITER-GIS] Error collecting incidents for person ${personId}:`, error);
                }
            }
        }

        // Fallback to window.sshrIncidents
        if (incidents.length === 0) {
            console.log(`📊 [JUPITER-GIS] Fallback to window.sshrIncidents - found ${(window.sshrIncidents || []).length} incidents`);
            incidents = (window.sshrIncidents || []).map(incident => ({
                id: incident.id,
                type: incident.type,
                timestamp: incident.timestamp,
                location: incident.location,
                severity: incident.severity || 'medium',
                resolved: incident.resolved || false
            }));
        }

        const exportData = {
            metadata: {
                facility: 'SSHR_Bohuslavice',
                timestamp: timestamp,
                export_version: '1.0',
                data_quality: this.assessDataQuality(persons, zones, incidents)
            },
            tracking_data: {
                persons: persons,
                zones: zones,
                incidents: incidents,
                active_persons_count: persons.length,
                active_zones_count: zones.length
            },
            system_status: {
                polygon_mode: polygonManager ? polygonManager.mode : 'FIXED',
                confirmed_zones: polygonManager ? polygonManager.confirmedZones.size : 0,
                pending_zones: polygonManager ? polygonManager.pendingZones.size : 0
            }
        };

        console.log(`📤 [JUPITER-GIS] Exported data: ${persons.length} persons, ${zones.length} zones, ${incidents.length} incidents`);
        return exportData;
    }

    /**
     * Export zone configuration
     */
    exportZoneConfiguration(polygonManager) {
        const zones = [];

        if (polygonManager.zones) {
            // Export GREEN zones
            polygonManager.zones.green.forEach((zone, id) => {
                zones.push({
                    id: id,
                    type: 'GREEN',
                    name: zone.name || `Green Zone ${id}`,
                    coordinates: zone.coordinates || [],
                    confirmed: polygonManager.confirmedZones.has(id),
                    area: this.calculatePolygonArea(zone.coordinates || [])
                });
            });

            // Export RED zones
            polygonManager.zones.red.forEach((zone, id) => {
                zones.push({
                    id: id,
                    type: 'RED',
                    name: zone.name || `Red Zone ${id}`,
                    coordinates: zone.coordinates || [],
                    area: this.calculatePolygonArea(zone.coordinates || [])
                });
            });
        }

        return zones;
    }

    /**
     * Calculate polygon area (simplified)
     */
    calculatePolygonArea(coordinates) {
        if (!coordinates || coordinates.length < 3) return 0;
        // Simplified area calculation - for demo purposes
        return Math.round(coordinates.length * 100 + Math.random() * 500);
    }

    /**
     * Assess data quality
     */
    assessDataQuality(persons, zones, incidents) {
        let quality = 100;

        if (persons.length === 0) quality -= 30;
        if (zones.length === 0) quality -= 20;
        if (persons.some(p => !p.position.lat || !p.position.lng)) quality -= 15;

        return Math.max(0, quality);
    }

    /**
     * Perform Jupiter GIS analysis (mock/remote aware)
     */
    async performAnalysis(data) {
        console.log("🔍 [JUPITER-GIS] Performing analytics...");

        if (!this.isConnected) {
            console.warn("⚠️ [JUPITER-GIS] Not connected, cannot perform analysis");
            return null;
        }

        if (!this.mockMode && this.config.enabled) {
            return this.performRemoteAnalysis(data);
        }

        return this.performMockAnalysis(data);
    }

    async performRemoteAnalysis(data) {
        try {
            await this.uploadExportToNAS(data);

            const triggerType = data.trigger_event?.type || 'periodic';
            const priority = data.trigger_event?.priority || 'normal';

            const response = await this.requestRemoteAnalysis({
                trigger: triggerType,
                priority,
                timestamp: Date.now(),
                metadata: {
                    persons: data.tracking_data.persons.length,
                    zones: data.tracking_data.zones.length,
                    incidents: data.tracking_data.incidents.length
                }
            });

            let analysis = response?.analysis || response;
            if (!analysis) {
                analysis = await this.fetchLatestAnalysis(true);
            }

            if (analysis) {
                this.processAnalysisResult(analysis, { mode: 'remote', trigger: triggerType, priority });
                console.log("✅ [JUPITER-GIS] Remote analysis completed:", analysis);
                return analysis;
            }

            console.warn("⚠️ [JUPITER-GIS] NAS returned empty analysis, falling back to mock");
            return this.performMockAnalysis(data, true);
        } catch (error) {
            this.handleRemoteError(error, data.trigger_event?.type || 'remote-analysis');
            return this.performMockAnalysis(data, true);
        }
    }

    async performMockAnalysis(data, isFallback = false) {
        await new Promise(resolve => setTimeout(resolve, 800));
        const analysis = this.generateMockAnalysis(data);
        const triggerType = data.trigger_event?.type || 'periodic';
        const priority = data.trigger_event?.priority || (isFallback ? 'fallback' : 'normal');
        this.processAnalysisResult(analysis, { mode: isFallback ? 'fallback' : 'mock', trigger: triggerType, priority });
        console.log("✅ [JUPITER-GIS] Mock analysis completed:", analysis);
        return analysis;
    }

    processAnalysisResult(analysis, context = {}) {
        this.lastAnalysis = analysis;
        this.metrics.totalAnalyses++;

        if (analysis?.risk_assessment) {
            this.metrics.riskAssessments++;
        }
        if (analysis?.pattern_analysis?.patterns_detected) {
            this.metrics.patternDetections += analysis.pattern_analysis.patterns_detected;
        }
        if (analysis?.anomaly_detection?.anomalies_count) {
            this.metrics.anomaliesFound += analysis.anomaly_detection.anomalies_count;
        }
        if ((analysis?.zone_optimization?.recommendations || []).length > 0) {
            this.metrics.zoneOptimizations++;
        }
        if (context.priority === 'high') {
            this.metrics.highPriorityAnalyses++;
        }

        this.recordAnalysisCacheEntry(analysis, context);

        window.dispatchEvent(new CustomEvent('jupiter-analysis-updated', {
            detail: {
                analysis,
                context
            }
        }));
    }

    recordAnalysisCacheEntry(analysis, context = {}) {
        const cacheId = analysis?.metadata?.id || `${Date.now()}-${Math.random().toString(36).slice(2)}`;
        const entry = {
            id: cacheId,
            timestamp: analysis?.timestamp || Date.now(),
            mode: context.mode || (this.mockMode ? 'mock' : 'remote'),
            priority: context.priority || 'normal'
        };

        this.analyticsCache.set(cacheId, entry);

        if (this.analyticsCache.size > 1000) {
            const oldestKey = this.analyticsCache.keys().next().value;
            this.analyticsCache.delete(oldestKey);
        }
    }

    /**
     * Generate mock analysis results
     */
    generateMockAnalysis(data) {
        const personsCount = data.tracking_data.persons.length;
        const zonesCount = data.tracking_data.zones.length;
        const incidentsCount = data.tracking_data.incidents.length;

        // Mock risk calculation
        let riskScore = 85; // Base score
        if (personsCount > 5) riskScore -= personsCount * 2;
        if (incidentsCount > 0) riskScore -= incidentsCount * 10;
        if (zonesCount === 0) riskScore -= 20;
        riskScore = Math.max(10, Math.min(100, riskScore));

        // Mock risk level
        let riskLevel = 'LOW';
        if (riskScore < 70) riskLevel = 'MEDIUM';
        if (riskScore < 40) riskLevel = 'HIGH';

        // Mock pattern detection
        const patterns = [];
        if (personsCount > 3) {
            patterns.push({
                type: 'clustering',
                confidence: 0.75 + Math.random() * 0.2,
                description: 'Seskupování osob v centrální oblasti'
            });
        }
        if (incidentsCount > 0) {
            patterns.push({
                type: 'incident_correlation',
                confidence: 0.60 + Math.random() * 0.3,
                description: 'Korelace incidentů s pohybem osob'
            });
        }

        // Mock anomalies
        const anomalies = [];
        if (Math.random() > 0.7) {
            anomalies.push({
                type: 'movement_anomaly',
                severity: 'minor',
                description: 'Neobvyklý pohybový vzor detekován',
                location: { lat: 49.7417, lng: 18.2625 }
            });
        }

        // Mock zone recommendations
        const zoneRecommendations = [];
        if (personsCount > 4 && zonesCount < 3) {
            zoneRecommendations.push({
                type: 'add_green_zone',
                priority: 'medium',
                suggestedLocation: { lat: 49.7420, lng: 18.2630 },
                reason: 'Vysoká koncentrace osob bez pokrytí'
            });
        }

        return {
            timestamp: Date.now(),
            risk_assessment: {
                score: riskScore,
                level: riskLevel,
                factors: [
                    `${personsCount} osob v areálu`,
                    `${zonesCount} aktivních zón`,
                    `${incidentsCount} incidentů`
                ]
            },
            pattern_analysis: {
                patterns_detected: patterns.length,
                confidence: patterns.length > 0 ? patterns.reduce((acc, p) => acc + p.confidence, 0) / patterns.length : 0,
                patterns: patterns
            },
            anomaly_detection: {
                anomalies_count: anomalies.length,
                anomalies: anomalies
            },
            zone_optimization: {
                recommendations: zoneRecommendations,
                current_efficiency: Math.round(60 + Math.random() * 30),
                coverage_score: Math.round(70 + Math.random() * 25)
            },
            metadata: {
                processing_time: '1.2s',
                data_quality: data.metadata.data_quality,
                algorithm_version: '2.1.0'
            }
        };
    }

    /**
     * Start periodic analysis
     */
    startPeriodicAnalysis() {
        if (this.analysisInterval) {
            clearInterval(this.analysisInterval);
        }

        this.analysisInterval = setInterval(async () => {
            if (this.isConnected) {
                const data = this.exportSSHRData();
                await this.performAnalysis(data);
            }
        }, this.exportInterval);

        console.log(`⏰ [JUPITER-GIS] Periodic analysis started (${this.exportInterval}ms interval)`);
    }

    /**
     * Stop periodic analysis
     */
    stopPeriodicAnalysis() {
        if (this.analysisInterval) {
            clearInterval(this.analysisInterval);
            this.analysisInterval = null;
            console.log("⏹️ [JUPITER-GIS] Periodic analysis stopped");
        }
    }

    /**
     * Get current analytics status
     */
    getAnalyticsStatus() {
        return {
            connected: this.isConnected,
            lastAnalysis: this.lastAnalysis,
            metrics: this.metrics,
            cacheSize: this.analyticsCache.size
        };
    }

    /**
     * Force immediate analysis
     */
    async triggerImmediateAnalysis() {
        console.log("🚀 [JUPITER-GIS] Triggering immediate analysis...");
        const data = this.exportSSHRData();
        const result = await this.performAnalysis(data);
        return result;
    }

    /**
     * Setup reactive event listeners for SSHR events
     */
    setupReactiveEventListeners() {
        console.log("📡 [JUPITER-GIS] Setting up reactive event listeners...");

        // Zone-related events
        window.addEventListener('sshr-zones-updated', (event) => {
            console.log("🔄 [JUPITER-REACTIVE] Zones updated, triggering analysis");
            this.triggerReactiveAnalysis('zones-updated', event.detail);
        });

        window.addEventListener('zone-drawn', (event) => {
            console.log("🎨 [JUPITER-REACTIVE] Zone drawn, analyzing zone efficiency");
            this.triggerReactiveAnalysis('zone-drawn', event.detail);
        });

        window.addEventListener('zone-confirmed', (event) => {
            console.log("✅ [JUPITER-REACTIVE] Zone confirmed, updating risk assessment");
            this.triggerReactiveAnalysis('zone-confirmed', event.detail);
        });

        window.addEventListener('zone-deleted', (event) => {
            console.log("🗑️ [JUPITER-REACTIVE] Zone deleted, recalculating coverage");
            this.triggerReactiveAnalysis('zone-deleted', event.detail);
        });

        // Layout events
        window.addEventListener('sshr-layout-activated', (event) => {
            console.log("📐 [JUPITER-REACTIVE] Layout activated, full analysis");
            this.triggerReactiveAnalysis('layout-activated', event.detail);
        });

        // Incident events
        window.addEventListener('incident-start', (event) => {
            console.log("🚨 [JUPITER-REACTIVE] Incident started, high-priority analysis");
            this.triggerReactiveAnalysis('incident-start', event.detail, true); // High priority
        });

        window.addEventListener('incident-resolve', (event) => {
            console.log("✅ [JUPITER-REACTIVE] Incident resolved, updating patterns");
            this.triggerReactiveAnalysis('incident-resolve', event.detail);
        });

        // Person tracking events
        window.addEventListener('person-added', (event) => {
            console.log("👤 [JUPITER-REACTIVE] Person added, updating density analysis");
            this.triggerReactiveAnalysis('person-added', event.detail);
        });

        window.addEventListener('person-removed', (event) => {
            console.log("👋 [JUPITER-REACTIVE] Person removed, updating metrics");
            this.triggerReactiveAnalysis('person-removed', event.detail);
        });

        // Configuration events
        window.addEventListener('jupiter-environment-changed', (event) => {
            console.log("⚙️ [JUPITER-REACTIVE] Environment changed, reconnecting");
            this.handleEnvironmentChange(event.detail);
        });

        window.addEventListener('jupiter-mock-mode-changed', (event) => {
            console.log("🎭 [JUPITER-REACTIVE] Mock mode changed");
            this.mockMode = event.detail.mockMode;
        });

        console.log("✅ [JUPITER-GIS] Reactive event listeners setup complete");
    }

    /**
     * Trigger reactive analysis based on events
     */
    async triggerReactiveAnalysis(eventType, eventData = null, highPriority = false) {
        if (!this.isConnected) {
            console.warn("⚠️ [JUPITER-REACTIVE] Not connected, skipping reactive analysis");
            return;
        }

        console.log(`🔥 [JUPITER-REACTIVE] Triggering ${highPriority ? 'HIGH-PRIORITY ' : ''}analysis for: ${eventType}`);

        // Add event context to analysis
        const data = this.exportSSHRData();
        data.trigger_event = {
            type: eventType,
            timestamp: Date.now(),
            data: eventData,
            priority: highPriority ? 'high' : 'normal'
        };

        try {
            const analysis = await this.performAnalysis(data);

            // Emit specialized event for reactive analysis
            window.dispatchEvent(new CustomEvent('jupiter-reactive-analysis', {
                detail: {
                    eventType: eventType,
                    analysis: analysis,
                    priority: highPriority
                }
            }));
        } catch (error) {
            console.error("❌ [JUPITER-REACTIVE] Reactive analysis failed:", error);
        }
    }

    /**
     * Handle environment configuration changes
     */
    handleEnvironmentChange(configDetail) {
        console.log("🔄 [JUPITER-CONFIG] Handling environment change:", configDetail?.environment);

        this.isConnected = false;
        this.stopPeriodicAnalysis();

        const cfg = configDetail?.config || {};

        if (cfg.mockMode) {
            this.fallbackToMockMode('config-change');
            return;
        }

        const options = {
            baseUrl: cfg.apiUrl || cfg.baseUrl,
            token: cfg.apiKey || cfg.token,
            endpoints: cfg.endpoints,
            websocketUrl: cfg.websocketUrl,
            timeout: cfg.timeout,
            exportInterval: cfg.exportInterval || cfg.timeout
        };

        this.enableProductionMode(options);
    }

    /**
     * Initialize WebSocket connection for real-time updates
     */
    initializeWebSocket(websocketUrl, apiKey) {
        try {
            this.websocket = new WebSocket(`${websocketUrl}?token=${apiKey}`);

            this.websocket.onopen = () => {
                console.log("🔌 [JUPITER-WS] WebSocket connection opened");
            };

            this.websocket.onmessage = (event) => {
                try {
                    const message = JSON.parse(event.data);
                    this.handleWebSocketMessage(message);
                } catch (error) {
                    console.error("❌ [JUPITER-WS] Failed to parse WebSocket message:", error);
                }
            };

            this.websocket.onclose = () => {
                console.log("🔌 [JUPITER-WS] WebSocket connection closed, attempting reconnect...");
                setTimeout(() => this.initializeWebSocket(websocketUrl, apiKey), 5000);
            };

            this.websocket.onerror = (error) => {
                console.error("❌ [JUPITER-WS] WebSocket error:", error);
            };

        } catch (error) {
            console.error("❌ [JUPITER-WS] Failed to initialize WebSocket:", error);
        }
    }

    /**
     * Handle incoming WebSocket messages from Jupiter GIS
     */
    handleWebSocketMessage(message) {
        console.log("📨 [JUPITER-WS] Received message:", message);

        switch (message.type) {
            case 'analysis_complete':
                this.lastAnalysis = message.data;
                window.dispatchEvent(new CustomEvent('jupiter-analysis-updated', {
                    detail: this.lastAnalysis
                }));
                break;

            case 'alert':
                this.handleJupiterAlert(message.data);
                break;

            case 'zone_recommendation':
                this.handleZoneRecommendation(message.data);
                break;

            default:
                console.log("📝 [JUPITER-WS] Unknown message type:", message.type);
        }
    }

    /**
     * Handle Jupiter GIS alerts
     */
    handleJupiterAlert(alertData) {
        console.log("🚨 [JUPITER-ALERT] Received alert:", alertData);

        window.dispatchEvent(new CustomEvent('jupiter-alert', {
            detail: alertData
        }));
    }

    /**
     * Handle zone recommendations from Jupiter GIS
     */
    handleZoneRecommendation(recommendation) {
        console.log("💡 [JUPITER-RECOMMEND] Received zone recommendation:", recommendation);

        window.dispatchEvent(new CustomEvent('jupiter-zone-recommendation', {
            detail: recommendation
        }));
    }

    // =========================================
    // EXPORT/AUDIT FUNCTIONALITY
    // =========================================

    /**
     * Add entry to audit log
     */
    addAuditEntry(action, details = null, user = 'system') {
        const entry = {
            id: Date.now() + Math.random().toString(36).substr(2, 9),
            timestamp: new Date().toISOString(),
            action: action,
            user: user,
            details: details,
            session_id: this.getSessionId()
        };

        this.auditLog.unshift(entry);

        // Maintain maximum entries
        if (this.auditLog.length > this.maxAuditEntries) {
            this.auditLog = this.auditLog.slice(0, this.maxAuditEntries);
        }

        this.metrics.auditLogs++;
        console.log(`📝 [JUPITER-AUDIT] ${action}:`, details);

        // Emit audit event
        window.dispatchEvent(new CustomEvent('jupiter-audit-entry', {
            detail: entry
        }));

        return entry;
    }

    /**
     * Export complete audit log
     */
    exportAuditLog(format = 'json') {
        const exportData = {
            metadata: {
                facility: 'SSHR_Bohuslavice',
                export_type: 'audit_log',
                timestamp: new Date().toISOString(),
                total_entries: this.auditLog.length,
                date_range: {
                    from: this.auditLog.length > 0 ? this.auditLog[this.auditLog.length - 1].timestamp : null,
                    to: this.auditLog.length > 0 ? this.auditLog[0].timestamp : null
                }
            },
            audit_log: this.auditLog
        };

        this.addAuditEntry('audit_log_exported', { format: format, entries_count: this.auditLog.length });

        if (format === 'csv') {
            return this.convertAuditToCSV(exportData);
        }

        return JSON.stringify(exportData, null, 2);
    }

    /**
     * Convert audit log to CSV format
     */
    convertAuditToCSV(exportData) {
        const headers = ['ID', 'Timestamp', 'Action', 'User', 'Details', 'Session ID'];
        const csvRows = [headers.join(',')];

        exportData.audit_log.forEach(entry => {
            const row = [
                entry.id,
                entry.timestamp,
                entry.action,
                entry.user,
                JSON.stringify(entry.details || '').replace(/"/g, '""'),
                entry.session_id
            ];
            csvRows.push(row.join(','));
        });

        return csvRows.join('\n');
    }

    /**
     * Export complete system state for backup/analysis
     */
    exportCompleteSystemState() {
        const timestamp = new Date().toISOString();
        const data = this.exportSSHRData();

        const completeState = {
            metadata: {
                facility: 'SSHR_Bohuslavice',
                export_type: 'complete_system_state',
                timestamp: timestamp,
                version: '2.0',
                jupiter_connector_version: '1.0.0'
            },
            sshr_data: data,
            jupiter_analytics: {
                last_analysis: this.lastAnalysis,
                metrics: this.metrics,
                cache_entries: this.analyticsCache.size
            },
            system_configuration: {
                mock_mode: this.mockMode,
                connected: this.isConnected,
                export_interval: this.exportInterval
            },
            audit_summary: {
                total_audit_entries: this.auditLog.length,
                recent_entries: this.auditLog.slice(0, 10),
                export_history_count: this.exportHistory.length
            }
        };

        // Add to export history
        this.exportHistory.unshift({
            timestamp: timestamp,
            type: 'complete_system_state',
            size: JSON.stringify(completeState).length,
            data_quality: data.metadata.data_quality
        });

        // Maintain export history size
        if (this.exportHistory.length > this.maxExportHistory) {
            this.exportHistory = this.exportHistory.slice(0, this.maxExportHistory);
        }

        this.metrics.dataExports++;
        this.addAuditEntry('complete_state_exported', {
            export_size: JSON.stringify(completeState).length,
            data_quality: data.metadata.data_quality
        });

        console.log(`📤 [JUPITER-EXPORT] Complete system state exported (${JSON.stringify(completeState).length} bytes)`);
        return completeState;
    }

    /**
     * Export filtered data based on criteria
     */
    exportFilteredData(filters = {}) {
        const {
            timeRange = null,          // { from: Date, to: Date }
            personIds = null,          // Array of person IDs
            zoneTypes = null,          // Array of zone types ('GREEN', 'RED')
            incidentTypes = null,      // Array of incident types
            includeAnalytics = true,   // Include Jupiter analytics
            includeAudit = false       // Include audit log
        } = filters;

        const baseData = this.exportSSHRData();
        const timestamp = new Date().toISOString();

        // Apply time range filter
        if (timeRange) {
            if (timeRange.from) {
                baseData.tracking_data.persons = baseData.tracking_data.persons.filter(p =>
                    new Date(p.timestamp) >= new Date(timeRange.from)
                );
                baseData.tracking_data.incidents = baseData.tracking_data.incidents.filter(i =>
                    new Date(i.timestamp) >= new Date(timeRange.from)
                );
            }
            if (timeRange.to) {
                baseData.tracking_data.persons = baseData.tracking_data.persons.filter(p =>
                    new Date(p.timestamp) <= new Date(timeRange.to)
                );
                baseData.tracking_data.incidents = baseData.tracking_data.incidents.filter(i =>
                    new Date(i.timestamp) <= new Date(timeRange.to)
                );
            }
        }

        // Apply person filter
        if (personIds && Array.isArray(personIds)) {
            baseData.tracking_data.persons = baseData.tracking_data.persons.filter(p =>
                personIds.includes(p.personId)
            );
        }

        // Apply zone type filter
        if (zoneTypes && Array.isArray(zoneTypes)) {
            baseData.tracking_data.zones = baseData.tracking_data.zones.filter(z =>
                zoneTypes.includes(z.type)
            );
        }

        // Apply incident type filter
        if (incidentTypes && Array.isArray(incidentTypes)) {
            baseData.tracking_data.incidents = baseData.tracking_data.incidents.filter(i =>
                incidentTypes.includes(i.type)
            );
        }

        const filteredData = {
            metadata: {
                ...baseData.metadata,
                export_type: 'filtered_data',
                timestamp: timestamp,
                filters_applied: filters
            },
            tracking_data: baseData.tracking_data,
            system_status: baseData.system_status
        };

        // Add analytics if requested
        if (includeAnalytics && this.lastAnalysis) {
            filteredData.jupiter_analytics = {
                last_analysis: this.lastAnalysis,
                analysis_timestamp: this.lastAnalysis.timestamp
            };
        }

        // Add audit log if requested
        if (includeAudit) {
            let auditEntries = this.auditLog;
            if (timeRange && timeRange.from) {
                auditEntries = auditEntries.filter(entry =>
                    new Date(entry.timestamp) >= new Date(timeRange.from)
                );
            }
            if (timeRange && timeRange.to) {
                auditEntries = auditEntries.filter(entry =>
                    new Date(entry.timestamp) <= new Date(timeRange.to)
                );
            }
            filteredData.audit_log = auditEntries;
        }

        this.addAuditEntry('filtered_data_exported', {
            filters: filters,
            result_size: JSON.stringify(filteredData).length
        });

        console.log(`📤 [JUPITER-FILTER] Filtered data exported with filters:`, filters);
        return filteredData;
    }

    /**
     * Schedule automated exports
     */
    scheduleAutomatedExport(schedule = {}) {
        const {
            interval = 3600000,        // 1 hour default
            exportType = 'system_state', // 'system_state', 'audit_log', 'analytics_only'
            autoDownload = false,      // Auto-download files
            retentionDays = 30        // Keep exports for 30 days
        } = schedule;

        if (this.exportSchedule) {
            clearInterval(this.exportSchedule);
        }

        this.exportSchedule = setInterval(() => {
            console.log(`⏰ [JUPITER-EXPORT] Running scheduled export: ${exportType}`);

            let exportData;
            let filename;

            switch (exportType) {
                case 'system_state':
                    exportData = this.exportCompleteSystemState();
                    filename = `sshr_system_state_${new Date().toISOString().replace(/[:.]/g, '-')}.json`;
                    break;

                case 'audit_log':
                    exportData = this.exportAuditLog('json');
                    filename = `sshr_audit_log_${new Date().toISOString().replace(/[:.]/g, '-')}.json`;
                    break;

                case 'analytics_only':
                    exportData = {
                        timestamp: new Date().toISOString(),
                        analytics: this.lastAnalysis,
                        metrics: this.metrics
                    };
                    filename = `sshr_analytics_${new Date().toISOString().replace(/[:.]/g, '-')}.json`;
                    break;

                default:
                    console.error(`❌ [JUPITER-EXPORT] Unknown export type: ${exportType}`);
                    return;
            }

            if (autoDownload) {
                this.downloadExportData(exportData, filename);
            }

            // Store in export history
            this.exportHistory.unshift({
                timestamp: new Date().toISOString(),
                type: `scheduled_${exportType}`,
                filename: filename,
                size: JSON.stringify(exportData).length,
                auto_downloaded: autoDownload
            });

            this.addAuditEntry('scheduled_export_completed', {
                type: exportType,
                filename: filename,
                auto_downloaded: autoDownload
            });

        }, interval);

        this.addAuditEntry('automated_export_scheduled', {
            interval: interval,
            export_type: exportType,
            auto_download: autoDownload,
            retention_days: retentionDays
        });

        console.log(`📅 [JUPITER-EXPORT] Automated export scheduled: ${exportType} every ${interval}ms`);
        return this.exportSchedule;
    }

    /**
     * Stop automated exports
     */
    stopAutomatedExport() {
        if (this.exportSchedule) {
            clearInterval(this.exportSchedule);
            this.exportSchedule = null;
            this.addAuditEntry('automated_export_stopped');
            console.log("⏹️ [JUPITER-EXPORT] Automated export stopped");
            return true;
        }
        return false;
    }

    /**
     * Download export data as file
     */
    downloadExportData(data, filename) {
        try {
            const jsonString = typeof data === 'string' ? data : JSON.stringify(data, null, 2);
            const blob = new Blob([jsonString], { type: 'application/json' });
            const url = URL.createObjectURL(blob);

            const link = document.createElement('a');
            link.href = url;
            link.download = filename;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            URL.revokeObjectURL(url);

            this.addAuditEntry('data_downloaded', { filename: filename, size: jsonString.length });
            console.log(`⬇️ [JUPITER-EXPORT] Downloaded: ${filename}`);
            return true;

        } catch (error) {
            console.error("❌ [JUPITER-EXPORT] Download failed:", error);
            this.addAuditEntry('download_failed', { filename: filename, error: error.message });
            return false;
        }
    }

    /**
     * Get export history
     */
    getExportHistory() {
        return {
            total_exports: this.exportHistory.length,
            recent_exports: this.exportHistory.slice(0, 20),
            export_types: [...new Set(this.exportHistory.map(e => e.type))],
            total_size: this.exportHistory.reduce((acc, e) => acc + (e.size || 0), 0)
        };
    }

    /**
     * Validate exported data integrity
     */
    validateExportData(data) {
        const validation = {
            valid: true,
            errors: [],
            warnings: [],
            checks_performed: []
        };

        try {
            // Check required metadata
            validation.checks_performed.push('metadata_check');
            if (!data.metadata || !data.metadata.timestamp) {
                validation.errors.push('Missing required metadata');
                validation.valid = false;
            }

            // Check tracking data structure
            validation.checks_performed.push('tracking_data_structure');
            if (data.tracking_data) {
                if (!Array.isArray(data.tracking_data.persons)) {
                    validation.errors.push('Invalid persons data structure');
                    validation.valid = false;
                }
                if (!Array.isArray(data.tracking_data.zones)) {
                    validation.errors.push('Invalid zones data structure');
                    validation.valid = false;
                }
                if (!Array.isArray(data.tracking_data.incidents)) {
                    validation.errors.push('Invalid incidents data structure');
                    validation.valid = false;
                }
            }

            // Check data consistency
            validation.checks_performed.push('data_consistency');
            if (data.tracking_data) {
                const personsWithInvalidCoords = data.tracking_data.persons.filter(p =>
                    !p.position || typeof p.position.lat !== 'number' || typeof p.position.lng !== 'number'
                );
                if (personsWithInvalidCoords.length > 0) {
                    validation.warnings.push(`${personsWithInvalidCoords.length} persons with invalid coordinates`);
                }

                const zonesWithInvalidArea = data.tracking_data.zones.filter(z =>
                    !z.coordinates || !Array.isArray(z.coordinates) || z.coordinates.length < 3
                );
                if (zonesWithInvalidArea.length > 0) {
                    validation.warnings.push(`${zonesWithInvalidArea.length} zones with invalid geometry`);
                }
            }

            // Check timestamp validity
            validation.checks_performed.push('timestamp_validity');
            if (data.metadata && data.metadata.timestamp) {
                const exportTime = new Date(data.metadata.timestamp);
                const now = new Date();
                if (exportTime > now || (now - exportTime) > 24 * 60 * 60 * 1000) {
                    validation.warnings.push('Export timestamp is suspicious');
                }
            }

        } catch (error) {
            validation.errors.push(`Validation error: ${error.message}`);
            validation.valid = false;
        }

        this.addAuditEntry('data_validation_performed', {
            valid: validation.valid,
            errors_count: validation.errors.length,
            warnings_count: validation.warnings.length
        });

        return validation;
    }

    /**
     * Get session ID for audit tracking
     */
    getSessionId() {
        if (!this.sessionId) {
            this.sessionId = `sshr_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        }
        return this.sessionId;
    }

    /**
     * Clear audit log and export history
     */
    clearAuditData(confirm = false) {
        if (!confirm) {
            console.warn("⚠️ [JUPITER-AUDIT] Use clearAuditData(true) to confirm deletion");
            return false;
        }

        const clearedEntries = this.auditLog.length;
        const clearedExports = this.exportHistory.length;

        this.auditLog = [];
        this.exportHistory = [];

        console.log(`🗑️ [JUPITER-AUDIT] Cleared ${clearedEntries} audit entries and ${clearedExports} export records`);

        // Add final entry about the clearing
        this.addAuditEntry('audit_data_cleared', {
            cleared_audit_entries: clearedEntries,
            cleared_export_records: clearedExports
        });

        return true;
    }

    // =========================================
    // GEOPROCESSING WORKFLOW
    // =========================================

    /**
     * Comprehensive geoprocessing workflow for zone optimization
     */
    async runGeoprocessingWorkflow(options = {}) {
        const {
            optimizeZones = true,
            analyzeCoverage = true,
            detectOverlaps = true,
            suggestNewZones = true,
            calculateRiskAreas = true,
            generateHeatMap = false
        } = options;

        console.log("🌍 [JUPITER-GEOPROCESSING] Starting comprehensive geoprocessing workflow...");
        this.addAuditEntry('geoprocessing_workflow_started', { options: options });

        const workflowResults = {
            timestamp: new Date().toISOString(),
            workflow_id: `geoprocessing_${Date.now()}`,
            results: {},
            recommendations: [],
            performance_metrics: {}
        };

        const startTime = Date.now();

        try {
            // Step 1: Collect current spatial data
            console.log("📊 [GEOPROCESSING] Step 1: Collecting spatial data...");
            const spatialData = await this.collectSpatialData();
            workflowResults.results.spatial_data = spatialData;

            // Step 2: Zone optimization
            if (optimizeZones && spatialData.zones.length > 0) {
                console.log("🔧 [GEOPROCESSING] Step 2: Optimizing zones...");
                const zoneOptimization = await this.optimizeZoneGeometry(spatialData.zones);
                workflowResults.results.zone_optimization = zoneOptimization;
                workflowResults.recommendations.push(...zoneOptimization.recommendations);
            }

            // Step 3: Coverage analysis
            if (analyzeCoverage) {
                console.log("🎯 [GEOPROCESSING] Step 3: Analyzing coverage...");
                const coverageAnalysis = await this.analyzeSpatialCoverage(spatialData);
                workflowResults.results.coverage_analysis = coverageAnalysis;
                workflowResults.recommendations.push(...coverageAnalysis.recommendations);
            }

            // Step 4: Overlap detection
            if (detectOverlaps && spatialData.zones.length > 1) {
                console.log("🔍 [GEOPROCESSING] Step 4: Detecting overlaps...");
                const overlapAnalysis = await this.detectZoneOverlaps(spatialData.zones);
                workflowResults.results.overlap_analysis = overlapAnalysis;
                if (overlapAnalysis.overlaps.length > 0) {
                    workflowResults.recommendations.push(...overlapAnalysis.recommendations);
                }
            }

            // Step 5: New zone suggestions
            if (suggestNewZones) {
                console.log("💡 [GEOPROCESSING] Step 5: Suggesting new zones...");
                const zoneSuggestions = await this.suggestOptimalZones(spatialData);
                workflowResults.results.zone_suggestions = zoneSuggestions;
                workflowResults.recommendations.push(...zoneSuggestions.recommendations);
            }

            // Step 6: Risk area calculation
            if (calculateRiskAreas) {
                console.log("⚠️ [GEOPROCESSING] Step 6: Calculating risk areas...");
                const riskAnalysis = await this.calculateRiskAreas(spatialData);
                workflowResults.results.risk_analysis = riskAnalysis;
                workflowResults.recommendations.push(...riskAnalysis.recommendations);
            }

            // Step 7: Heat map generation (optional)
            if (generateHeatMap) {
                console.log("🌡️ [GEOPROCESSING] Step 7: Generating heat map...");
                const heatMapData = await this.generateSpatialHeatMap(spatialData);
                workflowResults.results.heat_map = heatMapData;
            }

            const endTime = Date.now();
            workflowResults.performance_metrics = {
                total_processing_time: endTime - startTime,
                steps_completed: Object.keys(workflowResults.results).length,
                recommendations_generated: workflowResults.recommendations.length
            };

            this.addAuditEntry('geoprocessing_workflow_completed', {
                workflow_id: workflowResults.workflow_id,
                processing_time: workflowResults.performance_metrics.total_processing_time,
                recommendations_count: workflowResults.recommendations.length
            });

            console.log(`✅ [JUPITER-GEOPROCESSING] Workflow completed in ${workflowResults.performance_metrics.total_processing_time}ms`);

            // Emit geoprocessing results event
            window.dispatchEvent(new CustomEvent('jupiter-geoprocessing-completed', {
                detail: workflowResults
            }));

            return workflowResults;

        } catch (error) {
            console.error("❌ [JUPITER-GEOPROCESSING] Workflow failed:", error);
            this.addAuditEntry('geoprocessing_workflow_failed', { error: error.message });
            throw error;
        }
    }

    /**
     * Collect and structure spatial data for geoprocessing
     */
    async collectSpatialData() {
        const data = this.exportSSHRData();

        return {
            bounds: this.calculateFacilityBounds(),
            zones: data.tracking_data.zones.map(zone => ({
                ...zone,
                centroid: this.calculatePolygonCentroid(zone.coordinates),
                area: this.calculatePolygonArea(zone.coordinates),
                perimeter: this.calculatePolygonPerimeter(zone.coordinates)
            })),
            persons: data.tracking_data.persons.map(person => ({
                ...person,
                zone_assignments: this.getPersonZoneAssignments(person, data.tracking_data.zones)
            })),
            incidents: data.tracking_data.incidents,
            facility_metadata: {
                total_area: this.calculateFacilityArea(),
                person_density: data.tracking_data.persons.length / this.calculateFacilityArea(),
                zone_coverage_ratio: this.calculateZoneCoverageRatio(data.tracking_data.zones)
            }
        };
    }

    /**
     * Optimize zone geometry for better efficiency
     */
    async optimizeZoneGeometry(zones) {
        const optimizations = [];
        const recommendations = [];

        for (const zone of zones) {
            const optimization = {
                zone_id: zone.id,
                original_area: zone.area,
                original_perimeter: zone.perimeter,
                optimizations_applied: []
            };

            // Check for irregular shapes
            const irregularityScore = this.calculateShapeIrregularity(zone.coordinates);
            if (irregularityScore > 0.7) {
                optimization.optimizations_applied.push('shape_regularization');
                optimization.suggested_shape = this.suggestRegularShape(zone.coordinates);
                recommendations.push({
                    type: 'optimize_zone_shape',
                    priority: 'medium',
                    zone_id: zone.id,
                    description: `Zóna ${zone.name || zone.id} má velmi nepravidelný tvar (${Math.round(irregularityScore * 100)}% nepravidelnost)`,
                    suggested_action: 'Upravit hranice pro lepší pokrytí'
                });
            }

            // Check for optimal size
            const optimalArea = this.calculateOptimalZoneArea(zone);
            if (Math.abs(zone.area - optimalArea) > optimalArea * 0.3) {
                optimization.optimizations_applied.push('size_adjustment');
                optimization.suggested_area = optimalArea;
                recommendations.push({
                    type: 'adjust_zone_size',
                    priority: zone.area < optimalArea * 0.5 ? 'high' : 'medium',
                    zone_id: zone.id,
                    description: `Zóna ${zone.name || zone.id} má neoptimální velikost (${zone.area}m² vs doporučených ${optimalArea}m²)`,
                    suggested_action: zone.area < optimalArea ? 'Rozšířit zónu' : 'Zmenšit zónu'
                });
            }

            // Check for coverage efficiency
            const coverageEfficiency = this.calculateZoneCoverageEfficiency(zone);
            if (coverageEfficiency < 0.6) {
                optimization.optimizations_applied.push('coverage_improvement');
                recommendations.push({
                    type: 'improve_zone_coverage',
                    priority: 'medium',
                    zone_id: zone.id,
                    description: `Zóna ${zone.name || zone.id} má nízkou efektivitu pokrytí (${Math.round(coverageEfficiency * 100)}%)`,
                    suggested_action: 'Přemístit nebo přeformátovat zónu'
                });
            }

            optimizations.push(optimization);
        }

        return {
            zones_analyzed: zones.length,
            optimizations: optimizations,
            recommendations: recommendations,
            overall_efficiency_score: this.calculateOverallZoneEfficiency(zones)
        };
    }

    /**
     * Analyze spatial coverage of zones
     */
    async analyzeSpatialCoverage(spatialData) {
        const facilityBounds = spatialData.bounds;
        const zones = spatialData.zones;
        const persons = spatialData.persons;

        // Calculate covered area
        const totalCoveredArea = this.calculateTotalCoveredArea(zones);
        const facilityArea = this.calculateFacilityArea();
        const coveragePercentage = (totalCoveredArea / facilityArea) * 100;

        // Find uncovered areas
        const uncoveredAreas = this.findUncoveredAreas(facilityBounds, zones);

        // Calculate person coverage
        const personsInZones = persons.filter(p => p.zone_assignments.length > 0);
        const personCoveragePercentage = (personsInZones.length / persons.length) * 100;

        // Generate coverage recommendations
        const recommendations = [];

        if (coveragePercentage < 60) {
            recommendations.push({
                type: 'increase_coverage',
                priority: 'high',
                description: `Nízké pokrytí areálu zónami (${Math.round(coveragePercentage)}%)`,
                suggested_action: 'Přidat další zóny nebo rozšířit stávající'
            });
        }

        if (personCoveragePercentage < 80) {
            recommendations.push({
                type: 'improve_person_coverage',
                priority: 'medium',
                description: `${Math.round(100 - personCoveragePercentage)}% osob není pokryto zónami`,
                suggested_action: 'Optimalizovat umístění zón podle pohybu osob'
            });
        }

        // Identify critical uncovered areas
        uncoveredAreas.forEach((area, index) => {
            if (area.risk_level === 'high') {
                recommendations.push({
                    type: 'cover_critical_area',
                    priority: 'high',
                    description: `Kritická nepokrytá oblast detekována`,
                    suggested_location: area.centroid,
                    suggested_action: 'Vytvořit novou zónu v této oblasti'
                });
            }
        });

        return {
            coverage_percentage: coveragePercentage,
            person_coverage_percentage: personCoveragePercentage,
            uncovered_areas: uncoveredAreas,
            coverage_efficiency: this.calculateCoverageEfficiency(zones, persons),
            recommendations: recommendations
        };
    }

    /**
     * Detect overlapping zones
     */
    async detectZoneOverlaps(zones) {
        const overlaps = [];
        const recommendations = [];

        for (let i = 0; i < zones.length; i++) {
            for (let j = i + 1; j < zones.length; j++) {
                const zoneA = zones[i];
                const zoneB = zones[j];

                const overlapArea = this.calculatePolygonOverlap(zoneA.coordinates, zoneB.coordinates);

                if (overlapArea > 0) {
                    const overlapPercentageA = (overlapArea / zoneA.area) * 100;
                    const overlapPercentageB = (overlapArea / zoneB.area) * 100;

                    const overlap = {
                        zone_a: { id: zoneA.id, name: zoneA.name },
                        zone_b: { id: zoneB.id, name: zoneB.name },
                        overlap_area: overlapArea,
                        overlap_percentage_a: overlapPercentageA,
                        overlap_percentage_b: overlapPercentageB,
                        severity: this.determineOverlapSeverity(overlapPercentageA, overlapPercentageB)
                    };

                    overlaps.push(overlap);

                    if (overlap.severity === 'high') {
                        recommendations.push({
                            type: 'resolve_zone_overlap',
                            priority: 'high',
                            description: `Významné překrytí mezi zónami ${zoneA.name || zoneA.id} a ${zoneB.name || zoneB.id} (${Math.round(Math.max(overlapPercentageA, overlapPercentageB))}%)`,
                            suggested_action: 'Upravit hranice zón pro odstranění překrytí'
                        });
                    }
                }
            }
        }

        return {
            overlaps_detected: overlaps.length,
            overlaps: overlaps,
            total_overlap_area: overlaps.reduce((sum, o) => sum + o.overlap_area, 0),
            recommendations: recommendations
        };
    }

    /**
     * Suggest optimal new zones based on data analysis
     */
    async suggestOptimalZones(spatialData) {
        const suggestions = [];
        const recommendations = [];

        // Analyze person movement patterns
        const personHotspots = this.identifyPersonHotspots(spatialData.persons);

        // Analyze incident patterns
        const incidentClusters = this.identifyIncidentClusters(spatialData.incidents);

        // Find gaps in coverage
        const coverageGaps = this.findCoverageGaps(spatialData);

        // Generate zone suggestions for hotspots
        personHotspots.forEach((hotspot, index) => {
            if (hotspot.person_count > 2 && !this.isAreaCovered(hotspot.location, spatialData.zones)) {
                suggestions.push({
                    type: 'person_hotspot_zone',
                    priority: hotspot.person_count > 5 ? 'high' : 'medium',
                    suggested_location: hotspot.location,
                    suggested_radius: this.calculateOptimalRadius(hotspot.person_count),
                    zone_type: 'GREEN',
                    reason: `Vysoká koncentrace osob (${hotspot.person_count} osob)`
                });

                recommendations.push({
                    type: 'create_hotspot_zone',
                    priority: hotspot.person_count > 5 ? 'high' : 'medium',
                    description: `Vytvořit zónu pro koncentraci ${hotspot.person_count} osob`,
                    suggested_location: hotspot.location,
                    suggested_action: 'Vytvořit GREEN zónu pro monitorování'
                });
            }
        });

        // Generate zone suggestions for incident areas
        incidentClusters.forEach((cluster, index) => {
            if (cluster.incident_count > 1) {
                suggestions.push({
                    type: 'incident_cluster_zone',
                    priority: 'high',
                    suggested_location: cluster.location,
                    suggested_radius: this.calculateOptimalRadius(cluster.incident_count * 2),
                    zone_type: 'RED',
                    reason: `Opakované incidenty (${cluster.incident_count} incidentů)`
                });

                recommendations.push({
                    type: 'create_security_zone',
                    priority: 'high',
                    description: `Vytvořit bezpečnostní zónu pro ${cluster.incident_count} incidentů`,
                    suggested_location: cluster.location,
                    suggested_action: 'Vytvořit RED zónu pro zvýšenou bezpečnost'
                });
            }
        });

        // Generate suggestions for coverage gaps
        coverageGaps.forEach((gap, index) => {
            if (gap.importance > 0.6) {
                suggestions.push({
                    type: 'coverage_gap_zone',
                    priority: 'medium',
                    suggested_location: gap.location,
                    suggested_radius: gap.suggested_radius,
                    zone_type: 'GREEN',
                    reason: 'Nepokrytá oblast s potenciálem pro monitoring'
                });

                recommendations.push({
                    type: 'fill_coverage_gap',
                    priority: 'medium',
                    description: 'Doplnit pokrytí v nepokryté oblasti',
                    suggested_location: gap.location,
                    suggested_action: 'Vytvořit GREEN zónu pro kompletní pokrytí'
                });
            }
        });

        return {
            total_suggestions: suggestions.length,
            suggestions: suggestions,
            hotspots_analyzed: personHotspots.length,
            incident_clusters_found: incidentClusters.length,
            coverage_gaps_found: coverageGaps.length,
            recommendations: recommendations
        };
    }

    /**
     * Calculate risk areas based on various factors
     */
    async calculateRiskAreas(spatialData) {
        const riskAreas = [];
        const recommendations = [];

        // Calculate risk for each grid cell in facility
        const gridSize = 50; // 50m grid
        const riskGrid = this.createRiskGrid(spatialData.bounds, gridSize);

        // Analyze risk factors
        for (let x = 0; x < riskGrid.width; x++) {
            for (let y = 0; y < riskGrid.height; y++) {
                const cellLocation = this.gridToLocation(x, y, riskGrid);
                const riskScore = this.calculateCellRiskScore(cellLocation, spatialData);

                if (riskScore > 0.7) {
                    riskAreas.push({
                        location: cellLocation,
                        risk_score: riskScore,
                        risk_factors: this.identifyRiskFactors(cellLocation, spatialData),
                        recommended_action: this.suggestRiskMitigation(riskScore, cellLocation)
                    });
                }
            }
        }

        // Sort by risk score
        riskAreas.sort((a, b) => b.risk_score - a.risk_score);

        // Generate recommendations for high-risk areas
        riskAreas.slice(0, 5).forEach((area, index) => {
            recommendations.push({
                type: 'mitigate_risk_area',
                priority: area.risk_score > 0.9 ? 'critical' : 'high',
                description: `Vysokoriziková oblast (skóre: ${Math.round(area.risk_score * 100)}%)`,
                suggested_location: area.location,
                suggested_action: area.recommended_action
            });
        });

        return {
            total_risk_areas: riskAreas.length,
            high_risk_areas: riskAreas.filter(area => area.risk_score > 0.8).length,
            critical_risk_areas: riskAreas.filter(area => area.risk_score > 0.9).length,
            risk_areas: riskAreas.slice(0, 10), // Top 10 risk areas
            average_risk_score: riskAreas.length > 0 ? riskAreas.reduce((sum, area) => sum + area.risk_score, 0) / riskAreas.length : 0,
            recommendations: recommendations
        };
    }

    /**
     * Generate spatial heat map data
     */
    async generateSpatialHeatMap(spatialData) {
        const heatMapData = {
            type: 'FeatureCollection',
            features: [],
            metadata: {
                timestamp: new Date().toISOString(),
                grid_size: 25, // 25m grid
                intensity_type: 'person_density'
            }
        };

        const gridSize = 25;
        const bounds = spatialData.bounds;
        const width = Math.ceil((bounds.east - bounds.west) / gridSize);
        const height = Math.ceil((bounds.north - bounds.south) / gridSize);

        for (let x = 0; x < width; x++) {
            for (let y = 0; y < height; y++) {
                const cellBounds = {
                    west: bounds.west + (x * gridSize),
                    east: bounds.west + ((x + 1) * gridSize),
                    south: bounds.south + (y * gridSize),
                    north: bounds.south + ((y + 1) * gridSize)
                };

                const intensity = this.calculateCellIntensity(cellBounds, spatialData);

                if (intensity > 0) {
                    heatMapData.features.push({
                        type: 'Feature',
                        geometry: {
                            type: 'Polygon',
                            coordinates: [[
                                [cellBounds.west, cellBounds.south],
                                [cellBounds.east, cellBounds.south],
                                [cellBounds.east, cellBounds.north],
                                [cellBounds.west, cellBounds.north],
                                [cellBounds.west, cellBounds.south]
                            ]]
                        },
                        properties: {
                            intensity: intensity,
                            person_count: this.countPersonsInBounds(cellBounds, spatialData.persons),
                            incident_count: this.countIncidentsInBounds(cellBounds, spatialData.incidents)
                        }
                    });
                }
            }
        }

        return heatMapData;
    }

    // =========================================
    // GEOPROCESSING UTILITY METHODS
    // =========================================

    calculateFacilityBounds() {
        // Mock facility bounds for Bohuslavice
        return {
            north: 49.7430,
            south: 49.7410,
            east: 18.2640,
            west: 18.2610
        };
    }

    calculatePolygonCentroid(coordinates) {
        if (!coordinates || coordinates.length === 0) return { lat: 0, lng: 0 };

        const sumLat = coordinates.reduce((sum, coord) => sum + coord[1], 0);
        const sumLng = coordinates.reduce((sum, coord) => sum + coord[0], 0);

        return {
            lat: sumLat / coordinates.length,
            lng: sumLng / coordinates.length
        };
    }

    calculatePolygonPerimeter(coordinates) {
        if (!coordinates || coordinates.length < 2) return 0;

        let perimeter = 0;
        for (let i = 0; i < coordinates.length - 1; i++) {
            perimeter += this.calculateDistance(coordinates[i], coordinates[i + 1]);
        }
        return perimeter;
    }

    calculateDistance(coord1, coord2) {
        const R = 6371000; // Earth's radius in meters
        const dLat = (coord2[1] - coord1[1]) * Math.PI / 180;
        const dLon = (coord2[0] - coord1[0]) * Math.PI / 180;
        const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
                  Math.cos(coord1[1] * Math.PI / 180) * Math.cos(coord2[1] * Math.PI / 180) *
                  Math.sin(dLon/2) * Math.sin(dLon/2);
        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
        return R * c;
    }

    calculateFacilityArea() {
        const bounds = this.calculateFacilityBounds();
        const width = this.calculateDistance([bounds.west, bounds.south], [bounds.east, bounds.south]);
        const height = this.calculateDistance([bounds.west, bounds.south], [bounds.west, bounds.north]);
        return width * height; // Approximate area in m²
    }

    calculateShapeIrregularity(coordinates) {
        if (!coordinates || coordinates.length < 4) return 1;

        const area = this.calculatePolygonArea(coordinates);
        const perimeter = this.calculatePolygonPerimeter(coordinates);
        const circularArea = Math.pow(perimeter, 2) / (4 * Math.PI);

        return Math.abs(area - circularArea) / circularArea;
    }

    determineOverlapSeverity(percentageA, percentageB) {
        const maxPercentage = Math.max(percentageA, percentageB);
        if (maxPercentage > 50) return 'high';
        if (maxPercentage > 20) return 'medium';
        return 'low';
    }

    // Mock implementations for demo purposes
    getPersonZoneAssignments(person, zones) { return []; }
    calculateZoneCoverageRatio(zones) { return 0.7; }
    suggestRegularShape(coordinates) { return coordinates; }
    calculateOptimalZoneArea(zone) { return zone.area * 1.2; }
    calculateZoneCoverageEfficiency(zone) { return 0.75; }
    calculateOverallZoneEfficiency(zones) { return 0.68; }
    calculateTotalCoveredArea(zones) { return zones.reduce((sum, z) => sum + z.area, 0); }
    findUncoveredAreas(bounds, zones) { return []; }
    calculateCoverageEfficiency(zones, persons) { return 0.72; }
    calculatePolygonOverlap(coordsA, coordsB) { return 0; }
    identifyPersonHotspots(persons) { return []; }
    identifyIncidentClusters(incidents) { return []; }
    findCoverageGaps(spatialData) { return []; }
    isAreaCovered(location, zones) { return false; }
    calculateOptimalRadius(count) { return Math.max(20, Math.min(100, count * 10)); }
    createRiskGrid(bounds, gridSize) { return { width: 10, height: 10 }; }
    gridToLocation(x, y, grid) { return { lat: 49.7420, lng: 18.2625 }; }
    calculateCellRiskScore(location, spatialData) { return Math.random(); }
    identifyRiskFactors(location, spatialData) { return ['person_density', 'incident_history']; }
    suggestRiskMitigation(riskScore, location) { return 'Zvýšit monitoring v této oblasti'; }
    calculateCellIntensity(bounds, spatialData) { return Math.random(); }
    countPersonsInBounds(bounds, persons) { return Math.floor(Math.random() * 5); }
    countIncidentsInBounds(bounds, incidents) { return Math.floor(Math.random() * 2); }
}

// Global initialization
window.SSHRJupiterGIS = null;

/**
 * Initialize Jupiter GIS connector
 */
function initializeJupiterGIS() {
    if (!window.SSHRJupiterGIS) {
        console.log("🪐 [JUPITER-GIS] Initializing Jupiter GIS Connector...");
        window.SSHRJupiterGIS = new SSHRJupiterGISConnector(window.SSHR);

        // Expose global API
        window.SSHR = window.SSHR || {};
        window.SSHR.jupiterGIS = window.SSHRJupiterGIS;

        console.log("✅ [JUPITER-GIS] Jupiter GIS Connector ready!");
        console.log("🔧 [JUPITER-GIS] Access via window.SSHR.jupiterGIS");
    }
}

// Auto-initialize when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initializeJupiterGIS);
} else {
    setTimeout(initializeJupiterGIS, 500);
}

console.log("📦 [JUPITER-GIS] Jupiter GIS Connector v1.0.0 loaded!");
