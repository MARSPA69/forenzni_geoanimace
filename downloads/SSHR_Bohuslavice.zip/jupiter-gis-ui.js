/**
 * Jupiter GIS UI Module
 * ====================
 *
 * Advanced UI components for Jupiter GIS insights display
 * Features: Sidebar panel, detailed analytics, zone recommendations, alerts
 */

console.log("🎨 [JUPITER-UI] Loading Jupiter GIS UI Module...");

class JupiterGISUI {
    constructor() {
        this.isVisible = false;
        this.currentInsights = null;
        this.alertQueue = [];
        this.recommendations = [];

        this.initializeUI();
        this.setupEventListeners();

        console.log("🎨 [JUPITER-UI] Jupiter GIS UI Module initialized");
    }

    /**
     * Initialize UI components
     */
    initializeUI() {
        this.createJupiterSidebarPanel();
        this.createAlertSystem();
        this.createRecommendationPanel();
    }

    /**
     * Create Jupiter GIS sidebar panel
     */
    createJupiterSidebarPanel() {
        // Find SSHR sidebar and add Jupiter panel
        const sidebarNav = document.querySelector('.sidebar-nav, .nav-sidebar');
        if (!sidebarNav) {
            console.warn("⚠️ [JUPITER-UI] Sidebar not found, creating standalone panel");
            this.createStandalonePanel();
            return;
        }

        const jupiterPanel = document.createElement('li');
        jupiterPanel.className = 'nav-item';
        jupiterPanel.innerHTML = `
            <a class="nav-link" data-bs-toggle="collapse" href="#jupiter-insights-panel" role="button">
                <i class="nav-icon fas fa-satellite"></i>
                <p>
                    Jupiter GIS
                    <i class="right fas fa-angle-left"></i>
                    <span id="jupiter-status-badge" class="badge badge-info right">Mock</span>
                </p>
            </a>
            <div class="collapse" id="jupiter-insights-panel">
                <div class="card card-body" style="margin: 10px; background: rgba(20, 184, 166, 0.1); border: 1px solid rgba(20, 184, 166, 0.3);">

                    <!-- Configuration Section -->
                    <div class="mb-3">
                        <h6 class="text-teal-400">⚙️ Configuration</h6>
                        <div class="row">
                            <div class="col-6">
                                <select id="jupiter-environment-select" class="form-select form-select-sm">
                                    <option value="development">Development</option>
                                    <option value="staging">Staging</option>
                                    <option value="production">Production</option>
                                </select>
                            </div>
                            <div class="col-6">
                                <div class="form-check form-switch">
                                    <input class="form-check-input" type="checkbox" id="jupiter-mock-toggle" checked>
                                    <label class="form-check-label" for="jupiter-mock-toggle" style="font-size: 11px;">Mock Mode</label>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Risk Assessment -->
                    <div class="mb-3">
                        <h6 class="text-teal-400">🎯 Risk Assessment</h6>
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <span style="font-size: 12px;">Overall Risk Score:</span>
                            <span id="jupiter-detailed-risk-score" class="badge bg-success">85</span>
                        </div>
                        <div class="progress" style="height: 8px;">
                            <div id="jupiter-risk-progress" class="progress-bar bg-success" style="width: 85%"></div>
                        </div>
                        <div id="jupiter-risk-factors" class="mt-2" style="font-size: 10px;">
                            <div>• 3 persons in facility</div>
                            <div>• 2 active zones</div>
                            <div>• 0 incidents</div>
                        </div>
                    </div>

                    <!-- Pattern Analysis -->
                    <div class="mb-3">
                        <h6 class="text-teal-400">🔍 Pattern Analysis</h6>
                        <div id="jupiter-patterns-list" style="font-size: 11px;">
                            <div class="text-muted">No patterns detected</div>
                        </div>
                    </div>

                    <!-- Anomaly Detection -->
                    <div class="mb-3">
                        <h6 class="text-teal-400">⚠️ Anomaly Detection</h6>
                        <div id="jupiter-anomalies-list" style="font-size: 11px;">
                            <div class="text-muted">No anomalies detected</div>
                        </div>
                    </div>

                    <!-- Zone Optimization -->
                    <div class="mb-3">
                        <h6 class="text-teal-400">📐 Zone Optimization</h6>
                        <div class="row text-center" style="font-size: 11px;">
                            <div class="col-6">
                                <div>Efficiency</div>
                                <span id="jupiter-zone-efficiency" class="badge bg-info">--</span>
                            </div>
                            <div class="col-6">
                                <div>Coverage</div>
                                <span id="jupiter-zone-coverage" class="badge bg-info">--</span>
                            </div>
                        </div>
                        <div id="jupiter-zone-recommendations" class="mt-2" style="font-size: 10px;">
                            <div class="text-muted">No recommendations</div>
                        </div>
                    </div>

                    <!-- Actions -->
                    <div class="d-grid gap-2">
                        <button id="jupiter-trigger-analysis" class="btn btn-sm btn-outline-info">
                            <i class="fas fa-play"></i> Trigger Analysis
                        </button>
                        <button id="jupiter-export-data" class="btn btn-sm btn-outline-secondary">
                            <i class="fas fa-download"></i> Export Data
                        </button>
                    </div>

                    <!-- Connection Status -->
                    <div class="mt-2 text-center">
                        <small id="jupiter-connection-details" class="text-muted">
                            Connecting to Jupiter GIS...
                        </small>
                    </div>
                </div>
            </div>
        `;

        sidebarNav.appendChild(jupiterPanel);
        console.log("✅ [JUPITER-UI] Sidebar panel created");
    }

    /**
     * Create standalone panel if sidebar not found
     */
    createStandalonePanel() {
        const container = document.createElement('div');
        container.id = 'jupiter-standalone-panel';
        container.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            width: 300px;
            background: rgba(28, 25, 23, 0.95);
            border: 1px solid rgba(20, 184, 166, 0.3);
            border-radius: 8px;
            padding: 15px;
            z-index: 1000;
            color: #14b8a6;
            font-size: 12px;
            display: none;
        `;

        container.innerHTML = `
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h6 class="text-teal-400 mb-0">🪐 Jupiter GIS</h6>
                <button id="jupiter-panel-close" class="btn btn-sm btn-outline-secondary">×</button>
            </div>
            <div id="jupiter-panel-content">
                <!-- Content will be populated by updateUI -->
            </div>
        `;

        document.body.appendChild(container);

        // Add toggle button
        const toggleBtn = document.createElement('button');
        toggleBtn.id = 'jupiter-panel-toggle';
        toggleBtn.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: #14b8a6;
            color: white;
            border: none;
            border-radius: 50%;
            width: 50px;
            height: 50px;
            z-index: 999;
            cursor: pointer;
        `;
        toggleBtn.innerHTML = '🪐';
        toggleBtn.onclick = () => this.togglePanel();

        document.body.appendChild(toggleBtn);
        console.log("✅ [JUPITER-UI] Standalone panel created");
    }

    /**
     * Create alert system
     */
    createAlertSystem() {
        const alertContainer = document.createElement('div');
        alertContainer.id = 'jupiter-alerts-container';
        alertContainer.style.cssText = `
            position: fixed;
            top: 80px;
            right: 20px;
            width: 300px;
            z-index: 1001;
        `;

        document.body.appendChild(alertContainer);
        console.log("✅ [JUPITER-UI] Alert system created");
    }

    /**
     * Create recommendation panel
     */
    createRecommendationPanel() {
        // Will be integrated into main panel
        console.log("✅ [JUPITER-UI] Recommendation panel integrated");
    }

    /**
     * Setup event listeners
     */
    setupEventListeners() {
        // Jupiter analysis updates
        window.addEventListener('jupiter-analysis-updated', (event) => {
            this.updateInsights(event.detail);
        });

        // Jupiter reactive analysis
        window.addEventListener('jupiter-reactive-analysis', (event) => {
            this.updateInsights(event.detail.analysis, event.detail.eventType);
        });

        // Jupiter alerts
        window.addEventListener('jupiter-alert', (event) => {
            this.showAlert(event.detail);
        });

        // Jupiter zone recommendations
        window.addEventListener('jupiter-zone-recommendation', (event) => {
            this.showRecommendation(event.detail);
        });

        // UI Controls
        this.setupUIControls();

        console.log("✅ [JUPITER-UI] Event listeners setup complete");
    }

    /**
     * Setup UI control event listeners
     */
    setupUIControls() {
        // Environment selector
        const envSelect = document.getElementById('jupiter-environment-select');
        if (envSelect) {
            envSelect.addEventListener('change', (e) => {
                if (window.SSHR?.jupiterConfig) {
                    window.SSHR.jupiterConfig.switchEnvironment(e.target.value);
                }
            });
        }

        // Mock mode toggle
        const mockToggle = document.getElementById('jupiter-mock-toggle');
        if (mockToggle) {
            mockToggle.addEventListener('change', (e) => {
                if (window.SSHR?.jupiterConfig) {
                    window.SSHR.jupiterConfig.setMockMode(e.target.checked);
                }
            });
        }

        // Trigger analysis button
        const triggerBtn = document.getElementById('jupiter-trigger-analysis');
        if (triggerBtn) {
            triggerBtn.addEventListener('click', () => {
                if (window.SSHR?.jupiterGIS) {
                    window.SSHR.jupiterGIS.triggerImmediateAnalysis();
                }
            });
        }

        // Export data button
        const exportBtn = document.getElementById('jupiter-export-data');
        if (exportBtn) {
            exportBtn.addEventListener('click', () => {
                this.exportAnalysisData();
            });
        }

        // Panel close button (for standalone)
        const closeBtn = document.getElementById('jupiter-panel-close');
        if (closeBtn) {
            closeBtn.addEventListener('click', () => {
                this.togglePanel();
            });
        }
    }

    /**
     * Update insights display
     */
    updateInsights(analysis, triggerEvent = null) {
        console.log(`🎨 [JUPITER-UI] Updating insights display${triggerEvent ? ` (triggered by: ${triggerEvent})` : ''}`);

        this.currentInsights = analysis;

        // Update risk assessment
        this.updateRiskDisplay(analysis.risk_assessment);

        // Update patterns
        this.updatePatternsDisplay(analysis.pattern_analysis);

        // Update anomalies
        this.updateAnomaliesDisplay(analysis.anomaly_detection);

        // Update zone optimization
        this.updateZoneOptimizationDisplay(analysis.zone_optimization);

        // Update connection status
        this.updateConnectionStatus();

        // Update status badge
        this.updateStatusBadge(analysis);
    }

    /**
     * Update risk assessment display
     */
    updateRiskDisplay(riskAssessment) {
        if (!riskAssessment) return;

        const scoreElement = document.getElementById('jupiter-detailed-risk-score');
        const progressElement = document.getElementById('jupiter-risk-progress');
        const factorsElement = document.getElementById('jupiter-risk-factors');

        if (scoreElement) {
            scoreElement.textContent = riskAssessment.score;

            // Update color based on score
            scoreElement.className = 'badge ' +
                (riskAssessment.score >= 70 ? 'bg-success' :
                 riskAssessment.score >= 40 ? 'bg-warning' : 'bg-danger');
        }

        if (progressElement) {
            progressElement.style.width = `${riskAssessment.score}%`;
            progressElement.className = 'progress-bar ' +
                (riskAssessment.score >= 70 ? 'bg-success' :
                 riskAssessment.score >= 40 ? 'bg-warning' : 'bg-danger');
        }

        if (factorsElement && riskAssessment.factors) {
            factorsElement.innerHTML = riskAssessment.factors
                .map(factor => `<div>• ${factor}</div>`)
                .join('');
        }
    }

    /**
     * Update patterns display
     */
    updatePatternsDisplay(patternAnalysis) {
        const patternsElement = document.getElementById('jupiter-patterns-list');
        if (!patternsElement || !patternAnalysis) return;

        if (patternAnalysis.patterns && patternAnalysis.patterns.length > 0) {
            patternsElement.innerHTML = patternAnalysis.patterns
                .map(pattern => `
                    <div class="mb-1">
                        <span class="badge bg-info">${Math.round(pattern.confidence * 100)}%</span>
                        ${pattern.description}
                    </div>
                `).join('');
        } else {
            patternsElement.innerHTML = '<div class="text-muted">No patterns detected</div>';
        }
    }

    /**
     * Update anomalies display
     */
    updateAnomaliesDisplay(anomalyDetection) {
        const anomaliesElement = document.getElementById('jupiter-anomalies-list');
        if (!anomaliesElement || !anomalyDetection) return;

        if (anomalyDetection.anomalies && anomalyDetection.anomalies.length > 0) {
            anomaliesElement.innerHTML = anomalyDetection.anomalies
                .map(anomaly => `
                    <div class="mb-1">
                        <span class="badge ${anomaly.severity === 'high' ? 'bg-danger' : anomaly.severity === 'medium' ? 'bg-warning' : 'bg-info'}">${anomaly.severity}</span>
                        ${anomaly.description}
                    </div>
                `).join('');
        } else {
            anomaliesElement.innerHTML = '<div class="text-muted">No anomalies detected</div>';
        }
    }

    /**
     * Update zone optimization display
     */
    updateZoneOptimizationDisplay(zoneOptimization) {
        if (!zoneOptimization) return;

        const efficiencyElement = document.getElementById('jupiter-zone-efficiency');
        const coverageElement = document.getElementById('jupiter-zone-coverage');
        const recommendationsElement = document.getElementById('jupiter-zone-recommendations');

        if (efficiencyElement) {
            efficiencyElement.textContent = `${zoneOptimization.current_efficiency || '--'}%`;
        }

        if (coverageElement) {
            coverageElement.textContent = `${zoneOptimization.coverage_score || '--'}%`;
        }

        if (recommendationsElement && zoneOptimization.recommendations) {
            if (zoneOptimization.recommendations.length > 0) {
                recommendationsElement.innerHTML = zoneOptimization.recommendations
                    .map(rec => `
                        <div class="mb-1">
                            <span class="badge bg-warning">${rec.priority}</span>
                            ${rec.reason}
                        </div>
                    `).join('');
            } else {
                recommendationsElement.innerHTML = '<div class="text-muted">No recommendations</div>';
            }
        }
    }

    /**
     * Update connection status
     */
    updateConnectionStatus() {
        const statusElement = document.getElementById('jupiter-connection-details');
        if (!statusElement) return;

        const connector = window.SSHR?.jupiterGIS;
        if (connector) {
            const status = connector.getAnalyticsStatus();
            statusElement.innerHTML = `
                Status: ${status.connected ? '<span class="text-success">Connected</span>' : '<span class="text-warning">Disconnected</span>'}<br>
                Analyses: ${status.metrics?.totalAnalyses || 0}<br>
                Cache: ${status.cacheSize || 0} items
            `;
        }
    }

    /**
     * Update status badge
     */
    updateStatusBadge(analysis) {
        const badgeElement = document.getElementById('jupiter-status-badge');
        if (!badgeElement) return;

        const connector = window.SSHR?.jupiterGIS;
        if (connector && connector.mockMode) {
            badgeElement.textContent = 'Mock';
            badgeElement.className = 'badge badge-info right';
        } else {
            badgeElement.textContent = 'Live';
            badgeElement.className = 'badge badge-success right';
        }
    }

    /**
     * Show alert
     */
    showAlert(alertData) {
        console.log("🚨 [JUPITER-UI] Showing alert:", alertData);

        const alertContainer = document.getElementById('jupiter-alerts-container');
        if (!alertContainer) return;

        const alertElement = document.createElement('div');
        alertElement.className = `alert alert-${alertData.severity || 'warning'} alert-dismissible fade show`;
        alertElement.innerHTML = `
            <strong>Jupiter GIS Alert:</strong> ${alertData.message || alertData.description}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;

        alertContainer.appendChild(alertElement);

        // Auto-remove after 10 seconds
        setTimeout(() => {
            if (alertElement.parentNode) {
                alertElement.remove();
            }
        }, 10000);
    }

    /**
     * Show recommendation
     */
    showRecommendation(recommendation) {
        console.log("💡 [JUPITER-UI] Showing recommendation:", recommendation);
        this.recommendations.push(recommendation);

        // Show as alert for now
        this.showAlert({
            severity: 'info',
            message: `Zone Recommendation: ${recommendation.reason || recommendation.description}`
        });
    }

    /**
     * Toggle panel visibility
     */
    togglePanel() {
        const panel = document.getElementById('jupiter-standalone-panel');
        if (panel) {
            this.isVisible = !this.isVisible;
            panel.style.display = this.isVisible ? 'block' : 'none';
        }
    }

    /**
     * Export analysis data
     */
    exportAnalysisData() {
        console.log("📤 [JUPITER-UI] Exporting analysis data");

        const connector = window.SSHR?.jupiterGIS;
        if (!connector) {
            alert('Jupiter GIS connector not available');
            return;
        }

        const exportData = {
            timestamp: new Date().toISOString(),
            currentAnalysis: this.currentInsights,
            status: connector.getAnalyticsStatus(),
            recommendations: this.recommendations,
            exportedData: connector.exportSSHRData()
        };

        const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);

        const a = document.createElement('a');
        a.href = url;
        a.download = `jupiter-gis-analysis-${Date.now()}.json`;
        a.click();

        URL.revokeObjectURL(url);
        console.log("✅ [JUPITER-UI] Analysis data exported");
    }
}

// Global initialization
window.JupiterGISUI = null;

/**
 * Initialize Jupiter GIS UI
 */
function initializeJupiterGISUI() {
    if (!window.JupiterGISUI) {
        console.log("🎨 [JUPITER-UI] Initializing Jupiter GIS UI...");
        window.JupiterGISUI = new JupiterGISUI();

        // Expose global API
        window.SSHR = window.SSHR || {};
        window.SSHR.jupiterUI = window.JupiterGISUI;

        console.log("✅ [JUPITER-UI] Jupiter GIS UI ready!");
        console.log("🔧 [JUPITER-UI] Access via window.SSHR.jupiterUI");
    }
}

// Auto-initialize when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        setTimeout(initializeJupiterGISUI, 1000); // Delay to ensure other components load first
    });
} else {
    setTimeout(initializeJupiterGISUI, 1000);
}

console.log("📦 [JUPITER-UI] Jupiter GIS UI Module v1.0.0 loaded!");