/**
 * MQTT Client for SSHR NAS Communication
 * - Supports multi-host WebSocket MQTT (broker @ 1884/9002)
 * - Falls back to REST relay endpoints when WS is unavailable
 * - Maintains local retry queue for offline usage
 */

class SSHRMqttClient {
  constructor() {
    this.client = null;
    this.isConnected = false;
    this.config = null;
    this.messageQueue = [];
    this.maxQueueSize = 100;
    this.transportPriority = ['websocket', 'rest'];
    this.websocketHosts = [];
    this.restEndpoints = [];
    this.connectionTimeoutMs = 7000;
    this.activeTransport = null;
    this.activeHost = null;
    this.activeRestEndpoint = null;
    this.authToken = null;
    this.visitServiceBound = false;

    console.log('📡 [MQTT-CLIENT] Initializing SSHR MQTT Client');
  }

  async init() {
    try {
      this.config = window.SSHR_CONFIG?.mqtt || window.SSHR_CONFIG?.jupiter;
      if (!this.config || this.config.enabled === false) {
        console.log('⚠️ [MQTT-CLIENT] MQTT disabled or config missing');
        return false;
      }

      this.transportPriority = Array.isArray(this.config.transports) && this.config.transports.length
        ? this.config.transports
        : ['websocket', 'rest'];
      this.websocketHosts = this.buildWebSocketHosts();
      this.restEndpoints = this.buildRestEndpoints();
      this.connectionTimeoutMs = this.config.connectionTimeoutMs || 7000;
      this.authToken = this.config.token || window.SSHR_CONFIG?.jupiter?.token || null;

      console.log('📡 [MQTT-CLIENT] Attempting connection', {
        transports: this.transportPriority,
        websocketHosts: this.websocketHosts,
        restEndpoints: this.restEndpoints
      });

      let connected = false;
      if (this.config.mockMode) {
        this.initMockClient();
        connected = true;
      } else {
        connected = await this.connectWithFallback();
      }

      if (!connected) {
        console.warn('⚠️ [MQTT-CLIENT] All transports failed, switching to mock client');
        this.initMockClient();
      }

      this.attachVisitService();
      return connected;
    } catch (error) {
      console.error('❌ [MQTT-CLIENT] Failed to initialize MQTT:', error);
      this.initMockClient();
      this.attachVisitService();
      return false;
    }
  }

  attachVisitService() {
    if (!this.visitServiceBound && window.SSHRVisitService && typeof window.SSHRVisitService.initBackend === 'function') {
      window.SSHRVisitService.initBackend(this, null);
      this.visitServiceBound = true;
      console.log('📡 [MQTT-CLIENT] SSHRVisitService backend initialized');
    }
  }

  buildWebSocketHosts() {
    const stored = window.localStorage?.getItem('sshr_mqtt_host');
    const primary = this.config.primaryHost || this.config.host || null;
    const fallback = Array.isArray(this.config.fallbackHosts) ? this.config.fallbackHosts : [];
    const candidates = [
      stored,
      primary,
      ...fallback,
      window.location.hostname
    ].filter(host => typeof host === 'string' && host.length > 0);

    const unique = [];
    candidates.forEach((host) => {
      if (!unique.includes(host)) {
        unique.push(host);
      }
    });

    return unique;
  }

  buildRestEndpoints() {
    const stored = window.localStorage?.getItem('sshr_rest_endpoint');
    const configured = Array.isArray(this.config.restEndpoints) ? this.config.restEndpoints : [];
    const endpoints = [
      stored,
      ...configured,
      this.config.baseUrl
    ].filter(url => typeof url === 'string' && url.length > 0);

    const unique = [];
    endpoints.forEach((url) => {
      if (!unique.includes(url)) {
        unique.push(url);
      }
    });

    return unique;
  }

  async connectWithFallback() {
    for (const transport of this.transportPriority) {
      if (transport === 'websocket' && typeof mqtt !== 'undefined') {
        const success = await this.initWebsocketTransport();
        if (success) {
          return true;
        }
      } else if (transport === 'websocket') {
        console.warn('⚠️ [MQTT-CLIENT] mqtt.js library not available, skipping WebSocket transport');
      } else if (transport === 'rest') {
        const success = await this.initRestTransport();
        if (success) {
          return true;
        }
      }
    }

    return false;
  }

  async initWebsocketTransport() {
    if (!this.websocketHosts.length) {
      console.warn('⚠️ [MQTT-CLIENT] No WebSocket hosts configured');
      return false;
    }

    const port = this.config.wsPort || 9002;
    for (const host of this.websocketHosts) {
      const success = await this.connectWebsocketHost(host, port);
      if (success) {
        this.activeTransport = 'websocket';
        this.activeHost = host;
        window.localStorage?.setItem('sshr_mqtt_host', host);
        console.log(`✅ [MQTT-CLIENT] WebSocket MQTT connected @ ${host}:${port}`);
        return true;
      }
    }

    console.warn('⚠️ [MQTT-CLIENT] All WebSocket MQTT hosts failed');
    return false;
  }

  connectWebsocketHost(host, port) {
    return new Promise((resolve) => {
      let resolved = false;
      let timeoutId = null;
      let client = null;

      const finish = (result) => {
        if (resolved) return;
        resolved = true;
        clearTimeout(timeoutId);
        if (!result && client) {
          try {
            client.end(true);
          } catch (err) {
            console.warn('⚠️ [MQTT-CLIENT] Error closing WS client:', err);
          }
        }
        resolve(result);
      };

      try {
        client = mqtt.connect(`ws://${host}:${port}`, {
          clientId: `sshr_${Math.random().toString(16).substr(2, 8)}`,
          username: this.config.username,
          password: this.config.password,
          reconnectPeriod: 0,
          keepalive: 60
        });

        const onConnect = () => {
          this.client = client;
          this.isConnected = true;
          this.activeHost = host;
          this.activeTransport = 'websocket';
          finish(true);

          client.on('offline', () => {
            console.warn('⚠️ [MQTT-CLIENT] WebSocket MQTT offline');
            this.isConnected = false;
          });

          client.on('close', () => {
            console.log('ℹ️ [MQTT-CLIENT] WebSocket MQTT connection closed');
            this.isConnected = false;
          });

          client.on('error', (runtimeError) => {
            console.error('❌ [MQTT-CLIENT] WebSocket MQTT runtime error:', runtimeError);
          });
        };

        const onError = (error) => {
          console.error(`❌ [MQTT-CLIENT] WebSocket MQTT error @ ${host}:`, error);
          finish(false);
        };

        client.once('connect', onConnect);
        client.once('error', onError);

        timeoutId = setTimeout(() => {
          console.warn(`⚠️ [MQTT-CLIENT] WebSocket MQTT connection timeout @ ${host}`);
          client.removeListener('connect', onConnect);
          client.removeListener('error', onError);
          finish(false);
        }, this.connectionTimeoutMs);
      } catch (error) {
        console.error(`❌ [MQTT-CLIENT] Unable to start WebSocket MQTT @ ${host}:`, error);
        finish(false);
      }
    });
  }

  async initRestTransport() {
    const endpoints = this.restEndpoints.length ? [...this.restEndpoints] : (this.config.baseUrl ? [this.config.baseUrl] : []);
    if (!endpoints.length) {
      console.warn('⚠️ [MQTT-CLIENT] No REST endpoints configured');
      return false;
    }

    this.activeRestEndpoint = endpoints[0];
    this.activeTransport = 'rest';
    this.isConnected = true;

    this.client = {
      publish: (topic, message, options = {}) => this.publishViaRest(topic, message, options),
      subscribe: () => {
        console.warn('⚠️ [MQTT-CLIENT] REST transport does not support subscriptions');
        return false;
      },
      disconnect: () => {
        this.isConnected = false;
      }
    };

    console.log(`✅ [MQTT-CLIENT] Using REST fallback endpoint ${this.activeRestEndpoint}`);
    return true;
  }

  getPreferredRestEndpoints() {
    const endpoints = this.restEndpoints.length ? [...this.restEndpoints] : (this.config.baseUrl ? [this.config.baseUrl] : []);
    if (!endpoints.length) {
      return [];
    }

    if (this.activeRestEndpoint && endpoints.includes(this.activeRestEndpoint)) {
      return [this.activeRestEndpoint, ...endpoints.filter(ep => ep !== this.activeRestEndpoint)];
    }

    return endpoints;
  }

  async publishViaRest(topic, message, options = {}) {
    const endpoints = this.getPreferredRestEndpoints();
    if (!endpoints.length) {
      console.error('❌ [MQTT-CLIENT] No REST endpoints available for publish');
      this.queueMessage(topic, message, options);
      this.isConnected = false;
      return false;
    }

    const payload = {
      topic,
      message: this.safeJsonParse(message),
      timestamp: new Date().toISOString()
    };

    for (const endpoint of endpoints) {
      try {
        const url = `${endpoint.replace(/\/$/, '')}/sshr/mqtt/publish`;
        const response = await fetch(url, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            ...(this.authToken ? { 'Authorization': `Bearer ${this.authToken}` } : {})
          },
          body: JSON.stringify(payload)
        });

        if (!response.ok) {
          throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }

        this.isConnected = true;
        this.activeRestEndpoint = endpoint;
        window.localStorage?.setItem('sshr_rest_endpoint', endpoint);
        console.log(`✅ [MQTT-CLIENT] REST publish succeeded via ${endpoint}: ${topic}`);
        return true;
      } catch (error) {
        console.error(`❌ [MQTT-CLIENT] REST publish failed via ${endpoint}:`, error);
      }
    }

    console.warn('⚠️ [MQTT-CLIENT] All REST endpoints failed, queuing message');
    this.isConnected = false;
    this.queueMessage(topic, message, options);
    return false;
  }

  initMockClient() {
    console.log('ℹ️ [MQTT-CLIENT] Using mock MQTT client');
    this.isConnected = true;
    this.activeTransport = 'mock';

    this.client = {
      publish: (topic, message, options = {}) => {
        console.log('🧪 [MQTT-MOCK] Published to topic:', topic, {
          message: this.safeJsonParse(message),
          options
        });
        return true;
      },
      subscribe: (topic) => {
        console.log('🧪 [MQTT-MOCK] Subscribed to topic:', topic);
        return true;
      },
      disconnect: () => {
        console.log('🧪 [MQTT-MOCK] Disconnected');
        this.isConnected = false;
      }
    };
  }

  queueMessage(topic, message, options = {}) {
    if (this.messageQueue.length >= this.maxQueueSize) {
      this.messageQueue.shift();
    }

    this.messageQueue.push({
      topic,
      message,
      options,
      timestamp: Date.now()
    });

    console.log(`🗂️ [MQTT-CLIENT] Message queued (${this.messageQueue.length}/${this.maxQueueSize}) -> ${topic}`);
  }

  async retryQueuedMessages() {
    if (this.messageQueue.length === 0) {
      return;
    }

    if (!this.isConnected) {
      const reconnected = await this.connectWithFallback();
      if (!reconnected) {
        console.warn('⚠️ [MQTT-CLIENT] Retry skipped - still offline');
        return;
      }
    }

    if (!this.client) {
      return;
    }

    console.log(`📤 [MQTT-CLIENT] Retrying ${this.messageQueue.length} queued messages`);

    const messages = [...this.messageQueue];
    this.messageQueue = [];

    for (const msg of messages) {
      try {
        await this.publish(msg.topic, msg.message, msg.options);
      } catch (error) {
        this.queueMessage(msg.topic, msg.message, msg.options);
        console.error('❌ [MQTT-CLIENT] Retry failed for message:', error);
      }
    }
  }

  async publishVisitLog(visitData) {
    const topic = 'sshr/visit/log';
    const payload = {
      messageType: 'VISIT_LOG',
      facility: 'SSHR_Bohuslavice',
      timestamp: new Date().toISOString(),
      data: visitData
    };

    return this.publish(topic, JSON.stringify(payload));
  }

  async publishIncidentAlert(incidentData) {
    const topic = 'sshr/incident/alert';
    const payload = {
      messageType: 'INCIDENT_ALERT',
      facility: 'SSHR_Bohuslavice',
      timestamp: new Date().toISOString(),
      data: incidentData
    };

    return this.publish(topic, JSON.stringify(payload));
  }

  async publishPersonReport(reportData) {
    const topic = 'sshr/reports/person';
    const payload = {
      messageType: 'PERSON_REPORT',
      facility: 'SSHR_Bohuslavice',
      timestamp: new Date().toISOString(),
      data: reportData
    };

    return this.publish(topic, JSON.stringify(payload));
  }

  async publishGroupInteraction(interactionData) {
    const topic = 'sshr/interactions/group';
    const payload = {
      messageType: 'GROUP_INTERACTION',
      facility: 'SSHR_Bohuslavice',
      timestamp: new Date().toISOString(),
      data: interactionData
    };

    return this.publish(topic, JSON.stringify(payload));
  }

  async publish(topic, message, options = {}) {
    if (!this.client) {
      console.warn('⚠️ [MQTT-CLIENT] Client not initialized');
      return false;
    }

    return this.client.publish(topic, message, options);
  }

  subscribe(topic, callback) {
    if (!this.client) {
      console.warn('⚠️ [MQTT-CLIENT] Client not initialized');
      return false;
    }

    return this.client.subscribe(topic, callback);
  }

  disconnect() {
    if (!this.client) {
      return;
    }

    if (typeof this.client.end === 'function') {
      this.client.end(true);
    } else if (typeof this.client.disconnect === 'function') {
      this.client.disconnect();
    }

    this.isConnected = false;
  }

  getStatus() {
    return {
      isConnected: this.isConnected,
      queuedMessages: this.messageQueue.length,
      transport: this.activeTransport,
      activeHost: this.activeHost,
      activeRestEndpoint: this.activeRestEndpoint
    };
  }

  safeJsonParse(message) {
    if (typeof message !== 'string') {
      return message;
    }

    try {
      return JSON.parse(message);
    } catch (error) {
      return message;
    }
  }
}

window.SSHR = window.SSHR || {};

document.addEventListener('DOMContentLoaded', async () => {
  window.SSHR.mqttClient = new SSHRMqttClient();
  await window.SSHR.mqttClient.init();

  setInterval(() => {
    if (window.SSHR.mqttClient) {
      window.SSHR.mqttClient.retryQueuedMessages();
    }
  }, 30000);
});

console.log('📡 [MQTT-CLIENT] Module loaded');
