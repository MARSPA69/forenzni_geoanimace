/**
 * Parallel Engine for SSHR Bohuslavice
 * ====================================
 *
 * Lightweight orchestration layer that reuses the existing PersonTracker and
 * IncidentManager modules to play back multiple datasets in parallel (similar
 * to the CEPRO implementation).
 *
 * Responsibilities:
 *  - Registry of available mock datasets (SSHR_DATA1, SSHR_DATA2, …)
 *  - Spawning/removing persons in PersonTracker when a parallel session starts/stops
 *  - Stepping datasets at a fixed tick interval and updating PersonTracker positions
 *  - Forwarding position samples to the IncidentEngine so incidents stay in sync
 *  - Emitting high-level events that the UI layer (panels/widgets) can subscribe to
 */

(function registerParallelEngine(global) {
  const DEFAULT_TICK_MS = 1000;

  /**
   * Utility – normalise dataset sample into a uniform structure.
   * The SSHR datasets currently expose `{ timestamp, lat, lng, ... }`.
   */
  function normaliseSample(sample) {
    if (!sample) {
      return null;
    }

    const lat = Number(sample.lat ?? sample.latitude);
    const lng = Number(sample.lng ?? sample.lon ?? sample.longitude);
    if (!Number.isFinite(lat) || !Number.isFinite(lng)) {
      return null;
    }

    let timestamp = null;
    if (sample.timestamp) {
      const parsed = new Date(sample.timestamp);
      if (!Number.isNaN(parsed.getTime())) {
        timestamp = parsed;
      }
    }

    return {
      raw: sample,
      lat,
      lng,
      timestamp: timestamp || new Date()
    };
  }

  class ParallelEngine {
    constructor() {
      this.datasets = new Map();      // name -> samples[]
      this.tracks = new Map();        // trackName -> trackState
      this.tickHandle = null;
      this.tickInterval = DEFAULT_TICK_MS;
      this.eventTarget = document.createElement('div');
      this.currentMode = 'parallel';

      // Dependencies set via initialise()
      this.map = null;
      this.personTracker = null;
      this.incidentEngine = null;
      this.uiAdapter = null;
    }

    /**
     * Provide runtime dependencies once the renderer finishes bootstrapping.
     */
    initialise(options = {}) {
      this.map = options.map ?? this.map;
      this.personTracker = options.personTracker ?? this.personTracker;
      this.incidentEngine = options.incidentEngine ?? this.incidentEngine;
      this.uiAdapter = options.uiAdapter ?? this.uiAdapter;

      if (Number.isFinite(options.tickInterval) && options.tickInterval > 0) {
        this.tickInterval = options.tickInterval;
      }

      console.log('🧭 [PARALLEL] Engine initialised', {
        hasMap: Boolean(this.map),
        hasPersonTracker: Boolean(this.personTracker),
        hasIncidentEngine: Boolean(this.incidentEngine),
        tickInterval: this.tickInterval
      });
    }

    /**
     * Allow UI code to listen on engine events without leaking implementation.
     */
    on(eventName, listener) {
      this.eventTarget.addEventListener(eventName, listener);
    }

    off(eventName, listener) {
      this.eventTarget.removeEventListener(eventName, listener);
    }

    emit(eventName, detail = {}) {
      const event = new CustomEvent(eventName, { detail });
      this.eventTarget.dispatchEvent(event);
      if (typeof window !== 'undefined' && window.dispatchEvent) {
        window.dispatchEvent(new CustomEvent(`sshr-${eventName}`, { detail }));
      }
    }

    /**
     * Register a dataset that can later be used in a session.
     */
    registerDataset(name, samples) {
      if (!name || !Array.isArray(samples)) {
        console.warn('⚠️ [PARALLEL] Cannot register dataset – invalid input', { name, samples });
        return false;
      }

      const normalised = samples
        .map(normaliseSample)
        .filter(Boolean);

      if (!normalised.length) {
        console.warn('⚠️ [PARALLEL] Dataset has no valid samples', name);
        return false;
      }

      this.datasets.set(name, normalised);
      console.log(`📦 [PARALLEL] Dataset "${name}" registered (${normalised.length} samples)`);
      this.emit('dataset-registered', { name, length: normalised.length });
      return true;
    }

    /**
     * Start a parallel session for the provided dataset names.
     */
    startSession(datasetNames = [], options = {}) {
      if (!this.personTracker) {
        console.error('❌ [PARALLEL] Cannot start – PersonTracker not initialised');
        return false;
      }

      if (!Array.isArray(datasetNames) || datasetNames.length === 0) {
        console.warn('⚠️ [PARALLEL] No datasets selected for session');
        return false;
      }

      // Prevent double starts.
      if (this.tickHandle) {
        this.stopSession({ reason: 'restart' });
      }

      const createdTracks = [];
      this.currentMode = options?.mode || 'parallel';

      datasetNames.forEach((datasetName, idx) => {
        const samples = this.datasets.get(datasetName);
        if (!samples) {
          console.warn('⚠️ [PARALLEL] Dataset not found', datasetName);
          return;
        }

        const firstSample = samples[0];
        const personId = (idx + 1).toString();
        const person = this.personTracker.addPerson(personId, [firstSample.lat, firstSample.lng], {
          name: `Osoba ${idx + 1}`,
          cardId: datasetName,
          dataset: datasetName,
          parallel: true,
          entryTime: firstSample.timestamp,
          lastUpdate: firstSample.timestamp
        });

        if (!person) {
          console.error('❌ [PARALLEL] Failed to spawn person for dataset', datasetName);
          return;
        }

        const track = {
          name: datasetName,
          samples,
          index: 0,
          personId: person.id,
          startedAt: new Date(),
          finished: false,
          mode: options?.mode || 'parallel',
          metadata: options ? { ...options } : {}
        };

        this.tracks.set(datasetName, track);
        createdTracks.push(track);

        // BLOKOVÁNO: nepoužíváme pravý info panel, máme vlastní levý
        window.sshrDebugLog(`🚫 [PARALLEL-ENGINE] Blocked uiAdapter.addPanel - using left-side info panel instead`);
      });

      if (!createdTracks.length) {
        console.warn('⚠️ [PARALLEL] Session start aborted – no valid tracks');
        return false;
      }

      this.tickHandle = window.setInterval(() => this.step(), this.tickInterval);
      this.emit('session-start', {
        datasets: createdTracks.map(track => track.name),
        tickInterval: this.tickInterval,
        mode: options?.mode || 'parallel'
      });

      console.log(`🚀 [PARALLEL] Session started with ${createdTracks.length} track(s)`);
      return true;
    }

    /**
     * Pause current session (stop ticking but keep tracks and persons)
     */
    pauseSession() {
      if (this.tickHandle) {
        window.clearInterval(this.tickHandle);
        this.tickHandle = null;
        this.emit('session-pause', { datasets: Array.from(this.tracks.keys()) });
        console.log('⏸️ [PARALLEL] Session paused');
        return true;
      }
      return false;
    }

    /**
     * Resume paused session
     */
    resumeSession() {
      if (!this.tickHandle && this.tracks.size > 0) {
        this.tickHandle = window.setInterval(() => this.step(), this.tickInterval);
        this.emit('session-resume', { datasets: Array.from(this.tracks.keys()) });
        console.log('▶️ [PARALLEL] Session resumed');
        return true;
      }
      return false;
    }

    /**
     * Set playback speed (affects tick interval)
     */
    setSpeed(speedMultiplier) {
      const baseInterval = 1000; // 1 second base
      const newInterval = Math.max(50, Math.round(baseInterval / speedMultiplier)); // Min 50ms

      if (newInterval !== this.tickInterval) {
        this.tickInterval = newInterval;

        // Restart timer with new interval if running
        if (this.tickHandle) {
          window.clearInterval(this.tickHandle);
          this.tickHandle = window.setInterval(() => this.step(), this.tickInterval);
        }

        this.emit('speed-change', { speed: speedMultiplier, interval: this.tickInterval });
        console.log(`🏃 [PARALLEL] Speed set to ${speedMultiplier}x (${this.tickInterval}ms interval)`);
        return true;
      }
      return false;
    }

    /**
     * Stop current session and clean up everything (persons, timers, UI).
     */
    stopSession(meta = {}) {
      if (this.tickHandle) {
        window.clearInterval(this.tickHandle);
        this.tickHandle = null;
      }

      // Remove persons from tracker and inform UI.
      const reason = meta?.reason || 'stop';
      const statusText =
        reason === 'completed' ? 'DONE' :
        reason === 'restart' ? 'RESTART' :
        reason === 'manual' ? 'STOP' :
        reason === 'empty' ? 'NO DATA' :
        'STOP';
      const statusTone = reason === 'completed' ? 'success' : (reason === 'restart' ? 'warning' : 'neutral');

      this.tracks.forEach(track => {
        if (this.personTracker && track.personId) {
          this.personTracker.removePerson(track.personId);
        }

        if (this.uiAdapter?.removePanel) {
          try {
            this.uiAdapter.setStatus?.(track.name, statusText, statusTone);
            this.uiAdapter.removePanel(track);
          } catch (err) {
            console.error('❌ [PARALLEL] UI adapter removePanel failed', err);
          }
        }
      });

      const stoppedDatasets = Array.from(this.tracks.keys());
      this.tracks.clear();
      this.emit('session-stop', { datasets: stoppedDatasets, mode: this.currentMode, ...meta });

      this.currentMode = 'parallel';

      console.log('🛑 [PARALLEL] Session stopped', { datasets: stoppedDatasets, meta });
    }

    /**
     * Step through datasets and push updates to PersonTracker & IncidentEngine.
     */
    step() {
      if (!this.tracks.size) {
        this.stopSession({ reason: 'empty' });
        return;
      }

      const finishedTracks = [];

      this.tracks.forEach((track, datasetName) => {
        if (track.finished) {
          this.uiAdapter?.setStatus?.(datasetName, 'DONE', 'success');
          finishedTracks.push(datasetName);
          return;
        }

        const sample = track.samples[track.index];
        if (!sample) {
          track.finished = true;
          finishedTracks.push(datasetName);
          return;
        }

        // Update position in PersonTracker.
        window.sshrDebugLog(`🎯 [PARALLEL-ENGINE] Calling PersonTracker.updatePersonPosition for ${track.personId}`);
        const updated = this.personTracker.updatePersonPosition(
          track.personId,
          [sample.lat, sample.lng],
          sample.timestamp
        );

        if (!updated) {
          console.warn('⚠️ [PARALLEL] PersonTracker update failed', track.personId, sample);
        }

        if (this.incidentEngine) {
          const trackedPerson = this.personTracker?.getPerson
            ? this.personTracker.getPerson(track.personId)
            : null;
          const zoneStatus = trackedPerson?.currentZoneStatus || null;

          this.incidentEngine.evaluatePosition({
            personId: track.personId,
            lat: sample.lat,
            lng: sample.lng,
            timestamp: sample.timestamp,
            dataset: track.name,
            sample: sample.raw,
            zoneStatus
          });
        }

        if (this.uiAdapter?.updatePanel) {
          try {
            this.uiAdapter.updatePanel(track, sample);
          } catch (err) {
            console.error('❌ [PARALLEL] UI adapter updatePanel failed', err);
          }
        }

        track.index += 1;
        if (track.index >= track.samples.length) {
          track.finished = true;
          this.uiAdapter?.setStatus?.(datasetName, 'DONE', 'success');
          finishedTracks.push(datasetName);
        }
      });

      if (finishedTracks.length) {
        this.emit('tracks-finished', { datasets: finishedTracks.slice() });
      }

      if (finishedTracks.length === this.tracks.size) {
        this.stopSession({ reason: 'completed' });
      }
    }

    /**
     * Utility helpers for UI/testing.
     */
    isActive() {
      return Boolean(this.tickHandle);
    }

    getActiveTracks() {
      return Array.from(this.tracks.values());
    }
  }

  // Singleton export for easy access (`window.SSHRParallel`).
  global.SSHRParallel = new ParallelEngine();
})(window);

console.log('✅ [PARALLEL] SSHR Parallel Engine loaded');
