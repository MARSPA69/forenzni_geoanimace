/**
 * Parallel Tracking Module for SSHR Bohuslavice
 * ============================================
 *
 * PersonTracker Class - Advanced person tracking with real-time updates
 * Focus: Smooth animations, zone detection, incident reporting
 *
 * Dependencies: Leaflet, Turf.js, Anime.js
 */

// Debug logging s časovým omezením - resetovat timer
window.SSHR_DEBUG_START_TIME = Date.now();
window.SSHR_DEBUG_DURATION = 10000; // 10 sekund logování
window.sshrDebugLog = window.sshrDebugLog || function(message, ...args) {
    if (Date.now() - window.SSHR_DEBUG_START_TIME < window.SSHR_DEBUG_DURATION) {
        console.log(message, ...args);
    }
};

const debugLog = (...args) => {
    if (typeof window.sshrDebugLog === 'function') {
        window.sshrDebugLog(...args);
    }
};

debugLog("📍 [PARALLEL-TRACKING] Loading PersonTracker module...");

// Globální funkce pro reset debug času
window.resetSSHRDebugTimer = function() {
    window.SSHR_DEBUG_START_TIME = Date.now();
    console.log("🔄 Debug timer reset - další 15s logování");
};

function sshrGetIconFactory() {
    if (typeof window !== 'undefined') {
        if (typeof window.sshrGetPersonMarkerIcon === 'function') {
            return window.sshrGetPersonMarkerIcon;
        }
        if (typeof window.getPersonMarkerIcon === 'function') {
            return window.getPersonMarkerIcon;
        }
    }
    return sshrFallbackIcon;
}

function sshrFallbackIcon(color, rotation = 0) {
    return L.divIcon({
        html: `<div class="sshr-person-icon" style="transform: rotate(${rotation}deg); transition: transform 0.3s ease;">
                 <i class="bi bi-person-walking sshr-person-glyph" style="font-size:24px; color:${color}; filter: drop-shadow(0 2px 4px rgba(0,0,0,0.4));"></i>
               </div>`,
        className: 'custom-marker-icon',
        iconSize: [28, 28],
        iconAnchor: [14, 14]
    });
}

function sshrApplyIcon(marker, color, rotation, forceReplace = false) {
    if (!marker) return;

    const iconFactory = sshrGetIconFactory();
    const element = marker.getElement();

    if (forceReplace || !element) {
        marker.setIcon(iconFactory(color, rotation));
        return;
    }

    const wrapper = element.querySelector('.sshr-person-icon');
    if (wrapper) {
        wrapper.style.transform = `rotate(${rotation}deg)`;
    }

    const glyph = element.querySelector('.sshr-person-glyph');
    if (glyph) {
        if (glyph.tagName === 'I') {
            glyph.style.color = color;
        } else {
            glyph.style.backgroundColor = color;
        }
    } else {
        marker.setIcon(iconFactory(color, rotation));
    }
}

function sshrComputeAngle(fromPosition, toPosition) {
    const [oldLat, oldLng] = fromPosition || [];
    const [newLat, newLng] = toPosition || [];

    if (typeof window !== 'undefined') {
        const calc = window.sshrCalculateParallelMarkerAngle || window.calculateParallelMarkerAngle;
        if (typeof calc === 'function') {
            return calc(oldLat, oldLng, newLat, newLng);
        }
    }

    // Fallback k CEPRO-style kolmému směru
    const dLat = newLat - oldLat;
    const dLng = newLng - oldLng;

    if (Math.abs(dLat) < 0.0000001 && Math.abs(dLng) < 0.0000001) {
        return 0;
    }

    const avgLat = ((oldLat ?? 0) + (newLat ?? 0)) / 2;
    const latMeters = dLat * 111320;
    const lngMeters = dLng * (111320 * Math.cos(avgLat * Math.PI / 180));
    const distance = Math.sqrt(latMeters * latMeters + lngMeters * lngMeters);

    if (distance < 0.5) {
        return 0;
    }

    // CEPRO-style kolmý směr k pohybu
    const absLat = Math.abs(latMeters);
    const absLng = Math.abs(lngMeters);

    if (absLng > absLat * 1.2) {
        // Dominantní pohyb East-West → hlava vždy na sever (0°)
        return 0;
    }

    if (absLat > absLng * 1.2) {
        // Dominantní pohyb North-South → hlava nakloněna o 15° směrem na východ
        return 15;
    }

    // Diagonální / nejasný pohyb → použij standardní směr
    return 0;
}

class PersonTracker {
    constructor(map, zones = []) {
        this.map = map;
        this.zones = zones;
        this.persons = new Map();
        this.activeAnimations = new Map();
        this.lastPositions = new Map();
        this.movementHistory = new Map();
        this.fullTrajectories = new Map();
        this.speedCalculations = new Map();

        // Incident details storage for rich info panel display
        this.incidentDetails = new Map(); // personId -> Array of detailed incident objects

        // Sticky anchor tracking for persistent display
        this.lastActivatedAnchors = new Map(); // personId -> { anchorId, activationTime, distance }

        // Setup incident event listeners
        this.setupIncidentListeners();

        // Configuration
        this.config = {
            maxHistoryPoints: 50,
            speedSampleSize: 5,
            personSpeedCap: 11,  // km/h limit for personnel datasets
            alertThresholds: {
                speed: 20, // km/h
                stationaryTime: 300, // seconds
                zoneViolation: true
            },
            // Smooth speed configuration
            speedSmoothing: {
                alpha: 0.15, // exponential moving average factor
                hysteresis: {
                    movingEnter: 5.5,    // >5.5 km/h to enter "moving"
                    movingExit: 4.5,     // <=4.5 km/h to exit "moving"
                    stationaryEnter: 0.8, // <=0.8 km/h to enter "stationary"
                    stationaryExit: 1.2   // >1.2 km/h to exit "stationary"
                }
            },
            // Animation configuration
            animation: {
                baseSpeed: 800,        // base duration in ms
                minDuration: 200,      // minimum duration
                maxDuration: 2000,     // maximum duration
                easing: 'linear',      // linear for position
                rotationEasing: 'easeOutQuad', // smooth rotation
                rotationDuration: 300  // rotation animation duration
            },
            markerStyles: {
                default: { color: '#0d47a1' },
                moving: { color: '#28a745' },
                stationary: { color: '#f59e0b' },
                violation: { color: '#b71c1c' }
            },
            trajectoryHistoryLimit: 2000
        };

        console.log("✅ [PERSON-TRACKER] Initialized with", zones.length, "zones");
    }

    /**
     * Update smooth speed with exponential moving average and classify movement
     */
    updateSmoothSpeed(person, instantSpeed) {
        const alpha = this.config.speedSmoothing.alpha;
        const hysteresis = this.config.speedSmoothing.hysteresis;

        person.instantSpeed = instantSpeed;

        // Exponential moving average: smoothSpeed = alpha * newSpeed + (1-alpha) * oldSpeed
        person.smoothSpeed = alpha * instantSpeed + (1 - alpha) * person.smoothSpeed;

        // Classify movement type based on smooth speed
        person.movementType = this.classifyMovementType(person.smoothSpeed);

        // Update movement status with hysteresis
        const currentStatus = person.movementStatus;
        const smoothSpeedKmh = person.smoothSpeed;

        if (currentStatus === 'stationary') {
            if (smoothSpeedKmh > hysteresis.stationaryExit) {
                if (smoothSpeedKmh > hysteresis.movingEnter) {
                    person.movementStatus = 'moving';
                } else {
                    person.movementStatus = 'active';
                }
            }
        } else if (currentStatus === 'active') {
            if (smoothSpeedKmh <= hysteresis.stationaryEnter) {
                person.movementStatus = 'stationary';
            } else if (smoothSpeedKmh > hysteresis.movingEnter) {
                person.movementStatus = 'moving';
            }
        } else if (currentStatus === 'moving') {
            if (smoothSpeedKmh <= hysteresis.movingExit) {
                if (smoothSpeedKmh <= hysteresis.stationaryEnter) {
                    person.movementStatus = 'stationary';
                } else {
                    person.movementStatus = 'active';
                }
            }
        }

        window.sshrDebugLog(`🏃 [PARALLEL-TRACKING] Speed: instant=${instantSpeed.toFixed(1)}, smooth=${person.smoothSpeed.toFixed(1)}, type=${person.movementType}, status=${person.movementStatus}`);
    }

    /**
     * Classify movement type based on speed (similar to CEPRO)
     */
    classifyMovementType(speedKmh) {
        // Sanitize input - ensure it's a valid number
        const cap = this.config?.personSpeedCap ?? 11;
        const speed = isNaN(speedKmh) || !isFinite(speedKmh) || speedKmh < 0
            ? 0
            : Math.min(speedKmh, cap);

        if (speed <= 0.5) return "Stání";
        if (speed < 3) return "Pomalá chůze";
        if (speed < 5.5) return "Standardní chůze";
        if (speed < 7.5) return "Rychlá chůze";
        if (speed < 9) return "Běh";
        return "Sprint";
    }

    /**
     * Get color for movement type
     */
    getMovementTypeColor(movementType) {
        const colorByType = {
            "Stání": "#6c757d",
            "Pomalá chůze": "#28a745",
            "Standardní chůze": "#17a2b8",
            "Rychlá chůze": "#ffc107",
            "Běh": "#fd7e14",
            "Rychlý běh": "#ff5722",
            "Sprint": "#dc3545"
        };
        return colorByType[movementType] || "#6c757d";
    }

    /**
     * Add a new person to tracking
     */
    addPerson(personId, initialPosition, metadata = {}) {
        try {
            window.sshrDebugLog(`👤 [PARALLEL-TRACKING] Adding person ${personId} at position [${initialPosition}]`);

            const basePosition = Array.isArray(initialPosition)
                ? [Number(initialPosition[0]), Number(initialPosition[1])]
                : [0, 0];

            const person = {
                id: personId,
                position: basePosition,
                prevPosition: [...basePosition],
                rotation: 0,
                color: this.getFixedPersonColor(personId),
                marker: null,
                trail: [],
                metadata: {
                    name: metadata.name || `Person ${personId}`,
                    cardId: metadata.cardId || null,
                    entryTime: metadata.entryTime || new Date(),
                    lastUpdate: new Date(),
                    status: 'active',
                    ...metadata
                },
                stats: {
                    totalDistance: 0,
                    averageSpeed: 0,
                    maxSpeed: 0,
                    stationaryTime: 0,
                    zoneViolations: 0
                },
                // Smooth movement tracking
                smoothSpeed: 0,           // exponential moving average speed
                instantSpeed: 0,          // current sample speed
                movementType: 'Stání',    // movement classification
                movementStatus: 'stationary', // for hysteresis tracking
                lastInfraElement: null,
                lastInfraDistance: null
            };

            person.datasetName = metadata.dataset || metadata.datasetName || metadata.cardId || null;
            person.lastActiveAnchor = metadata.anchorId || null;
            person.lastAnchorDistance = null;

            person.metadata.lastUpdate = this.normaliseTimestamp(person.metadata.lastUpdate);
            person.metadata.previousTimestamp = person.metadata.previousTimestamp
                ? this.normaliseTimestamp(person.metadata.previousTimestamp)
                : person.metadata.lastUpdate;

            // Create marker
            person.marker = this.createPersonMarker(person);

            // Add to tracking
            this.persons.set(personId, person);
            this.lastPositions.set(personId, [...basePosition]);
            this.movementHistory.set(personId, []);
            this.fullTrajectories.set(personId, [{
                lat: basePosition[0],
                lng: basePosition[1],
                timestamp: person.metadata.lastUpdate
            }]);
            this.speedCalculations.set(personId, []);

            if (window.sshrPersons && typeof window.sshrPersons.set === 'function') {
                window.sshrPersons.set(personId, person);
            }

            console.log(`👤 [PERSON-TRACKER] Added person ${personId}:`, person.metadata.name);

            if (typeof window.getZoneStatus === 'function') {
                const zoneStatus = window.getZoneStatus(initialPosition[0], initialPosition[1]);
                if (zoneStatus) {
                    person.metadata.currentZone = zoneStatus.zoneName;
                    person.metadata.zoneDetails = zoneStatus;
                }
            }

            // Trigger event
            this.triggerEvent('person-added', { person });

            return person;
        } catch (error) {
            console.error(`❌ [PERSON-TRACKER] Error adding person ${personId}:`, error);
            return null;
        }
    }

    /**
     * Update person position with smooth animation
     */
    updatePersonPosition(personId, newPosition, timestamp = new Date()) {
        window.sshrDebugLog(`📍 [PARALLEL-TRACKING] updatePersonPosition called for ${personId}, position: [${newPosition[0]}, ${newPosition[1]}]`);
        const person = this.persons.get(personId);
        if (!person) {
            console.warn(`⚠️ [PERSON-TRACKER] Person ${personId} not found for update`);
            return false;
        }

        try {
            const oldPosition = Array.isArray(person.position)
                ? [...person.position]
                : [newPosition[0], newPosition[1]];
            const distance = this.calculateDistance(oldPosition, newPosition);
            const previousTimestamp = this.normaliseTimestamp(person.metadata.lastUpdate);
            const nextTimestamp = this.normaliseTimestamp(timestamp);
            const timeDiff = (nextTimestamp - previousTimestamp) / 1000; // seconds
            let speed = distance > 0 && timeDiff > 0 ? (distance / timeDiff) * 3.6 : 0; // km/h

            // Sanitize speed calculation - prevent invalid values
            if (isNaN(speed) || !isFinite(speed) || speed < 0) {
                speed = 0;
            }

            // Cap speeds to personnel limit (expectation: <= 11 km/h)
            const personSpeedCap = this.config.personSpeedCap ?? 11;
            if (speed > personSpeedCap) {
                console.warn(`🚨 [PERSON-TRACKER] Personnel speed cap exceeded for ${personId}: ${speed.toFixed(1)} km/h, clamping to ${personSpeedCap} km/h`);
                speed = personSpeedCap;
            }

            // Update person data
            person.prevPosition = oldPosition;
            person.position = Array.isArray(newPosition) ? [...newPosition] : [...oldPosition];
            person.metadata.previousTimestamp = previousTimestamp;
            person.metadata.lastUpdate = nextTimestamp;
            person.stats.totalDistance += distance;

            // Update speed calculations
            this.updateSpeedCalculations(personId, speed);

            // Update smooth speed and movement classification
            this.updateSmoothSpeed(person, speed);

            // Update movement history
            this.updateMovementHistory(personId, newPosition, timestamp);

            // Update marker style BEFORE animation (determines color for animation)
            this.updateMarkerStyle(person, person.smoothSpeed);

            // Animate marker to new position
            window.sshrDebugLog(`🎯 [PARALLEL-TRACKING] About to call animateMarkerToPosition for ${personId}`);
            this.animateMarkerToPosition(person, newPosition, nextTimestamp, previousTimestamp);
            this.lastPositions.set(personId, [...newPosition]);

            // Check anchor proximity for glow effects
            if (typeof window.checkSSHRAnchorProximity === 'function') {
                window.checkSSHRAnchorProximity({
                    lat: newPosition[0],
                    lng: newPosition[1],
                    personId: personId
                });
            }

            // Check INFRA elements proximity (2m radius)
            if (typeof window.checkSSHRInfraProximity === 'function') {
                window.checkSSHRInfraProximity(personId, newPosition[0], newPosition[1]);
            }

            // Update trail
            this.updatePersonTrail(person, newPosition);

            // Synchronise with central incident engine (if available)
            if (window.SSHRIncidentEngine && typeof window.SSHRIncidentEngine.evaluatePosition === 'function') {
                try {
                    // Position evaluation - debug log removed for performance

                    const beforeActiveIncidents = window.SSHRIncidentEngine.activeIncidents ?
                        new Map(window.SSHRIncidentEngine.activeIncidents) : null;
                    // Active incidents before - debug log removed for performance

                    window.SSHRIncidentEngine.evaluatePosition({
                        personId,
                        lat: newPosition[0],
                        lng: newPosition[1],
                        timestamp,
                        dataset: person.metadata.dataset || null,
                        sample: null,
                        zoneStatus: person.currentZoneStatus || null
                    });

                    const afterActiveIncidents = window.SSHRIncidentEngine.activeIncidents ?
                        new Map(window.SSHRIncidentEngine.activeIncidents) : null;
                    // Active incidents after - debug log removed for performance

                    if (window.SSHRIncidentEngine.getIncidentCount) {
                        const incidentCount = window.SSHRIncidentEngine.getIncidentCount(personId);
                        // Total incident count - debug log removed for performance
                    }
                } catch (engineError) {
                    console.error(`❌ [PERSON-TRACKER] IncidentEngine evaluate failed for ${personId}:`, engineError);
                }
            }

            if (typeof window.getZoneStatus === 'function') {
                const liveZoneStatus = window.getZoneStatus(newPosition[0], newPosition[1]);
                if (liveZoneStatus) {
                    person.metadata.currentZone = liveZoneStatus.zoneName;
                    person.metadata.zoneDetails = liveZoneStatus;
                }
            }

            // Check for incidents
            this.checkForIncidents(person, speed);

            // Position updated - debug log removed for performance

            // Update info panel with current data
            this.updatePersonInfoPanel(person, timestamp);

            // === NOVÁ INTEGRACE S REPORTOVACÍMI SYSTÉMY ===

            // 1. Zaznamenat pohyb do SSHRVisitService pro reporty
            const datasetKey = person.datasetName || person.metadata.dataset || null;
            if (datasetKey && window.SSHRVisitService && typeof window.SSHRVisitService.recordMovement === 'function') {
                try {
                    const movementData = {
                        gps: { lat: newPosition[0], lng: newPosition[1] },
                        zone: person.metadata.zoneDetails?.zoneName || person.metadata.currentZone || null,
                        anchor: person.lastActiveAnchor || null,
                        anchorDistance: person.lastAnchorDistance || null,
                        speed,
                        distance,
                        movementType: person.movementType || 'unknown',
                        movementStatus: person.movementStatus || 'stationary',
                        infraElement: person.lastInfraElement || null,
                        infraDistance: person.lastInfraDistance || null,
                        timestamp: nextTimestamp instanceof Date
                            ? nextTimestamp.toISOString()
                            : new Date(nextTimestamp).toISOString(),
                        groupContext: window.SSHR?.groupInteractionTracker?.getPersonGroupContext
                            ? window.SSHR.groupInteractionTracker.getPersonGroupContext(personId)
                            : null
                    };

                    window.SSHRVisitService.recordMovement(datasetKey, movementData);
                } catch (visitError) {
                    console.error(`❌ [PERSON-TRACKER] SSHRVisitService.recordMovement failed for ${personId}:`, visitError);
                }
            }

            // 2. Aktualizovat GroupInteractionTracker s aktuálními pozicemi všech osob
            if (window.SSHR?.groupInteractionTracker && this.persons.size > 1) {
                try {
                    // Připravit data pro GroupInteractionTracker - pouze osoby s platnou pozicí
                    const personsForTracking = [];
                    this.persons.forEach((p, pid) => {
                        if (p.position && p.position.length >= 2) {
                            personsForTracking.push({
                                id: pid,
                                datasetName: p.datasetName || p.metadata?.dataset,
                                position: {
                                    lat: p.position[0],
                                    lng: p.position[1]
                                },
                                movementType: p.movementType || 'unknown',
                                lastActiveAnchor: p.lastActiveAnchor || null
                            });
                        }
                    });

                    // Spustit sledování interakcí pouze pokud máme alespoň 2 osoby
                    if (personsForTracking.length >= 2) {
                        const trackingResult = window.SSHR.groupInteractionTracker.processTick(personsForTracking, nextTimestamp);

                        window.sshrDebugLog(`👥 [PERSON-TRACKER] Group tracking update:`, {
                            activeGroups: trackingResult.activeGroupsCount,
                            proximities: trackingResult.currentProximities,
                            totalPersons: personsForTracking.length
                        });
                    }
                } catch (groupError) {
                    console.error(`❌ [PERSON-TRACKER] GroupInteractionTracker failed:`, groupError);
                }
            }

            // Trigger event
            this.triggerEvent('person-updated', { person, speed, distance });

            return true;
        } catch (error) {
            console.error(`❌ [PERSON-TRACKER] Error updating person ${personId}:`, error);
            return false;
        }
    }

    /**
     * Create person marker with custom styling
     */
    createPersonMarker(person) {
        window.sshrDebugLog(`🗺️ [PARALLEL-TRACKING] Creating marker for person ${person.id} with color ${person.color}`);

        const color = person.color || this.config.markerStyles.default.color;
        const rotation = person.rotation || 0;
        const iconFactory = sshrGetIconFactory();

        const marker = L.marker(person.position, {
            icon: iconFactory(color, rotation),
            keyboard: false,
            riseOnHover: true
        });

        // ODSTRANĚN popup - místo toho používáme info panel na levé straně

        marker.addTo(this.map);
        sshrApplyIcon(marker, color, rotation);

        // Vytvořit info panel podle SSHR specifikace
        window.sshrDebugLog(`🗺️ [PARALLEL-TRACKING] About to create info panel for ${person.id}`);
        this.createPersonInfoPanel(person);
        window.sshrDebugLog(`🗺️ [PARALLEL-TRACKING] Marker creation completed for ${person.id}`);

        return marker;
    }

    /**
     * Create info panel on left side (SSHR specification)
     */
    createPersonInfoPanel(person) {
        window.sshrDebugLog(`📋 [PARALLEL-TRACKING] Creating info panel for person ${person.id}`);

        // Odstranit existující panel, pokud existuje
        const existingPanel = document.getElementById(`person-info-${person.id}`);
        if (existingPanel) {
            existingPanel.remove();
            window.sshrDebugLog(`📋 [PARALLEL-TRACKING] Removed existing panel for ${person.id}`);
        }

        const panel = document.createElement('div');
        panel.id = `person-info-${person.id}`;
        panel.className = 'sshr-person-info-panel';

        // CRITICAL FIX: Spočítej pozici PŘED přidáním tohoto panelu do DOM
        const existingPanels = document.querySelectorAll('.sshr-person-info-panel');
        const panelIndex = existingPanels.length; // Index pro nový panel
        const topPosition = 50 + (panelIndex * 200); // 200px mezera mezi panely (větší mezera)

        window.sshrDebugLog(`📍 [PARALLEL-TRACKING] Panel ${person.id} positioned at ${topPosition}px (index: ${panelIndex}, existing: ${existingPanels.length})`);

        // Cool compact styling
        panel.style.cssText = `
            position: absolute;
            top: ${topPosition}px;
            left: 8px;
            width: 160px;
            z-index: 1000;
            cursor: move;
            user-select: none;
        `;

        // Modern glass-morphism design
        panel.className = 'sshr-person-info-panel bg-white/90 backdrop-blur-md rounded-xl shadow-2xl border border-white/20 overflow-hidden transition-all duration-300 hover:shadow-3xl hover:scale-105';

        // Simple person numbering based on dataset order (1, 2, 3...)
        const personNumber = panelIndex + 1; // Simple: 1st panel = Osoba č.1, 2nd = Osoba č.2

        // Fixed person color
        const fixedPersonColor = person.color || this.config.markerStyles.default.color;

        panel.innerHTML = `
            <!-- Header s draggable handle a collapse toggle -->
            <div class="panel-header flex items-center justify-between p-3 border-l-4 cursor-move bg-gradient-to-r from-gray-50 to-white" style="border-left-color: ${fixedPersonColor};">
                <div class="flex items-center space-x-2">
                    <div class="w-2 h-2 rounded-full" style="background-color: ${fixedPersonColor};"></div>
                    <span class="text-xs font-semibold text-gray-800">OSOBA č.${personNumber}</span>
                </div>
                <div class="flex items-center space-x-1">
                    <button onclick="this.closest('.sshr-person-info-panel').querySelector('.panel-content').classList.toggle('hidden')"
                            class="p-1 hover:bg-gray-200 rounded transition-colors">
                        <svg class="w-3 h-3 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/>
                        </svg>
                    </button>
                    <button onclick="this.closest('.sshr-person-info-panel').remove()"
                            class="p-1 hover:bg-red-100 rounded transition-colors">
                        <svg class="w-3 h-3 text-gray-500 hover:text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
                        </svg>
                    </button>
                </div>
            </div>

            <!-- Collapsible content -->
            <div class="panel-content p-3 space-y-1 text-xs bg-white">
                <div class="flex justify-between items-center">
                    <span class="text-gray-600 font-medium">Čas:</span>
                    <span class="text-gray-900 font-mono" data-info="time">—</span>
                </div>
                <div class="flex justify-between items-center">
                    <span class="text-gray-600 font-medium">GPS:</span>
                    <span class="text-gray-900 font-mono text-xs ml-2" data-info="gps">${person.position[0].toFixed(5)}, ${person.position[1].toFixed(5)}</span>
                </div>
                <div class="flex justify-between items-center">
                    <span class="text-gray-600 font-medium">Pohyb:</span>
                    <span class="font-semibold" data-info="movement">${person.movementType}</span>
                </div>
                <div class="flex justify-between items-center">
                    <span class="text-gray-600 font-medium">Zóna:</span>
                    <span class="font-semibold" data-info="zone">—</span>
                </div>
                <div class="flex justify-between items-center">
                    <span class="text-gray-600 font-medium">Kotva:</span>
                    <span class="text-gray-900" data-info="anchor">—</span>
                </div>
                <div class="flex justify-between items-center">
                    <span class="text-gray-600 font-medium">Segment:</span>
                    <span class="text-gray-900" data-info="green-segment">—</span>
                </div>
                <div class="flex justify-between items-center">
                    <span class="text-gray-600 font-medium">Incidenty:</span>
                    <span class="text-red-600 font-semibold" data-info="incidents">0</span>
                </div>
                <div class="mt-2 p-2 border-2 border-dashed border-gray-300 rounded text-center text-gray-500 text-xs card-drop-zone"
                     data-panel-id="person-info-${person.id}"
                     data-dataset-name="${person.datasetName}">
                    💳 Návštěvnická karta
                </div>
            </div>
        `;

        // Přidat do mapy (ne do body) - relativní pozicování
        const mapContainer = document.getElementById('leafletMap');
        if (mapContainer) {
            // Ujistit se, že mapContainer má relativní pozici
            if (mapContainer.style.position !== 'relative') {
                mapContainer.style.position = 'relative';
            }
            mapContainer.appendChild(panel);
            window.sshrDebugLog(`📋 [PARALLEL-TRACKING] Panel attached to map container`);
        } else {
            // Fallback k body pokud mapa není k dispozici
            document.body.appendChild(panel);
            window.sshrDebugLog(`📋 [PARALLEL-TRACKING] Panel fallback to body (map not found)`);
        }

        // Uložit referenci na panel
        person.infoPanel = panel;

        // CRITICAL FIX: Use vanilla JS draggable instead of jQuery UI
        window.sshrDebugLog(`🖱️ [PARALLEL-TRACKING] About to make panel ${person.id} draggable, mapContainer: ${mapContainer ? 'found' : 'missing'}`);
        this.makePanelDraggable(panel, mapContainer);
        window.sshrDebugLog(`🖱️ [PARALLEL-TRACKING] Vanilla JS draggable applied to panel ${person.id}`);

        // Register drop zone with SSHR Card Manager
        if (window.SSHR?.cardManager?.registerDropZone) {
            window.SSHR.cardManager.registerDropZone(panel, {
                panelId: `person-info-${person.id}`,
                datasetName: person.datasetName,
                personId: person.id,
                personNumber: personNumber
            });
            window.sshrDebugLog(`💳 [PARALLEL-TRACKING] Drop zone registered for panel ${person.id}`);
        }

        window.sshrDebugLog(`📋 [PARALLEL-TRACKING] Modern draggable panel created for ${person.id} at position ${topPosition}px`);

        return panel;
    }

    /**
     * Update info panel with current data
     */
    updatePersonInfoPanel(person, currentTimestamp = null) {
        if (!person.infoPanel) return;

        const panel = person.infoPanel;

        // Aktualizovat barvu levého pruhu podle aktuální barvy osoby
        panel.style.borderLeftColor = person.color;

        // Aktualizovat header barvu
        const header = panel.querySelector('.panel-header');
        if (header) {
            header.style.color = person.color;
        }

        // Aktualizovat jednotlivé hodnoty
        const timeEl = panel.querySelector('[data-info="time"]');
        if (timeEl) {
            // Použít čas z datasetu místo aktuálního času
            const datasetTime = person.metadata.lastUpdate instanceof Date
                ? person.metadata.lastUpdate
                : new Date(person.metadata.lastUpdate);
            timeEl.textContent = datasetTime.toLocaleTimeString('cs-CZ');
        }

        const gpsEl = panel.querySelector('[data-info="gps"]');
        if (gpsEl) {
            gpsEl.textContent = `${person.position[0].toFixed(5)}, ${person.position[1].toFixed(5)}`;
        }

        // Aktualizovat typ pohybu s barvou podle rychlosti
        const movementEl = panel.querySelector('[data-info="movement"]');
        if (movementEl) {
            const movementColor = this.getMovementTypeColor(person.movementType);
            movementEl.innerHTML = `<span style="color: ${movementColor}; font-weight: bold;">${person.movementType}</span>`;
        }

        // CRITICAL FIX: Info panel parameters work INDEPENDENTLY of Animation Layers
        // Animation Layers are ONLY for visualization - incident system runs on background always!
        window.sshrDebugLog(`🔧 [PARALLEL-TRACKING] Updating panel parameters independently of Animation Layers`);

        // 1. ZÓNA - vždy detekuje, nezávisle na UI layers
        const zoneEl = panel.querySelector('[data-info="zone"]');
        if (zoneEl) {
            const zoneStatus = this.getPersonZoneStatus(person);
            window.sshrDebugLog(`🔍 [PARALLEL-TRACKING] Zone status for ${person.id}: inGreen=${zoneStatus.inGreen}, inRed=${zoneStatus.inRed}`);

            // Export zone status to person object for incident engine
            person.currentZoneStatus = zoneStatus;

            if (zoneStatus.inGreen) {
                zoneEl.innerHTML = `<span style="color: #65a30d; font-weight: bold;">Povolená</span>`; // lime-600
            } else if (zoneStatus.inRed) {
                zoneEl.innerHTML = `<span style="color: #dc2626; font-weight: bold;">Nepovolená</span>`; // red-600
            } else {
                zoneEl.innerHTML = `<span style="color: #6b7280;">Neutrální</span>`;
            }
        }

        // 2. KOTVA - vždy detekuje proximity, nezávisle na UI layers
        const anchorEl = panel.querySelector('[data-info="anchor"]');
        if (anchorEl) {
            const nearbyAnchor = this.getNearbyAnchor(person.position);
            window.sshrDebugLog(`⚓ [PARALLEL-TRACKING] Nearby anchor for ${person.id}: ${nearbyAnchor ? `ID ${nearbyAnchor.id} at ${nearbyAnchor.distance.toFixed(1)}m` : 'none'}`);

            if (nearbyAnchor) {
                // Active anchor - zobraz aktuální vzdálenost
                anchorEl.innerHTML = `<span style="color: #f59e0b; font-weight: bold;">ID ${nearbyAnchor.id} (${nearbyAnchor.distance.toFixed(1)}m)</span>`; // amber-500

                // Uložit jako "last activated anchor" pouze pokud se změnila kotva nebo je nová
                const lastActivated = this.lastActivatedAnchors.get(person.id);
                const isNewAnchor = !lastActivated || lastActivated.anchorId !== nearbyAnchor.id;

                if (isNewAnchor && currentTimestamp) {
                    // Nová aktivace kotvy - použít timestamp z aktuálního vzorku datasetu
                    const activationTime = currentTimestamp instanceof Date
                        ? currentTimestamp
                        : new Date(currentTimestamp);

                    this.lastActivatedAnchors.set(person.id, {
                        anchorId: nearbyAnchor.id,
                        activationTime: activationTime,
                        distance: nearbyAnchor.distance
                    });

                    console.log(`⚓ [ANCHOR-ACTIVATION] Person ${person.id} activated anchor ${nearbyAnchor.id} at ${activationTime.toLocaleTimeString('cs-CZ')}`);
                }

                person.lastActiveAnchor = nearbyAnchor.id;
                person.lastAnchorDistance = nearbyAnchor.distance;

                // Corona efekt je už aktivován globálně přes window.checkSSHRAnchorProximity() níže
                // (odstraněno duplicitní volání activateAnchorCorona pro vyřešení konfliktu velikostí)
            } else {
                // Žádná aktivní kotva - zobraz sticky "last activated" s časem
                const lastAnchor = this.lastActivatedAnchors.get(person.id);
                if (lastAnchor) {
                    const timeStr = lastAnchor.activationTime.toLocaleTimeString('cs-CZ', {
                        hour: '2-digit',
                        minute: '2-digit',
                        second: '2-digit'
                    });
                    anchorEl.innerHTML = `<span style="color: #9ca3af; font-weight: normal;">ID ${lastAnchor.anchorId} (${timeStr})</span>`; // gray-400 for sticky
                    person.lastActiveAnchor = lastAnchor.anchorId;
                    person.lastAnchorDistance = lastAnchor.distance || null;
                } else {
                    anchorEl.textContent = '—';
                    person.lastActiveAnchor = null;
                    person.lastAnchorDistance = null;
                }
                // Deaktivace je už řešena globálně přes window.checkSSHRAnchorProximity() níže
            }
        }

        // 3. SEGMENT - vždy detekuje GREEN zóny, nezávisle na UI layers
        const segmentEl = panel.querySelector('[data-info="green-segment"]');
        if (segmentEl) {
            const segment = this.getGreenZoneSegment(person.position);
            window.sshrDebugLog(`📍 [PARALLEL-TRACKING] Segment for ${person.id}: ${segment || 'none'}`);
            segmentEl.textContent = segment || '—';
        }

        // 4. INCIDENTY - zjednodušeno, čte pouze z IncidentRegistry
        const incidentsEl = panel.querySelector('[data-info="incidents"]');
        if (incidentsEl) {
            let totalCount = 0;
            let latestIncident = null;

            // Číst pouze z IncidentRegistry - jediný zdroj pravdy
            if (window.SSHR?.incidentRegistry) {
                totalCount = window.SSHR.incidentRegistry.getTotalCount(person.id);
                latestIncident = window.SSHR.incidentRegistry.getLatestIncident(person.id);

                // Enhanced debugging for incident counting
                const completedCount = window.SSHR.incidentRegistry.getCompletedCount(person.id);
                const isActive = window.SSHR.incidentRegistry.isActive(person.id);

                console.log(`📊 [PARALLEL-TRACKING] Person ${person.id} incidents: total=${totalCount}, completed=${completedCount}, active=${isActive}`);

                // Person incident debug info - log removed for performance

                // Incident count retrieved - debug log removed for performance
            } else {
                console.warn('❌ [PARALLEL-TRACKING] IncidentRegistry not available', {
                    'window.SSHR': !!window.SSHR,
                    'window.SSHR.incidentRegistry': !!window.SSHR?.incidentRegistry
                });
            }

            if (totalCount === 0) {
                incidentsEl.innerHTML = '<span style="color: #6b7280;">0</span>';
            } else {
                incidentsEl.innerHTML = `<span style="color: #dc2626; font-weight: bold;">${totalCount}</span>`;
            }

            // Incident count debug - log removed for performance
        }

        window.sshrDebugLog(`📋 [PARALLEL-TRACKING] Info panel updated independently: ${person.movementType}`);
    }

    /**
     * Create popup content for person marker
     */
    createPersonPopup(person) {
        const zoneDetails = person.metadata.zoneDetails || null;
        const zoneLabel = zoneDetails?.greenZone?.name ||
            zoneDetails?.redZone?.name ||
            zoneDetails?.zoneName ||
            person.metadata.currentZone ||
            'Unknown';

        const zoneStateBadge = zoneDetails?.violation
            ? '<span class="badge bg-danger">Violation</span>'
            : '<span class="badge bg-success">OK</span>';

        return `
            <div class="person-popup">
                <h6><i class="fas fa-user"></i> ${person.metadata.name}</h6>
                <hr style="margin: 5px 0;">
                <small>
                    <strong>ID:</strong> ${person.id}<br>
                    <strong>Card:</strong> ${person.metadata.cardId || 'N/A'}<br>
                    <strong>Dataset:</strong> ${person.metadata.dataset || 'N/A'}<br>
                    <strong>Zone:</strong> ${zoneLabel} ${zoneStateBadge}<br>
                    <strong>Entry:</strong> ${person.metadata.entryTime.toLocaleTimeString()}<br>
                    <strong>Distance:</strong> ${person.stats.totalDistance.toFixed(1)}m<br>
                    <strong>Avg Speed:</strong> ${person.stats.averageSpeed.toFixed(1)} km/h<br>
                    <strong>Status:</strong> <span class="badge badge-${this.getStatusBadgeColor(person.metadata.status)}">${person.metadata.status}</span>
                </small>
            </div>
        `;
    }

    /**
     * Animate marker to new position with temporal accuracy
     */
    animateMarkerToPosition(person, newPosition, timestamp = new Date(), previousTimestamp = null) {
        window.sshrDebugLog(`🎯 [PARALLEL-TRACKING] animateMarkerToPosition called for person ${person.id}`);
        const marker = person.marker;
        if (!marker) return;

        const currentLatLng = marker.getLatLng();
        const startLat = currentLatLng?.lat ?? person.prevPosition[0];
        const startLng = currentLatLng?.lng ?? person.prevPosition[1];

        // Stop any existing animation
        if (this.activeAnimations.has(marker)) {
            const existing = this.activeAnimations.get(marker);
            if (existing && typeof existing.pause === 'function') {
                existing.pause();
            }
        }

        // Vypočítej rotaci a barvu pouze jednou na začátku animace
        const initialRotation = sshrComputeAngle(person.prevPosition, newPosition);
        const finalColor = person.color || this.config.markerStyles.default.color;

        window.sshrDebugLog(`🔄 [PARALLEL-TRACKING] Rotation calculated: ${initialRotation}°, Color: ${finalColor}`);

        // Vypočítej reálné duration podle timestampů
        const startSampleTime = this.normaliseTimestamp(previousTimestamp || person.metadata.previousTimestamp || timestamp);
        const targetSampleTime = this.normaliseTimestamp(timestamp);
        const realTimeDiff = targetSampleTime - startSampleTime; // ms
        const distance = this.calculateDistance([startLat, startLng], newPosition);

        // Base duration podle konfigurace, ale adaptované na reálný čas a vzdálenost
        let duration = this.config.animation.baseSpeed;

        if (realTimeDiff > 0 && realTimeDiff < 10000) { // max 10s rozdíl
            duration = Math.min(Math.max(realTimeDiff, this.config.animation.minDuration), this.config.animation.maxDuration);
        } else if (distance > 15) {
            // Velký skok - použij rychlejší animaci
            duration = this.config.animation.minDuration;
        }

        window.sshrDebugLog(`⏱️ [PARALLEL-TRACKING] Animation duration: ${duration}ms (realTime: ${realTimeDiff}ms, distance: ${distance.toFixed(1)}m)`);

        // Aplikuj ikonu s konečnou rotací a barvou hned na začátku
        sshrApplyIcon(marker, finalColor, initialRotation);
        person.rotation = initialRotation;

        const targets = { lat: startLat, lng: startLng };
        const animation = anime({
            targets,
            lat: newPosition[0],
            lng: newPosition[1],
            duration: duration,
            easing: this.config.animation.easing,
            update: () => {
                // Pouze posun markeru, NEMĚNIT rotaci ani barvu během animace
                marker.setLatLng([targets.lat, targets.lng]);
            },
            complete: () => {
                window.sshrDebugLog(`✅ [PARALLEL-TRACKING] Animation completed for person ${person.id}`);
                this.activeAnimations.delete(marker);
                marker._animeInstance = null;
                person.prevPosition = [...newPosition];
                marker.setLatLng(newPosition);
                // Finální aplikace - ikona už má správnou rotaci a barvu
            }
        });

        marker._animeInstance = animation;
        this.activeAnimations.set(marker, animation);
    }

    /**
     * Update person trail
     */
    updatePersonTrail(person, newPosition) {
        person.trail.push({
            position: newPosition,
            timestamp: new Date()
        });

        // Limit trail length
        if (person.trail.length > this.config.maxHistoryPoints) {
            person.trail.shift();
        }

        // TODO: Implement visual trail rendering
        // This would create a polyline showing the person's path
    }

    /**
     * Update speed calculations
     */
    updateSpeedCalculations(personId, speed) {
        const speeds = this.speedCalculations.get(personId);
        speeds.push(speed);

        // Keep only recent speeds for average calculation
        if (speeds.length > this.config.speedSampleSize) {
            speeds.shift();
        }

        const person = this.persons.get(personId);
        person.stats.averageSpeed = speeds.reduce((a, b) => a + b, 0) / speeds.length;
        person.stats.maxSpeed = Math.max(person.stats.maxSpeed, speed);
    }

    /**
     * Update movement history
     */
    updateMovementHistory(personId, position, timestamp) {
        const history = this.movementHistory.get(personId) || [];
        const normalisedTimestamp = this.normaliseTimestamp(timestamp);
        history.push({ position, timestamp: normalisedTimestamp });

        if (!this.movementHistory.has(personId)) {
            this.movementHistory.set(personId, history);
        }

        // Limit history size
        if (history.length > this.config.maxHistoryPoints) {
            history.shift();
        }

        let fullTrack = this.fullTrajectories.get(personId);
        if (!fullTrack) {
            fullTrack = [];
            this.fullTrajectories.set(personId, fullTrack);
        }

        fullTrack.push({
            lat: position[0],
            lng: position[1],
            timestamp: normalisedTimestamp
        });

        const limit = this.config.trajectoryHistoryLimit;
        if (Number.isFinite(limit) && fullTrack.length > limit) {
            fullTrack.splice(0, fullTrack.length - limit);
        }
    }

    /**
     * Provide full trajectory history for rendering layers
     */
    getTrajectoryPoints(personId) {
        const track = this.fullTrajectories.get(personId);
        if (!track) return [];
        return track.map(sample => ({
            lat: sample.lat,
            lng: sample.lng,
            timestamp: sample.timestamp
        }));
    }

    /**
     * Check for incidents
     */
    checkForIncidents(person, speed) {
        const incidents = [];

        // Speed violations
        if (speed > this.config.alertThresholds.speed) {
            incidents.push({
                type: 'speed-violation',
                person: person.id,
                value: speed,
                threshold: this.config.alertThresholds.speed,
                timestamp: new Date()
            });
        }

        // Zone violations
        if (this.config.alertThresholds.zoneViolation) {
            const zoneViolation = this.checkZoneViolations(person);
            if (zoneViolation) {
                incidents.push(zoneViolation);
                person.stats.zoneViolations++;
            }
        }

        // Report incidents
        incidents.forEach(incident => {
            this.triggerEvent('incident-detected', incident);
        });
    }

    /**
     * Check if person is violating any zones
     */
    checkZoneViolations(person) {
        // TODO: Implement with Turf.js point-in-polygon detection
        // This would check if person is in restricted zones
        return null;
    }

    /**
     * Update marker style based on movement state
     */
    updateMarkerStyle(person, smoothSpeed) {
        if (!person || !person.marker) return;

        let style;

        // Priority: zone violations override movement status
        if (person.metadata.zoneDetails?.violation) {
            style = this.config.markerStyles.violation;
            person.metadata.status = 'violation';
        } else {
            // Use stable movement status from hysteresis (not direct speed)
            switch (person.movementStatus) {
                case 'moving':
                    style = this.config.markerStyles.moving;
                    person.metadata.status = 'moving';
                    break;
                case 'stationary':
                    style = this.config.markerStyles.stationary;
                    person.metadata.status = 'stationary';
                    break;
                default: // 'active'
                    style = this.config.markerStyles.default;
                    person.metadata.status = 'active';
                    break;
            }
        }

        // KRITICKÁ OPRAVA: NIKDY NEMĚNIT BARVU OSOBY - má být fixní po celou dobu animace
        // person.color = style.color;  // ZAKOMENTOVÁNO - barva osoby se nenastavuje podle pohybu
        // NEAPLIKOVAT ikonu zde - nechá animaci nastavit správnou rotaci a barvu
        window.sshrDebugLog(`🎨 [PARALLEL-TRACKING] Stable color: ${style.color} (status: ${person.movementStatus}, smooth: ${smoothSpeed.toFixed(1)} km/h)`);

        // Update popup content
        const popupContent = this.createPersonPopup(person);
        person.marker.setPopupContent(popupContent);
    }

    /**
     * Remove person from tracking
     */
    removePerson(personId) {
        const person = this.persons.get(personId);
        if (!person) return false;

        try {
            // Remove marker from map
            if (person.marker) {
                if (person.marker._animeInstance && typeof person.marker._animeInstance.pause === 'function') {
                    person.marker._animeInstance.pause();
                    person.marker._animeInstance = null;
                }
                this.map.removeLayer(person.marker);
            }

            // Stop any animations
            if (this.activeAnimations.has(person.marker)) {
                this.activeAnimations.get(person.marker).pause();
                this.activeAnimations.delete(person.marker);
            }

            // Clean up data
        this.persons.delete(personId);
        this.lastPositions.delete(personId);
        this.movementHistory.delete(personId);
        this.fullTrajectories.delete(personId);
        this.speedCalculations.delete(personId);
            this.lastActivatedAnchors.delete(personId); // Cleanup sticky anchor data

            console.log(`🚪 [PERSON-TRACKER] Removed person ${personId}`);

            // Trigger event
            this.triggerEvent('person-removed', { personId, person });

            if (window.sshrPersons && typeof window.sshrPersons.delete === 'function') {
                window.sshrPersons.delete(personId);
            }

            return true;
        } catch (error) {
            console.error(`❌ [PERSON-TRACKER] Error removing person ${personId}:`, error);
            return false;
        }
    }

    /**
     * Get all tracked persons
     */
    getAllPersons() {
        return Array.from(this.persons.values());
    }

    /**
     * Get person by ID
     */
    getPerson(personId) {
        return this.persons.get(personId);
    }

    /**
     * Normalize mixed timestamp inputs to Date objects
     */
    normaliseTimestamp(value) {
        if (value instanceof Date && !Number.isNaN(value.getTime())) {
            return value;
        }
        const parsed = new Date(value);
        if (!Number.isNaN(parsed.getTime())) {
            return parsed;
        }
        return new Date();
    }

    /**
     * Calculate distance between two points using Haversine formula
     */
    calculateDistance(pos1, pos2) {
        const R = 6371e3; // Earth's radius in meters
        const φ1 = pos1[0] * Math.PI/180;
        const φ2 = pos2[0] * Math.PI/180;
        const Δφ = (pos2[0]-pos1[0]) * Math.PI/180;
        const Δλ = (pos2[1]-pos1[1]) * Math.PI/180;

        const a = Math.sin(Δφ/2) * Math.sin(Δφ/2) +
                  Math.cos(φ1) * Math.cos(φ2) *
                  Math.sin(Δλ/2) * Math.sin(Δλ/2);
        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));

        return R * c; // Distance in meters
    }

    /**
     * Get status badge color for Bootstrap
     */
    getStatusBadgeColor(status) {
        const colors = {
            'active': 'primary',
            'moving': 'success',
            'stationary': 'warning',
            'violation': 'danger',
            'offline': 'secondary'
        };
        return colors[status] || 'secondary';
    }

    /**
     * Get fixed color for person based on ID - ensures consistent color throughout animation
     * Uses HSL rotation to generate unlimited unique colors
     */
    getFixedPersonColor(personId) {
        // Initialize color allocation tracker if not exists
        if (!this.colorAllocation) {
            this.colorAllocation = new Map();
            this.nextColorIndex = 0;
        }

        // Check if person already has assigned color
        if (this.colorAllocation.has(personId)) {
            return this.colorAllocation.get(personId);
        }

        // Generate unique color using HSL rotation
        // Distribute hue evenly across 360 degrees with golden ratio for better distribution
        const goldenRatio = 0.618033988749;
        const hue = (this.nextColorIndex * goldenRatio * 360) % 360;

        // Use fixed saturation and lightness for consistency and visibility
        const saturation = 70; // Rich colors
        const lightness = 35;  // Dark enough for good contrast on light backgrounds

        const assignedColor = `hsl(${Math.round(hue)}, ${saturation}%, ${lightness}%)`;

        this.colorAllocation.set(personId, assignedColor);
        this.nextColorIndex++;

        window.sshrDebugLog(`🎨 [PARALLEL-TRACKING] Person ${personId} assigned HSL color: ${assignedColor} (hue: ${Math.round(hue)}°, index: ${this.nextColorIndex - 1})`);
        return assignedColor;
    }

    /**
     * Make panel draggable within map container bounds
     */
    makePanelDraggable(panel, container) {
        if (!panel || !container) {
            window.sshrDebugLog(`⚠️ [PARALLEL-TRACKING] Cannot make panel draggable - missing panel or container`);
            return;
        }

        let isDragging = false;
        let startX, startY, initialLeft, initialTop;

        // Add drag handle styling to header
        const header = panel.querySelector('.panel-header');
        if (header) {
            header.style.userSelect = 'none';
            header.title = 'Přetáhněte panel';
            header.style.cursor = 'move';
        } else {
            window.sshrDebugLog(`⚠️ [PARALLEL-TRACKING] No .panel-header found in panel for dragging`);
        }

        const startDrag = (e) => {
            isDragging = true;

            // Zakázat Leaflet drag při začátku drag panelu
            if (window.leafletMap) {
                window.leafletMap.dragging.disable();
                window.leafletMap.scrollWheelZoom.disable();
            } else if (window.SSHR && window.SSHR.map) {
                window.SSHR.map.dragging.disable();
                window.SSHR.map.scrollWheelZoom.disable();
            }

            // Get initial positions
            const rect = panel.getBoundingClientRect();
            const containerRect = container.getBoundingClientRect();

            startX = (e.clientX || e.touches[0].clientX);
            startY = (e.clientY || e.touches[0].clientY);

            initialLeft = rect.left - containerRect.left;
            initialTop = rect.top - containerRect.top;

            panel.style.transition = 'none';
            document.addEventListener('mousemove', onDrag);
            document.addEventListener('mouseup', stopDrag);
            document.addEventListener('touchmove', onDrag);
            document.addEventListener('touchend', stopDrag);

            e.preventDefault();
            window.sshrDebugLog(`🖱️ [PARALLEL-TRACKING] Started dragging panel`);
        };

        const onDrag = (e) => {
            if (!isDragging) return;

            const currentX = (e.clientX || e.touches[0].clientX);
            const currentY = (e.clientY || e.touches[0].clientY);

            const deltaX = currentX - startX;
            const deltaY = currentY - startY;

            let newLeft = initialLeft + deltaX;
            let newTop = initialTop + deltaY;

            // Get container and panel dimensions
            const containerRect = container.getBoundingClientRect();
            const panelRect = panel.getBoundingClientRect();

            // Constrain to container bounds
            const maxLeft = containerRect.width - panelRect.width;
            const maxTop = containerRect.height - panelRect.height;

            newLeft = Math.max(0, Math.min(newLeft, maxLeft));
            newTop = Math.max(0, Math.min(newTop, maxTop));

            panel.style.left = `${newLeft}px`;
            panel.style.top = `${newTop}px`;

            e.preventDefault();
        };

        const stopDrag = () => {
            if (!isDragging) return;

            isDragging = false;
            panel.style.transition = '';

            // Povolit Leaflet drag při konci drag panelu
            if (window.leafletMap) {
                window.leafletMap.dragging.enable();
                window.leafletMap.scrollWheelZoom.enable();
            } else if (window.SSHR && window.SSHR.map) {
                window.SSHR.map.dragging.enable();
                window.SSHR.map.scrollWheelZoom.enable();
            }

            document.removeEventListener('mousemove', onDrag);
            document.removeEventListener('mouseup', stopDrag);
            document.removeEventListener('touchmove', onDrag);
            document.removeEventListener('touchend', stopDrag);

            window.sshrDebugLog(`🖱️ [PARALLEL-TRACKING] Stopped dragging panel`);
        };

        // Mouse events
        if (header) {
            header.addEventListener('mousedown', startDrag);
            header.addEventListener('touchstart', startDrag);
        } else {
            // Fallback to entire panel if no header found
            panel.addEventListener('mousedown', startDrag);
            panel.addEventListener('touchstart', startDrag);
        }

        window.sshrDebugLog(`🖱️ [PARALLEL-TRACKING] Panel draggable functionality added`);
    }

    /**
     * Extract simple person number from complex ID (OSOBA č. 1 instead of OSOBA č. SSHR_DATA1)
     */
    extractPersonNumber(personId) {
        // Extract number from PARALLEL_SSHR_DATA1_PERSON_X format
        const match = personId.match(/PERSON_(\d+)/);
        if (match) {
            return match[1];
        }
        // Fallback to last number in ID
        const numbers = personId.match(/\d+/g);
        return numbers ? numbers[numbers.length - 1] : personId.substring(0, 3);
    }

    /**
     * Get current Animation Layers state to determine what should be shown in info panel
     */
    getAnimationLayersState() {
        // Získání stavu z Animation Layers dropdown
        const anchorMode = document.querySelector('input[name="anchor-layer"]:checked')?.value || 'bez-kotev';

        // Polygon checkboxes
        const polygonCheckboxes = document.querySelectorAll('input[name="polygon-layer"]:checked');
        const enabledPolygons = Array.from(polygonCheckboxes).map(cb => cb.value);

        const greenPolygons = enabledPolygons.includes('green-polygons');
        const redPolygons = enabledPolygons.includes('red-polygons');
        const greenPolylines = enabledPolygons.includes('green-polylines');
        const redPolylines = enabledPolygons.includes('red-polylines');

        const result = {
            anchors: anchorMode !== 'bez-kotev', // true if 's-kotvami-bez-cisel' or 's-id-kotev'
            anchorNumbers: anchorMode === 's-id-kotev',
            zones: greenPolygons || redPolygons || greenPolylines || redPolylines,
            greenZones: greenPolygons || greenPolylines,
            redZones: redPolygons || redPolylines,
            segments: greenPolygons || greenPolylines // segments pouze pokud máme GREEN zóny
        };

        window.sshrDebugLog(`🎭 [DEBUG] getAnimationLayersState: anchorMode='${anchorMode}', result=`, result);
        return result;
    }

    /**
     * Get person zone status (GREEN/RED detection)
     */
    getPersonZoneStatus(person) {
        try {
            const [lat, lng] = person.position;

            // DEBUG: Check what zone systems are available
            window.sshrDebugLog(`🔍 [DEBUG] Zone systems available: SSHR_ZONES=${typeof window.SSHR_ZONES}, ZONES_SSHR=${typeof window.ZONES_SSHR}`);
            if (window.SSHR_ZONES) {
                window.sshrDebugLog(`🔍 [DEBUG] SSHR_ZONES.greens length: ${window.SSHR_ZONES.greens?.length || 'undefined'}`);
            }

            // Check if point is in any GREEN zone using SSHR_ZONES.greens
            if (typeof window.SSHR_ZONES !== 'undefined' && window.SSHR_ZONES.greens) {
                const greenZones = window.SSHR_ZONES.greens;
                window.sshrDebugLog(`🔍 [DEBUG] Found ${greenZones.length} GREEN zones`);

                for (const zone of greenZones) {
                    if (this.isPointInPolygon([lat, lng], zone.coordinates)) {
                        return {
                            inGreen: true,
                            inRed: false,
                            greenZone: zone
                        };
                    }
                }
            }

            // If not in GREEN, check if inside fence (= RED zone)
            if (typeof window.SSHR_ZONES !== 'undefined' && window.SSHR_ZONES.helpers) {
                const insideFence = window.SSHR_ZONES.helpers.pointInFence(lat, lng);
                return {
                    inGreen: false,
                    inRed: insideFence, // Inside fence but not in GREEN = RED
                    greenZone: null
                };
            }

        } catch (error) {
            window.sshrDebugLog(`⚠️ [PARALLEL-TRACKING] Zone status error: ${error.message}`);
        }
        return { inGreen: false, inRed: false, greenZone: null };
    }

    /**
     * Get nearby anchor within specified radius based on anchor group (7m/10m/15m)
     */
    getNearbyAnchor(position) {
        try {
            // Fallback pro anchor data s ochranou pro budoucí použití
            const anchors = window.ANCHORS || globalThis.ANCHORS;

            // DEBUG: Check anchor data availability
            window.sshrDebugLog(`⚓ [DEBUG] ANCHORS available: ${typeof anchors}, length: ${anchors?.length || 'undefined'}`);

            // ANCHOR_SSHR.js exports ANCHORS array directly to window
            if (typeof anchors !== 'undefined' && Array.isArray(anchors)) {
                const [lat, lng] = position;

                // Define anchor groups with different perimeters
                const anchorGroups = {
                    // Group 1: 10m perimeter
                    group10m: [8,80,70,67,68,64,19,21,62,61,55,54,48,57,53,35,30,32,33,48,47,46,37,35,36],
                    // Group 2: 15m perimeter
                    group15m: [45,44,43,42],
                    // Group 3: 7m perimeter (default for all others)
                    defaultRadius: 7
                };

                for (const anchor of anchors) {
                    const distance = this.calculateDistance([lat, lng], [anchor.lat, anchor.lng]);

                    // Determine activation radius based on anchor group
                    let activationRadius = anchorGroups.defaultRadius; // Default 7m

                    if (anchorGroups.group10m.includes(anchor.anchorNumber)) {
                        activationRadius = 10;
                    } else if (anchorGroups.group15m.includes(anchor.anchorNumber)) {
                        activationRadius = 15;
                    }

                    if (distance <= activationRadius) {
                        return {
                            id: anchor.anchorNumber, // Use anchorNumber as ID
                            distance: distance,
                            activationRadius: activationRadius // Include radius info for corona sizing
                        };
                    }
                }
            }
        } catch (error) {
            window.sshrDebugLog(`⚠️ [PARALLEL-TRACKING] Nearby anchor error: ${error.message}`);
        }
        return null;
    }

    /**
     * Get GREEN zone segment for position
     */
    getGreenZoneSegment(position) {
        try {
            const [lat, lng] = position;
            if (typeof window.SSHR_ZONES !== 'undefined' && window.SSHR_ZONES.greens) {
                const zones = window.SSHR_ZONES.greens;
                for (const zone of zones) {
                    if (this.isPointInPolygon([lat, lng], zone.coordinates)) {
                        // Return zone name from ZONES_SSHR.js structure
                        // GREEN_ENTRY -> ENTRY, GREEN_A -> A, etc.
                        if (zone.name) {
                            return zone.name.replace('GREEN ', '').replace('ZONE ', '');
                        }
                        return zone.id?.replace('GREEN_', '') || 'UNKNOWN';
                    }
                }
            }
        } catch (error) {
            window.sshrDebugLog(`⚠️ [PARALLEL-TRACKING] Green segment error: ${error.message}`);
        }
        return null;
    }

    /**
     * Simple point-in-polygon check
     * Opraveno: správné pořadí souřadnic pro geolokaci [lat, lng]
     */
    isPointInPolygon(point, polygon) {
        // Správné pořadí: lat = y, lng = x pro geografické souřadnice
        const [lat, lng] = point;
        const [y, x] = [lat, lng]; // lat je y-ová souřadnice, lng je x-ová
        let inside = false;

        for (let i = 0, j = polygon.length - 1; i < polygon.length; j = i++) {
            // Stejná konverze pro polygon body
            const [lati, lngi] = polygon[i];
            const [latj, lngj] = polygon[j];
            const [yi, xi] = [lati, lngi];
            const [yj, xj] = [latj, lngj];

            if (((yi > y) !== (yj > y)) && (x < (xj - xi) * (y - yi) / (yj - yi) + xi)) {
                inside = !inside;
            }
        }

        return inside;
    }

    /**
     * Get incident count for person (uses local detailed storage)
     */
    getPersonIncidentCount(personId) {
        try {
            let totalIncidents = 0;

            // Count active incidents from IncidentEngine
            if (window.SSHRIncidentEngine && window.SSHRIncidentEngine.activeIncidents) {
                const activeIncident = window.SSHRIncidentEngine.activeIncidents.get(personId);
                if (activeIncident) {
                    totalIncidents += 1; // Currently active incident
                }
            }

            // Count resolved incidents from our detailed storage
            const detailedIncidents = this.getPersonIncidentDetails(personId);
            totalIncidents += detailedIncidents.length;

            return totalIncidents;
        } catch (error) {
            window.sshrDebugLog(`⚠️ [PARALLEL-TRACKING] Incident count error: ${error.message}`);
        }
        return 0;
    }

    /**
     * Activate amber corona effect for specific anchor (tailwind amber-500)
     */
    activateAnchorCorona(anchorId, activationRadius = 7) {
        try {
            // Direct approach - find anchor marker and apply amber glow
            if (window.SSHR && window.SSHR.anchorLayers) {
                const anchors = window.SSHR.anchorLayers;
                anchors.eachLayer((layer) => {
                    if (layer.anchorId === anchorId) {
                        // Calculate corona size based on activation radius - proportional scaling
                        const baseSize = 20; // Base shadow blur for 7m radius
                        const scaleFactor = activationRadius / 7; // Scale relative to 7m base
                        const shadowBlur = Math.round(baseSize * scaleFactor);
                        const shadowSpread = Math.round(8 * scaleFactor);

                        // Apply amber-500 (#f59e0b) corona effect using CSS
                        const element = layer.getElement();
                        if (element) {
                            element.style.boxShadow = `0 0 ${shadowBlur}px ${shadowSpread}px #f59e0b`;
                            element.style.borderRadius = '50%';
                            element.style.transition = 'box-shadow 0.3s ease';
                            window.sshrDebugLog(`✨ [PARALLEL-TRACKING] Corona activated for anchor ${anchorId} (radius: ${activationRadius}m, shadow: ${shadowBlur}px)`);
                        }
                    }
                });
            }

            // Alternative: use global renderer function if available
            if (typeof window.activateAnchorFlashlight === 'function') {
                window.activateAnchorFlashlight(anchorId, activationRadius);
            }
        } catch (error) {
            window.sshrDebugLog(`⚠️ [PARALLEL-TRACKING] Anchor corona activation error: ${error.message}`);
        }
    }

    /**
     * Deactivate all anchor corona effects
     */
    deactivateAllAnchorCoronas() {
        try {
            // Direct approach - remove all corona effects
            if (window.SSHR && window.SSHR.anchorLayers) {
                const anchors = window.SSHR.anchorLayers;
                anchors.eachLayer((layer) => {
                    const element = layer.getElement();
                    if (element) {
                        element.style.boxShadow = '';
                        element.style.borderRadius = '';
                        element.style.transition = '';
                    }
                });
                window.sshrDebugLog(`🌑 [PARALLEL-TRACKING] All coronas deactivated`);
            }

            // Alternative: use global renderer function if available
            if (typeof window.deactivateAllAnchorFlashlights === 'function') {
                window.deactivateAllAnchorFlashlights();
            }
        } catch (error) {
            window.sshrDebugLog(`⚠️ [PARALLEL-TRACKING] Anchor corona deactivation error: ${error.message}`);
        }
    }

    /**
     * Event system for notifications
     */
    triggerEvent(eventType, data) {
        // TODO: Implement proper event system
        // This would integrate with the main SSHR event system
        // Event emitted - debug log removed for performance

        // Dispatch custom event
        if (typeof window !== 'undefined') {
            window.dispatchEvent(new CustomEvent(`sshr-${eventType}`, { detail: data }));
        }
    }

    /**
     * Cleanup method
     */
    destroy() {
        debugLog("🧹 [PERSON-TRACKER] Cleaning up...");

        // Remove all persons
        const personIds = Array.from(this.persons.keys());
        personIds.forEach(id => this.removePerson(id));

        // Clear all data
        this.persons.clear();
        this.activeAnimations.clear();
        this.lastPositions.clear();
        this.movementHistory.clear();
        this.fullTrajectories.clear();
        this.speedCalculations.clear();
        this.lastActivatedAnchors.clear(); // Clear sticky anchor data
    }

    // ===== INFRA PROXIMITY MARKER BLINKING =====

    activateMarkerBlink(personId) {
        const person = this.persons.get(personId);
        if (!person || !person.marker) return;

        // Avoid multiple blink animations
        if (person.blinkAnimation) return;

        const markerElement = person.marker.getElement();
        if (!markerElement) return;

        console.log(`🔴 [MARKER-BLINK] Starting blink for person ${personId}`);

        // Create blinking animation with anime.js
        person.blinkAnimation = anime({
            targets: markerElement,
            opacity: [1, 0.3, 1],
            duration: 800,
            easing: 'easeInOutSine',
            loop: true,
            direction: 'normal'
        });

        // Add visual indicator
        person.isBlinking = true;
    }

    deactivateMarkerBlink(personId) {
        const person = this.persons.get(personId);
        if (!person) return;

        console.log(`⚪ [MARKER-BLINK] Stopping blink for person ${personId}`);

        // Stop animation
        if (person.blinkAnimation) {
            person.blinkAnimation.pause();
            person.blinkAnimation = null;
        }

        // Reset opacity
        const markerElement = person.marker?.getElement();
        if (markerElement) {
            markerElement.style.opacity = '1';
        }

        person.isBlinking = false;
    }

    /**
     * Setup incident event listeners to capture detailed incident data
     */
    setupIncidentListeners() {
        console.log(`🎧 [INCIDENT-LISTENERS] Setting up incident event listeners`);

        // Listen for incident resolve events to capture detailed incident data
        if (window.SSHRIncidentEngine) {
            console.log(`✅ [INCIDENT-LISTENERS] SSHRIncidentEngine found, setting up listeners`);

            window.SSHRIncidentEngine.on('incident-resolve', (evt) => {
                console.log(`🔔 [INCIDENT-LISTENERS] Received incident-resolve event:`, evt);

                const data = evt.detail || evt;
                const personId = data.personId;

                if (!personId) {
                    console.warn('⚠️ [PARALLEL-TRACKING] incident-resolve missing personId:', data);
                    return;
                }

                console.log(`📝 [INCIDENT-LISTENERS] Processing incident for person ${personId}`);


                // Create detailed incident object
                const incidentDetail = {
                    id: `incident-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
                    personId: personId,
                    dataset: data.dataset,
                    timestamp: new Date().toISOString(),
                    duration: data.durationSeconds,
                    startGPS: data.startSample ? {
                        lat: data.startSample.GPS_lat,
                        lng: data.startSample.GPS_lng,
                        timestamp: data.startSample.timestamp
                    } : null,
                    endGPS: data.endSample ? {
                        lat: data.endSample.GPS_lat,
                        lng: data.endSample.GPS_lng,
                        timestamp: data.endSample.timestamp
                    } : null,
                    maxDistance: data.maxDistanceMeters,
                    maxDistanceGPS: data.maxDistanceSample ? {
                        lat: data.maxDistanceSample.GPS_lat,
                        lng: data.maxDistanceSample.GPS_lng,
                        timestamp: data.maxDistanceSample.timestamp
                    } : null,
                    type: 'zone-violation'
                };

                // Store incident details
                if (!this.incidentDetails.has(personId)) {
                    this.incidentDetails.set(personId, []);
                    console.log(`🆕 [INCIDENT-LISTENERS] Created new incident store for ${personId}`);
                }

                const beforeCount = this.incidentDetails.get(personId).length;
                this.incidentDetails.get(personId).push(incidentDetail);
                const afterCount = this.incidentDetails.get(personId).length;

                console.log(`💾 [INCIDENT-LISTENERS] Stored incident for ${personId}: ${beforeCount} → ${afterCount} total incidents`);

                // Limit stored incidents per person (keep last 10)
                const incidents = this.incidentDetails.get(personId);
                if (incidents.length > 10) {
                    incidents.splice(0, incidents.length - 10);
                    console.log(`✂️ [INCIDENT-LISTENERS] Trimmed incidents for ${personId} to last 10`);
                }

                console.log(`📊 [PARALLEL-TRACKING] Captured incident details for person ${personId}:`, incidentDetail);
            });

            console.log('✅ [PARALLEL-TRACKING] Incident event listeners setup complete');
        } else {
            console.warn('⚠️ [PARALLEL-TRACKING] SSHRIncidentEngine not available for event listening');
        }
    }

    /**
     * Get detailed incidents for person
     */
    getPersonIncidentDetails(personId) {
        return this.incidentDetails.get(personId) || [];
    }

}

// Export for use in main renderer
if (typeof window !== 'undefined') {
    window.PersonTracker = PersonTracker;
}

debugLog("✅ [PARALLEL-TRACKING] PersonTracker class loaded successfully");
