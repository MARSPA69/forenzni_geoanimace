/**
 * SSHR Polygon Manager - Dual-Mode Zone System
 * ============================================
 *
 * PolygonManager Class - FIXED/FLOAT režimy pro GREEN/RED polygony
 * Features: Interactive polygon drawing, automatic zone calculation, validation
 *
 * Dependencies: Leaflet, Turf.js, Leaflet.draw
 */

console.log("🔺 [POLYGON-MANAGER] Loading SSHR PolygonManager module...");

class SSHRPolygonManager {
    constructor(map, options = {}) {
        this.map = map;
        this.mode = options.mode || 'FIXED'; // 'FIXED' nebo 'FLOAT'
        this.zones = {
            green: new Map(),
            red: new Map(),
            neutral: new Map()
        };
        this.polygonLayers = new Map();
        this.drawControl = null;
        this.editableLayers = null;
        this.managementLimit = null;
        this.managementActive = false;
        this._drawEventListenersRegistered = false;
        this.selectedShape = 4; // Default to 4-sided polygon
        this.activeReshapeZoneId = null;
        this.confirmedZones = new Set(); // Track individually confirmed zones
        this.pendingZones = new Set(); // Track zones awaiting confirmation
        this.drawingActive = false;
        this._templateClickHandler = null;
        this.templateRadiusMeters = options.templateRadiusMeters || 25;
        this.storageKeys = {
            zones: 'sshr_float_zones',
            draft: 'sshr_float_layout_draft',
            active: 'sshr_float_layout_active',
            history: 'sshr_float_layout_history'
        };
        this.activeLayoutId = null;
        this.currentLayout = null;
        this.layoutDraft = null;
        this.layoutHistory = [];
        this._suspendLayoutTracking = false;

        // Configuration
        this.config = {
            modes: {
                FIXED: {
                    editable: false,
                    predefined: true,
                    autoRedZones: false
                },
                FLOAT: {
                    editable: true,
                    predefined: false,
                    autoRedZones: true
                }
            },
            styles: {
                green: {
                    color: '#52c674',
                    fillColor: '#52c674',
                    fillOpacity: 0.3,
                    weight: 2,
                    dashArray: null
                },
                red: {
                    color: '#e85d75',
                    fillColor: '#e85d75',
                    fillOpacity: 0.3,
                    weight: 2,
                    dashArray: null
                },
                neutral: {
                    color: '#6c757d',
                    fillColor: '#6c757d',
                    fillOpacity: 0.1,
                    weight: 1,
                    dashArray: '5, 5'
                },
                fence: {
                    color: '#dc3545',
                    fillColor: 'transparent',
                    fillOpacity: 0,
                    weight: 3,
                    dashArray: null
                },
                greenPolyline: {
                    color: '#52c674',
                    fillColor: 'transparent',
                    fillOpacity: 0,
                    weight: 2,
                    dashArray: null
                },
                redPolyline: {
                    color: '#e85d75',
                    fillColor: 'transparent',
                    fillOpacity: 0,
                    weight: 2,
                    dashArray: null
                },
                editing: {
                    color: '#007bff',
                    fillColor: '#007bff',
                    fillOpacity: 0.2,
                    weight: 3,
                    dashArray: '10, 5'
                }
            },
            bufferDistance: 50, // meters for auto-generated zones
            templateRadiusMeters: 25,
            validationRules: {
                minZoneArea: 100, // square meters
                maxZoneArea: 50000, // square meters
                maxOverlapPercent: 10 // percent
            }
        };

        this.templateRadiusMeters = options.templateRadiusMeters || this.config.templateRadiusMeters;

        this.loadPersistedLayoutState();
        this.init();
        console.log(`✅ [POLYGON-MANAGER] Initialized in ${this.mode} mode`);
    }

    /**
     * Initialize the polygon management system
     */
    init() {
        this.setupEditableLayers();
        this.setupDrawingTools();
        this.setupEventListeners();
        this.loadDefaultZones();
    }

    /**
     * Setup editable layers for polygon management
     */
    setupEditableLayers() {
        // Create FeatureGroup for editable layers
        this.editableLayers = new L.FeatureGroup();
        this.map.addLayer(this.editableLayers);

        console.log("📋 [POLYGON-MANAGER] Editable layers initialized");
    }

    /**
     * Setup drawing tools for FLOAT mode - DISABLED
     */
    setupDrawingTools() {
        console.log("🚫 [POLYGON-MANAGER] Drawing tools disabled - Management zones functionality removed");
    }

    /**
     * Setup event listeners
     */
    setupEventListeners() {
        // Drawing events for FLOAT mode
        if (this.mode === 'FLOAT') {
            this.registerDrawingEventListeners();
        }

        // Polygon click events (always active)
        this.map.on('click', (e) => this.onMapClick(e));
    }

    /**
     * Register Leaflet.draw event listeners for FLOAT mode
     */
    registerDrawingEventListeners() {
        // Prevent duplicate registration
        if (this._drawEventListenersRegistered) {
            return;
        }

        this.map.on('draw:created', (e) => this.onPolygonCreated(e));
        this.map.on('draw:edited', (e) => this.onPolygonEdited(e));
        this.map.on('draw:deleted', (e) => this.onPolygonDeleted(e));

        this._drawEventListenersRegistered = true;
        console.log("🎧 [POLYGON-MANAGER] Leaflet.draw event listeners registered");
    }

    /**
     * Unregister Leaflet.draw event listeners
     */
    unregisterDrawingEventListeners() {
        if (!this._drawEventListenersRegistered) {
            return;
        }

        this.map.off('draw:created');
        this.map.off('draw:edited');
        this.map.off('draw:deleted');

        this._drawEventListenersRegistered = false;
        console.log("🔇 [POLYGON-MANAGER] Leaflet.draw event listeners unregistered");
    }

    /**
     * Load default zones based on mode
     * NOTE: Only loads perimeter fence on startup for clean start
     */
    loadDefaultZones() {
        // Always load the perimeter fence (security boundary)
        this.loadPerimeterFence();

        // Do NOT load internal zones automatically for clean start
        // Zones will be loaded on-demand through Animation Layers panel
        console.log('🎯 [POLYGON-MANAGER] Clean startup: Only perimeter fence loaded, internal zones on-demand');
    }

    /**
     * Load only the perimeter fence (always required for security)
     */
    loadPerimeterFence() {
        const zoneData = window.SSHR_ZONES;
        if (!zoneData || !zoneData.fence) {
            console.warn('⚠️ [POLYGON-MANAGER] SSHR_ZONES fence not available');
            return;
        }

        const fence = zoneData.fence;
        const fenceZone = {
            id: fence.id || 'FENCE',
            name: fence.name || 'Perimeter Fence',
            coordinates: fence.coordinates
        };

        // Add fence as RED perimeter line (not filled polygon)
        this.addFenceLine(fenceZone);
        console.log('🔴 [POLYGON-MANAGER] Perimeter fence loaded as red boundary line');
    }

    /**
     * Add fence as a line (perimeter boundary) without fill
     */
    addFenceLine(fenceData) {
        const coordinates = fenceData.coordinates;
        if (!coordinates || !Array.isArray(coordinates) || coordinates.length < 3) {
            console.warn('⚠️ [POLYGON-MANAGER] Invalid fence coordinates');
            return;
        }

        // Create Leaflet polyline (not polygon) for fence
        const fenceStyle = this.config.styles.fence;
        const fenceLine = L.polyline(coordinates, fenceStyle);

        // Add popup with fence info
        fenceLine.bindPopup(`
            <div class="zone-popup">
                <h6 class="mb-1">${fenceData.name}</h6>
                <small class="text-muted">Perimeter boundary</small>
            </div>
        `);

        // Store fence reference
        this.polygonLayers.set('fence', fenceLine);

        // Add to map
        this.map.addLayer(fenceLine);

        console.log('🔴 [POLYGON-MANAGER] Fence line added to map');
    }

    /**
     * Add zones as polylines (borders only, no fill)
     */
    addZonePolylines(zones, type) {
        const style = type === 'green' ? this.config.styles.greenPolyline : this.config.styles.redPolyline;
        const layerGroupName = `${type}-polylines`;

        // Remove existing polylines of this type
        if (this.polygonLayers.has(layerGroupName)) {
            const existingLayer = this.polygonLayers.get(layerGroupName);
            if (this.map.hasLayer(existingLayer)) {
                this.map.removeLayer(existingLayer);
            }
        }

        // Create new layer group for polylines
        const polylineGroup = L.layerGroup();

        zones.forEach(zone => {
            if (!zone.coordinates || !Array.isArray(zone.coordinates)) return;

            // Create polyline (border only)
            const polyline = L.polyline(zone.coordinates, style);

            polyline.bindPopup(`
                <div class="zone-popup">
                    <h6 class="mb-1">${zone.name || zone.id}</h6>
                    <small class="text-muted">${type.toUpperCase()} border</small>
                </div>
            `);

            polylineGroup.addLayer(polyline);
        });

        // Store and add to map
        this.polygonLayers.set(layerGroupName, polylineGroup);
        this.map.addLayer(polylineGroup);

        console.log(`📐 [POLYGON-MANAGER] Added ${zones.length} ${type.toUpperCase()} polylines`);
    }

    /**
     * Add zones as filled polygons
     */
    addZonePolygons(zones, type) {
        const style = this.config.styles[type];
        const layerGroupName = `${type}-polygons`;

        // Remove existing polygons of this type
        if (this.polygonLayers.has(layerGroupName)) {
            const existingLayer = this.polygonLayers.get(layerGroupName);
            if (this.map.hasLayer(existingLayer)) {
                this.map.removeLayer(existingLayer);
            }
        }

        // Create new layer group for filled polygons
        const polygonGroup = L.layerGroup();

        zones.forEach(zone => {
            if (!zone.coordinates || !Array.isArray(zone.coordinates)) return;

            // Create filled polygon
            const polygon = L.polygon(zone.coordinates, style);

            polygon.bindPopup(`
                <div class="zone-popup">
                    <h6 class="mb-1">${zone.name || zone.id}</h6>
                    <small class="text-muted">${type.toUpperCase()} zone</small>
                </div>
            `);

            polygonGroup.addLayer(polygon);
        });

        // Store and add to map
        this.polygonLayers.set(layerGroupName, polygonGroup);
        this.map.addLayer(polygonGroup);

        console.log(`🎨 [POLYGON-MANAGER] Added ${zones.length} ${type.toUpperCase()} filled polygons`);
    }

    /**
     * Remove specific layer type (polylines or polygons)
     */
    removeLayerType(layerGroupName) {
        if (this.polygonLayers.has(layerGroupName)) {
            const layer = this.polygonLayers.get(layerGroupName);
            if (this.map.hasLayer(layer)) {
                this.map.removeLayer(layer);
            }
            this.polygonLayers.delete(layerGroupName);
            console.log(`🗑️ [POLYGON-MANAGER] Removed layer: ${layerGroupName}`);
        }
    }

    /**
     * Load internal zones on-demand (called from Animation Layers panel)
     */
    loadInternalZones() {
        if (this.mode === 'FIXED') {
            this.loadFixedZones();
        } else {
            this.loadFloatZones();
        }
        console.log('🎯 [POLYGON-MANAGER] Internal zones loaded on-demand');
    }

    /**
     * Load predefined FIXED zones
     */
    loadFixedZones() {
        this.managementActive = false;
        this.managementLimit = null;
        const zoneData = window.SSHR_ZONES;
        if (!zoneData) {
            console.warn('⚠️ [POLYGON-MANAGER] SSHR_ZONES not available, falling back to empty fixed set');
            return;
        }

        const greenZones = (zoneData.greens || []).map((zone) => ({
            id: zone.id,
            name: zone.name,
            coordinates: Array.isArray(zone.coordinates[0])
                ? zone.coordinates
                : zone.coordinates
        }));

        const redZones = (zoneData.reds || []).map((zone) => ({
            id: zone.id,
            name: zone.name,
            coordinates: Array.isArray(zone.coordinates?.[0])
                ? zone.coordinates[0]
                : zone.coordinates
        }));

        this.addZones(greenZones, 'green');
        this.addZones(redZones, 'red');

        console.log(`🔒 [POLYGON-MANAGER] Loaded ${greenZones.length} GREEN and ${redZones.length} RED fixed zones from SSHR data`);
    }

    /**
     * Load or initialize FLOAT zones
     */
    loadFloatZones() {
        // Try to load from localStorage or start empty
        this._suspendLayoutTracking = true;
        try {
            const layoutSource = this.layoutDraft || this.currentLayout;
            if (layoutSource) {
                if (!this.layoutDraft) {
                    try {
                        this.layoutDraft = JSON.parse(JSON.stringify(layoutSource));
                        this.layoutDraft.status = 'draft';
                        this.layoutDraft.updatedAt = new Date().toISOString();
                        this.persistLayoutDraft();
                    } catch (error) {
                        console.warn('⚠️ [POLYGON-MANAGER] Unable to clone layout source for draft state', error);
                    }
                }
                const greenZones = (layoutSource.greens || []).map(zone => this.preparePersistedZone(zone, 'green'));
                const redZones = (layoutSource.reds || []).map(zone => this.preparePersistedZone(zone, 'red'));
                this.addZones(greenZones, 'green');
                this.addZones(redZones, 'red');
                console.log("📁 [POLYGON-MANAGER] Loaded zones from persisted layout state");
                return;
            }

            const savedZones = this.loadZonesFromStorage();
            if (savedZones) {
                this.addZones((savedZones.green || []).map(zone => this.preparePersistedZone(zone, 'green')), 'green');
                this.addZones((savedZones.red || []).map(zone => this.preparePersistedZone(zone, 'red')), 'red');
                console.log("📁 [POLYGON-MANAGER] Loaded zones from storage");
            } else {
                console.log("🆕 [POLYGON-MANAGER] Starting with empty FLOAT zones");
            }
        } finally {
            this._suspendLayoutTracking = false;
        }
    }

    setManagementLimit(limit) {
        if (typeof limit === 'number' && limit > 0) {
            this.managementLimit = limit;
            this.managementActive = true;
            console.log(`🛠️ [POLYGON-MANAGER] Management limit set to ${limit}`);

            // Ensure tracking sets exist whenever we enter management mode
            if (!this.confirmedZones || !(this.confirmedZones instanceof Set)) {
                this.confirmedZones = new Set();
            }
            if (!this.pendingZones || !(this.pendingZones instanceof Set)) {
                this.pendingZones = new Set();
            }
        } else {
            this.managementLimit = null;
            this.managementActive = false;
            console.log('🛠️ [POLYGON-MANAGER] Management limit cleared');

            if (this.confirmedZones) {
                this.confirmedZones.clear();
            }
            if (this.pendingZones) {
                this.pendingZones.clear();
            }
        }
    }

    isManagementMode() {
        return Boolean(this.managementActive);
    }


    /**
     * Add multiple zones of specific type
     */
    addZones(zones, type) {
        zones.forEach(zone => this.addZone(zone, type));
    }

    /**
     * Add a single zone
     */
    addZone(zoneData, type) {
        try {
            const zone = {
                id: zoneData.id || this.generateZoneId(type),
                name: zoneData.name || `${type.toUpperCase()} Zone`,
                type: type,
                coordinates: zoneData.coordinates,
                properties: zoneData.properties || {},
                createdAt: new Date(),
                ...zoneData
            };
            if (typeof zone.createdAt === 'string') {
                zone.createdAt = new Date(zone.createdAt);
            }
            if (typeof zone.modifiedAt === 'string') {
                zone.modifiedAt = new Date(zone.modifiedAt);
            }
            if (typeof zone.confirmedAt === 'string') {
                zone.confirmedAt = new Date(zone.confirmedAt);
            }

            // Create Leaflet polygon
            const polygon = L.polygon(zone.coordinates, this.config.styles[type]);

            // Add popup with zone info
            polygon.bindPopup(this.createZonePopup(zone));

            // Add to map and layers
            polygon.addTo(this.editableLayers);
            this.polygonLayers.set(zone.id, polygon);
            this.zones[type].set(zone.id, zone);

            if (this.managementActive && type === 'green' && this.managementLimit && this.zones.green.size > this.managementLimit) {
                console.warn(`⚠️ [POLYGON-MANAGER] Management limit ${this.managementLimit} exceeded`);
                this.zones[type].delete(zone.id);
                this.polygonLayers.delete(zone.id);
                this.editableLayers.removeLayer(polygon);
                if (typeof window !== 'undefined' && window.dispatchEvent) {
                    window.dispatchEvent(new CustomEvent('sshr-management-limit-exceeded', {
                        detail: { limit: this.managementLimit }
                    }));
                }
                return null;
            }

            // Store reference in polygon
            polygon._sshrZoneId = zone.id;
            polygon._sshrZoneType = type;

            // Add corner handles for FLOAT mode green zones
            if (this.mode === 'FLOAT' && type === 'green') {
                console.log(`🔵 [POLYGON-MANAGER] Adding corner handles for zone ${zone.id} in FLOAT mode`);
                // Add small delay to ensure polygon is fully rendered
                setTimeout(() => {
                    this.addCornerHandles(polygon, zone);
                }, 100);
            } else {
                console.log(`🔵 [POLYGON-MANAGER] NOT adding corner handles - mode: ${this.mode}, type: ${type}`);
            }

            console.log(`🔺 [POLYGON-MANAGER] Added ${type.toUpperCase()} zone: ${zone.name}`);

            // Trigger event
            this.triggerEvent('zone-added', { zone, type });

            // Track layout changes in FLOAT mode when not suspended
            if (this.mode === 'FLOAT' && !this._suspendLayoutTracking) {
                this.recordLayoutChange('zone-added', { zoneId: zone.id, zoneType: type });
            }

            if (type === 'green' && this.config.modes[this.mode].autoRedZones && !this.managementActive && this.mode !== 'FLOAT') {
                this.recalculateRedZones();
            }

            return zone;
        } catch (error) {
            console.error(`❌ [POLYGON-MANAGER] Error adding zone:`, error);
            return null;
        }
    }

    /**
     * Create popup content for zone
     */
    createZonePopup(zone) {
        const typeColor = zone.type === 'green' ? 'success' : zone.type === 'red' ? 'danger' : 'secondary';

        return `
            <div class="zone-popup">
                <h6><i class="fas fa-map-marker-alt"></i> ${zone.name}</h6>
                <hr style="margin: 5px 0;">
                <small>
                    <strong>Type:</strong> <span class="badge bg-${typeColor}">${zone.type.toUpperCase()}</span><br>
                    <strong>ID:</strong> ${zone.id}<br>
                    <strong>Area:</strong> ${this.calculateZoneArea(zone).toFixed(0)} m²<br>
                    <strong>Created:</strong> ${zone.createdAt.toLocaleTimeString()}<br>
                    ${zone.rotation ? `<strong>Rotation:</strong> ${zone.rotation.toFixed(1)}°<br>` : ''}
                    ${this.mode === 'FLOAT' ? `
                        <div class="mt-2">
                            <button class="btn btn-sm btn-outline-primary edit-zone-btn" onclick="window.SSHR.polygonManager.editZone('${zone.id}')">
                                <i class="fas fa-edit"></i> Edit
                            </button>
                            <button class="btn btn-sm btn-outline-info rotate-zone-btn" onclick="window.SSHR.polygonManager.enableRotationMode('${zone.id}')">
                                <i class="fas fa-sync-alt"></i> Rotate
                            </button>
                            <button class="btn btn-sm btn-outline-warning reshape-zone-btn" onclick="window.SSHR.polygonManager.enableReshapeMode('${zone.id}')">
                                <i class="fas fa-expand-arrows-alt"></i> Reshape
                            </button>
                            <button class="btn btn-sm btn-outline-danger delete-zone-btn" onclick="window.SSHR.polygonManager.deleteZone('${zone.id}')">
                                <i class="fas fa-trash"></i> Delete
                            </button>
                        </div>
                    ` : ''}
                </small>
            </div>
        `;
    }


    /**
     * Handle polygon creation in FLOAT mode
     */
    onPolygonCreated(e) {
        console.log("🎨 [POLYGON-MANAGER] Polygon created event triggered");

        const layer = e.layer;
        let coordinates = layer.getLatLngs()[0].map(latlng => [latlng.lat, latlng.lng]);

        // Ensure polygon is properly closed using consistent logic
        coordinates = this.ensurePolygonClosed(coordinates);
        console.log("🔄 [POLYGON-MANAGER] Polygon ensured closed");

        // Check management limit before validation
        if (this.managementActive && this.managementLimit && this.zones.green.size >= this.managementLimit) {
            alert(`Nelze vytvořit další zónu. Dosáhli jste limitu ${this.managementLimit} zón.`);
            this.map.removeLayer(layer);
            return;
        }

        // Validate new polygon
        const validation = this.validatePolygon(coordinates, 'green');
        if (!validation.valid) {
            alert(`Vytvoření zóny selhalo: ${validation.errors.join(', ')}`);
            this.map.removeLayer(layer);
            return;
        }

        // Add as GREEN zone
        const zone = this.addZone({
            name: `Variabilní zóna ${this.zones.green.size + 1}`,
            coordinates: coordinates,
            rotation: 0 // Initialize rotation to 0 degrees
        }, 'green');

        if (zone) {
            // Remove the temporary layer
            this.map.removeLayer(layer);

            // Trigger zone drawn event for UI
            this.onZoneDrawn(zone);

            // Auto-calculate RED zones if enabled
            if (this.config.modes[this.mode].autoRedZones && !this.managementActive) {
                this.recalculateRedZones();
            }

            // Save to storage only if not in management mode
            if (!this.managementActive) {
                this.saveZonesToStorage();
            }

            console.log(`✅ [POLYGON-MANAGER] Zone ${zone.name} created successfully`);
        } else {
            console.error("❌ [POLYGON-MANAGER] Failed to create zone");
            this.map.removeLayer(layer);
        }
    }

    /**
     * Handle polygon editing
     */
    onPolygonEdited(e) {
        e.layers.eachLayer((layer) => {
            const zoneId = layer._sshrZoneId;
            const zoneType = layer._sshrZoneType;

            if (zoneId && zoneType) {
                const zone = this.zones[zoneType].get(zoneId);
                if (zone) {
                    // Update coordinates
                    zone.coordinates = layer.getLatLngs()[0].map(latlng => [latlng.lat, latlng.lng]);
                    zone.modifiedAt = new Date();

                    // Validate edited polygon
                    const validation = this.validatePolygon(zone.coordinates, zoneType);
                    if (!validation.valid) {
                        alert(`Zone edit failed: ${validation.errors.join(', ')}`);
                        // TODO: Revert changes
                        return;
                    }

                    // Update popup
                    layer.setPopupContent(this.createZonePopup(zone));

                    console.log(`📝 [POLYGON-MANAGER] Edited ${zoneType} zone: ${zone.name}`);

                    // Trigger event
                    this.triggerEvent('zone-edited', { zone, zoneType });

                    // Auto-recalculate if needed
                    if (zoneType === 'green' && this.config.modes[this.mode].autoRedZones && !this.managementActive) {
                        this.recalculateRedZones();
                    }

                    // Save to storage
                    if (!this.managementActive) {
                        this.saveZonesToStorage();
                    }

                    if (this.mode === 'FLOAT' && !this._suspendLayoutTracking) {
                        this.recordLayoutChange('zone-edited', { zoneId });
                    }
                }
            }
        });
    }

    /**
     * Handle polygon deletion
     */
    onPolygonDeleted(e) {
        e.layers.eachLayer((layer) => {
            const zoneId = layer._sshrZoneId;
            const zoneType = layer._sshrZoneType;

            if (zoneId && zoneType) {
                this.deleteZone(zoneId);
            }
        });
    }

    /**
     * Delete a zone
     */
    deleteZone(zoneId) {
        // Find zone type
        let zoneType = null;
        let zone = null;

        for (const [type, zones] of Object.entries(this.zones)) {
            if (zones.has(zoneId)) {
                zoneType = type;
                zone = zones.get(zoneId);
                break;
            }
        }

        if (!zone || !zoneType) {
            console.warn(`⚠️ [POLYGON-MANAGER] Zone ${zoneId} not found for deletion`);
            return false;
        }

        try {
            // Remove from map
            const polygon = this.polygonLayers.get(zoneId);
            if (polygon) {
                this.editableLayers.removeLayer(polygon);
                this.polygonLayers.delete(zoneId);
            }

        // Remove from zones
        this.zones[zoneType].delete(zoneId);

        console.log(`🗑️ [POLYGON-MANAGER] Deleted ${zoneType} zone: ${zone.name}`);

        // Trigger event
        this.triggerEvent('zone-deleted', { zoneId, zone, zoneType });

        // Auto-recalculate if needed
        if (zoneType === 'green' && this.config.modes[this.mode].autoRedZones && !this.managementActive) {
            this.recalculateRedZones();
        }

        // Save to storage
        if (!this.managementActive) {
            this.saveZonesToStorage();
        }

            return true;
        } catch (error) {
            console.error(`❌ [POLYGON-MANAGER] Error deleting zone ${zoneId}:`, error);
            return false;
        }
    }

    /**
     * Edit a zone (enter edit mode)
     */
    editZone(zoneId) {
        const polygon = this.polygonLayers.get(zoneId);
        if (polygon && this.mode === 'FLOAT') {
            // Enable editing for this polygon
            polygon.editing.enable();
            polygon.setStyle(this.config.styles.editing);

            console.log(`📝 [POLYGON-MANAGER] Entered edit mode for zone ${zoneId}`);
        }
    }

    /**
     * Recalculate RED zones based on GREEN zones
     */
    recalculateRedZones() {
        // TODO: Implement intelligent RED zone calculation
        // This would analyze GREEN zones and create buffer/complement RED zones
        console.log("🔄 [POLYGON-MANAGER] Recalculating RED zones based on GREEN zones...");

        // For now, create simple buffer zones around GREEN zones
        const greenZones = Array.from(this.zones.green.values());

        // Clear existing auto-generated RED zones
        this.clearAutoGeneratedRedZones();

        greenZones.forEach((greenZone, index) => {
            try {
                // Create buffer around GREEN zone using Turf.js
                if (typeof turf !== 'undefined') {
                    const polygon = turf.polygon([greenZone.coordinates]);
                    const buffered = turf.buffer(polygon, this.config.bufferDistance, { units: 'meters' });

                    if (buffered && buffered.geometry) {
                        const redZone = {
                            id: `auto_red_${greenZone.id}`,
                            name: `Auto RED around ${greenZone.name}`,
                            coordinates: buffered.geometry.coordinates[0],
                            properties: {
                                autoGenerated: true,
                                sourceGreenZone: greenZone.id
                            }
                        };

                        this.addZone(redZone, 'red');
                    }
                }
            } catch (error) {
                console.error(`❌ [POLYGON-MANAGER] Error creating buffer for zone ${greenZone.id}:`, error);
            }
        });

        console.log("✅ [POLYGON-MANAGER] RED zones recalculated");
    }

    /**
     * Clear auto-generated RED zones
     */
    clearAutoGeneratedRedZones() {
        const redZones = Array.from(this.zones.red.entries());

        redZones.forEach(([zoneId, zone]) => {
            if (zone.properties && zone.properties.autoGenerated) {
                this.deleteZone(zoneId);
            }
        });
    }

    /**
     * Validate polygon against rules
     */
    validatePolygon(coordinates, type) {
        const errors = [];

        try {
            // Calculate area using Turf.js if available
            if (typeof turf !== 'undefined') {
                const polygon = turf.polygon([coordinates]);
                const area = turf.area(polygon);

                // Check area constraints
                if (area < this.config.validationRules.minZoneArea) {
                    errors.push(`Zone area too small (${area.toFixed(0)} m² < ${this.config.validationRules.minZoneArea} m²)`);
                }

                if (area > this.config.validationRules.maxZoneArea) {
                    errors.push(`Zone area too large (${area.toFixed(0)} m² > ${this.config.validationRules.maxZoneArea} m²)`);
                }

                // Check for self-intersection
                const kinks = turf.kinks(polygon);
                if (kinks.features.length > 0) {
                    errors.push('Polygon has self-intersections');
                }
            }

            // Check minimum vertices
            if (coordinates.length < 3) {
                errors.push('Polygon must have at least 3 vertices');
            }

        } catch (error) {
            errors.push(`Validation error: ${error.message}`);
        }

        return {
            valid: errors.length === 0,
            errors: errors
        };
    }

    /**
     * Calculate zone area
     */
    calculateZoneArea(zone) {
        try {
            if (typeof turf !== 'undefined') {
                const polygon = turf.polygon([zone.coordinates]);
                return turf.area(polygon);
            }
        } catch (error) {
            console.error(`❌ [POLYGON-MANAGER] Error calculating area for zone ${zone.id}:`, error);
        }
        return 0;
    }

    /**
     * Check if point is in any zone of specific type
     */
    isPointInZone(lat, lng, zoneType) {
        if (!this.zones[zoneType]) return false;

        const zones = Array.from(this.zones[zoneType].values());

        for (const zone of zones) {
            if (this.isPointInPolygon(lat, lng, zone.coordinates)) {
                return { inZone: true, zone: zone };
            }
        }

        return { inZone: false, zone: null };
    }

    /**
     * Check if point is inside polygon using Turf.js
     */
    isPointInPolygon(lat, lng, coordinates) {
        try {
            if (typeof turf !== 'undefined') {
                const point = turf.point([lng, lat]); // Note: Turf uses [lng, lat]
                const polygon = turf.polygon([coordinates.map(coord => [coord[1], coord[0]])]);
                return turf.booleanPointInPolygon(point, polygon);
            } else {
                // Fallback to simple ray casting algorithm
                return this.raycastPointInPolygon(lat, lng, coordinates);
            }
        } catch (error) {
            console.error(`❌ [POLYGON-MANAGER] Error checking point in polygon:`, error);
            return false;
        }
    }

    /**
     * Fallback ray casting algorithm for point-in-polygon
     */
    raycastPointInPolygon(lat, lng, coordinates) {
        let inside = false;

        for (let i = 0, j = coordinates.length - 1; i < coordinates.length; j = i++) {
            if (((coordinates[i][0] > lat) !== (coordinates[j][0] > lat)) &&
                (lng < (coordinates[j][1] - coordinates[i][1]) * (lat - coordinates[i][0]) / (coordinates[j][0] - coordinates[i][0]) + coordinates[i][1])) {
                inside = !inside;
            }
        }

        return inside;
    }

    /**
     * Get zone type for point (green/red/neutral)
     * BUSINESS LOGIC: RED = Fence area MINUS GREEN zones
     */
    getZoneTypeForPoint(lat, lng) {
        // 1. Check GREEN zones first (highest priority)
        const greenResult = this.isPointInZone(lat, lng, 'green');
        if (greenResult.inZone) {
            console.log(`🟢 [POLYGON-MANAGER] Point in GREEN zone: ${greenResult.zone?.name || 'Unnamed'}`);
            return { type: 'green', zone: greenResult.zone };
        }

        // 2. Check if inside fence perimeter using SSHR_ZONES API
        if (window.SSHR_ZONES && window.SSHR_ZONES.helpers && window.SSHR_ZONES.helpers.pointInFence) {
            const inFence = window.SSHR_ZONES.helpers.pointInFence(lat, lng);
            if (inFence) {
                console.log(`🔴 [POLYGON-MANAGER] Point in RED zone: inside fence but not in GREEN`);
                return { type: 'red', zone: window.SSHR_ZONES.fence };
            }
        }

        // 3. Check explicit RED zones (legacy support)
        const redResult = this.isPointInZone(lat, lng, 'red');
        if (redResult.inZone) {
            console.log(`🔴 [POLYGON-MANAGER] Point in explicit RED zone: ${redResult.zone?.name || 'Unnamed'}`);
            return { type: 'red', zone: redResult.zone };
        }

        // 4. Outside all zones = neutral
        console.log(`⚪ [POLYGON-MANAGER] Point outside all zones (neutral)`);
        return { type: 'neutral', zone: null };
    }

    /**
     * Switch between FIXED and FLOAT modes
     */
    switchMode(newMode) {
        if (newMode === this.mode) return;

        console.log(`🔄 [POLYGON-MANAGER] Switching from ${this.mode} to ${newMode} mode`);

        // Save current state if switching from FLOAT
        if (this.mode === 'FLOAT') {
            this.saveZonesToStorage();
            this.unregisterDrawingEventListeners();
        }

        const previousMode = this.mode;
        this.mode = newMode;

        // Clean up current zones and tools
        this.clearAllZones();
        this.removeDrawingTools();

        // Reinitialize for new mode
        this.setupDrawingTools();

        // Register drawing event listeners if switching TO FLOAT mode
        if (newMode === 'FLOAT') {
            this.registerDrawingEventListeners();
        }

        this.loadDefaultZones();

        // Trigger event
        this.triggerEvent('mode-changed', { mode: newMode, previousMode });

        console.log(`✅ [POLYGON-MANAGER] Switched to ${newMode} mode`);
    }

    /**
     * Clear all zones from map
     */
    clearAllZones() {
        this.editableLayers.clearLayers();

        // Remove all polygon layers from map (EXCEPT fence line) and clean up corner handles
        this.polygonLayers.forEach((layer, key) => {
            if (key !== 'fence' && this.map.hasLayer(layer)) {
                // Remove corner handles if they exist
                if (layer._cornerHandles) {
                    layer._cornerHandles.forEach(handle => {
                        if (this.map.hasLayer(handle)) {
                            this.map.removeLayer(handle);
                        }
                    });
                    delete layer._cornerHandles;
                }
                this.map.removeLayer(layer);
            }
        });

        // Clear polygon layers but keep fence reference
        const fenceLayer = this.polygonLayers.get('fence');
        this.polygonLayers.clear();
        if (fenceLayer) {
            this.polygonLayers.set('fence', fenceLayer);
        }
        this.zones.green.clear();
        this.zones.red.clear();
        this.zones.neutral.clear();
    }

    /**
     * Remove drawing tools - DISABLED
     */
    removeDrawingTools() {
        console.log("🚫 [POLYGON-MANAGER] Drawing tools removal disabled - Management zones functionality removed");
    }

    /**
     * Save zones to localStorage
     */
    saveZonesToStorage() {
        if (this.mode === 'FLOAT') {
            const zonesData = {
                green: Array.from(this.zones.green.values()),
                red: Array.from(this.zones.red.values()),
                timestamp: new Date().toISOString()
            };

            try {
                localStorage.setItem(this.storageKeys.zones, JSON.stringify(zonesData));
                console.log("💾 [POLYGON-MANAGER] Zones saved to storage");
            } catch (error) {
                console.error("❌ [POLYGON-MANAGER] Error saving zones to storage:", error);
            }

            if (!this._suspendLayoutTracking) {
                this.updateLayoutDraft('autosave', { storage: 'zones' });
            }
        }
    }

    /**
     * Load zones from localStorage
     */
    loadZonesFromStorage() {
        try {
            const stored = localStorage.getItem(this.storageKeys.zones);
            if (stored) {
                const zonesData = JSON.parse(stored);
                console.log("📁 [POLYGON-MANAGER] Loading zones from storage");
                return zonesData;
            }
        } catch (error) {
            console.error("❌ [POLYGON-MANAGER] Error loading zones from storage:", error);
        }
        return null;
    }

    /**
     * Load any persisted layout metadata from storage.
     */
    loadPersistedLayoutState() {
        if (typeof localStorage === 'undefined') {
            return;
        }

        try {
            const activeRaw = localStorage.getItem(this.storageKeys.active);
            if (activeRaw) {
                this.currentLayout = JSON.parse(activeRaw);
                this.activeLayoutId = this.currentLayout?.id || null;
                console.log(`📦 [POLYGON-MANAGER] Loaded active layout ${this.activeLayoutId || '(unknown)'}`);
            }

            const draftRaw = localStorage.getItem(this.storageKeys.draft);
            if (draftRaw) {
                const draftLayout = JSON.parse(draftRaw);
                if (draftLayout && typeof draftLayout === 'object') {
                    this.layoutDraft = draftLayout;
                }
            }

            const historyRaw = localStorage.getItem(this.storageKeys.history);
            if (historyRaw) {
                const history = JSON.parse(historyRaw);
                this.layoutHistory = Array.isArray(history) ? history : [];
            }
        } catch (error) {
            console.error("❌ [POLYGON-MANAGER] Failed to load persisted layout state:", error);
        }
    }

    /**
     * Prepare persisted zone data for hydration into runtime structures.
     */
    preparePersistedZone(zoneData = {}, type) {
        const ensureCoordinatesClosed = (coords) => {
            if (!Array.isArray(coords) || !coords.length) {
                return [];
            }
            if (Array.isArray(coords[0]) && typeof coords[0][0] !== 'number') {
                // Nested rings, ensure each ring closed
                return coords.map(ring => this.ensurePolygonClosed(ring));
            }
            return this.ensurePolygonClosed(coords);
        };

        const prepared = {
            ...zoneData,
            id: zoneData.id || this.generateZoneId(type),
            coordinates: ensureCoordinatesClosed(zoneData.coordinates || []),
            properties: zoneData.properties || {}
        };

        if (typeof prepared.createdAt === 'string') {
            prepared.createdAt = new Date(prepared.createdAt);
        }
        if (typeof prepared.modifiedAt === 'string') {
            prepared.modifiedAt = new Date(prepared.modifiedAt);
        }
        if (typeof prepared.confirmedAt === 'string') {
            prepared.confirmedAt = new Date(prepared.confirmedAt);
        }

        return prepared;
    }

    /**
     * Record that the layout changed whilst in FLOAT mode.
     */
    recordLayoutChange(reason, context = {}) {
        if (this.mode !== 'FLOAT') {
            return;
        }
        this.updateLayoutDraft(reason, context);
    }

    /**
     * Persist current draft layout snapshot.
     */
    updateLayoutDraft(reason = 'mutation', context = {}) {
        const snapshot = this.captureLayoutSnapshot({
            status: 'draft',
            reason,
            context,
            id: this.layoutDraft?.id
        });

        this.layoutDraft = snapshot;
        this.persistLayoutDraft();
        this.triggerEvent('layout-draft-updated', { layout: snapshot });
    }

    /**
     * Capture the current in-memory zones as a layout snapshot.
     */
    captureLayoutSnapshot(options = {}) {
        const timestamp = new Date().toISOString();
        const layoutId = options.id || this.layoutDraft?.id || this.generateLayoutId();
        const createdAt = options.createdAt || this.layoutDraft?.createdAt || timestamp;
        const greens = this.getZones('green').map(zone => this.serializeZoneForLayout(zone)).filter(Boolean);
        const reds = this.getZones('red').map(zone => this.serializeZoneForLayout(zone)).filter(Boolean);

        return {
            id: layoutId,
            mode: options.mode || this.mode,
            status: options.status || 'draft',
            createdAt,
            updatedAt: timestamp,
            confirmedAt: options.confirmedAt || null,
            confirmedBy: options.confirmedBy || null,
            confirmedCount: this.confirmedZones.size,
            pendingCount: this.pendingZones.size,
            limit: this.managementLimit ?? null,
            reason: options.reason || null,
            context: options.context || {},
            fence: this.getFenceGeometry(),
            greens,
            reds,
            metadata: {
                source: options.metadata?.source || 'polygon-manager',
                ...options.metadata
            }
        };
    }

    /**
     * Serialize zone to lightweight structure for layouts.
     */
    serializeZoneForLayout(zone) {
        if (!zone) return null;
        const coordinates = Array.isArray(zone.coordinates?.[0]) && typeof zone.coordinates[0][0] !== 'number'
            ? zone.coordinates.map(ring => this.ensurePolygonClosed(ring))
            : this.ensurePolygonClosed(zone.coordinates || []);
        return {
            id: zone.id,
            name: zone.name,
            type: zone.type,
            coordinates,
            properties: zone.properties || {},
            createdAt: zone.createdAt?.toISOString?.() || null,
            modifiedAt: zone.modifiedAt?.toISOString?.() || null,
            confirmedAt: zone.confirmedAt?.toISOString?.() || null,
            rotation: zone.rotation ?? null,
            template: zone.template || null,
            metadata: zone.metadata || {}
        };
    }

    /**
     * Persist layout draft to storage.
     */
    persistLayoutDraft() {
        if (typeof localStorage === 'undefined' || !this.layoutDraft) {
            return;
        }
        try {
            localStorage.setItem(this.storageKeys.draft, JSON.stringify(this.layoutDraft));
        } catch (error) {
            console.error("❌ [POLYGON-MANAGER] Failed to persist layout draft:", error);
        }
    }

    /**
     * Persist active layout snapshot.
     */
    persistActiveLayout(layout) {
        if (typeof localStorage === 'undefined' || !layout) {
            return;
        }
        try {
            localStorage.setItem(this.storageKeys.active, JSON.stringify(layout));
        } catch (error) {
            console.error("❌ [POLYGON-MANAGER] Failed to persist active layout:", error);
        }
    }

    /**
     * Persist layout history entries.
     */
    persistLayoutHistory() {
        if (typeof localStorage === 'undefined') {
            return;
        }
        try {
            localStorage.setItem(this.storageKeys.history, JSON.stringify(this.layoutHistory));
        } catch (error) {
            console.error("❌ [POLYGON-MANAGER] Failed to persist layout history:", error);
        }
    }

    /**
     * Clear draft persistence.
     */
    clearLayoutDraftStorage() {
        if (typeof localStorage === 'undefined') {
            return;
        }
        try {
            localStorage.removeItem(this.storageKeys.draft);
        } catch (error) {
            console.error("❌ [POLYGON-MANAGER] Failed to clear layout draft storage:", error);
        }
    }

    /**
     * Activate the current FLOAT layout snapshot as live session.
     */
    activateCurrentLayout(metadata = {}) {
        const { historyLimit, ...meta } = metadata || {};
        const layout = this.captureLayoutSnapshot({
            status: 'active',
            mode: 'FLOAT',
            confirmedBy: meta.confirmedBy || null,
            confirmedAt: new Date().toISOString(),
            metadata: meta
        });

        this.currentLayout = layout;
        this.activeLayoutId = layout.id;
        this.layoutDraft = null;

        this.persistActiveLayout(layout);
        this.clearLayoutDraftStorage();

        // Maintain short history (latest first)
        if (Array.isArray(this.layoutHistory)) {
            this.layoutHistory.unshift(layout);
            this.layoutHistory = this.layoutHistory.slice(0, historyLimit || 20);
        } else {
            this.layoutHistory = [layout];
        }
        this.persistLayoutHistory();

        this.triggerEvent('layout-activated', { layout });
        this.triggerEvent('layout-history-updated', { layouts: this.layoutHistory });
        return layout;
    }

    getActiveLayout() {
        return this.currentLayout;
    }

    getLayoutDraft() {
        return this.layoutDraft;
    }

    getLayoutHistory() {
        return Array.isArray(this.layoutHistory) ? [...this.layoutHistory] : [];
    }

    /**
     * Provide fence geometry for layout snapshot.
     */
    getFenceGeometry() {
        const fenceContainer = (typeof window !== 'undefined') ? window.SSHR_ZONES : null;
        const fence = fenceContainer && fenceContainer.fence;
        if (!fence || !fence.coordinates) {
            return null;
        }
        return {
            id: fence.id || 'FENCE',
            name: fence.name || 'Perimeter Fence',
            coordinates: this.ensurePolygonClosed(fence.coordinates || [])
        };
    }

    /**
     * Generate unique layout id.
     */
    generateLayoutId() {
        return `layout_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
    }

    /**
     * Export zones to JSON
     */
    exportZones() {
        const exportData = {
            mode: this.mode,
            zones: {
                green: Array.from(this.zones.green.values()),
                red: Array.from(this.zones.red.values())
            },
            config: this.config,
            exportedAt: new Date().toISOString()
        };

        const dataStr = JSON.stringify(exportData, null, 2);
        const dataBlob = new Blob([dataStr], { type: 'application/json' });
        const url = URL.createObjectURL(dataBlob);

        const link = document.createElement('a');
        link.href = url;
        link.download = `sshr_zones_${this.mode.toLowerCase()}_${new Date().toISOString().split('T')[0]}.json`;
        link.click();

        URL.revokeObjectURL(url);

        console.log("📤 [POLYGON-MANAGER] Zones exported");
    }

    /**
     * Import zones from JSON
     */
    importZones(jsonData) {
        try {
            const data = typeof jsonData === 'string' ? JSON.parse(jsonData) : jsonData;

            // Clear current zones
            this.clearAllZones();

            // Import zones
            if (data.zones) {
                this.addZones(data.zones.green || [], 'green');
                this.addZones(data.zones.red || [], 'red');
            }

            console.log("📥 [POLYGON-MANAGER] Zones imported successfully");

            // Save to storage if in FLOAT mode
            if (this.mode === 'FLOAT') {
                this.saveZonesToStorage();
            }

            return true;
        } catch (error) {
            console.error("❌ [POLYGON-MANAGER] Error importing zones:", error);
            return false;
        }
    }

    /**
     * Generate unique zone ID
     */
    generateZoneId(type) {
        return `${type}_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    }

    /**
     * Get all zones of specific type
     */
    getZones(type) {
        return Array.from(this.zones[type].values());
    }

    /**
     * Get zone statistics
     */
    getZoneStatistics() {
        return {
            mode: this.mode,
            counts: {
                green: this.zones.green.size,
                red: this.zones.red.size,
                neutral: this.zones.neutral.size
            },
            totalArea: {
                green: this.getTotalArea('green'),
                red: this.getTotalArea('red')
            }
        };
    }

    /**
     * Calculate total area for zone type
     */
    getTotalArea(type) {
        const zones = Array.from(this.zones[type].values());
        return zones.reduce((total, zone) => total + this.calculateZoneArea(zone), 0);
    }

    /**
     * Handle map click events
     */
    onMapClick(e) {
        // TODO: Implement click handling for zone information
        const zoneInfo = this.getZoneTypeForPoint(e.latlng.lat, e.latlng.lng);

        if (zoneInfo.type !== 'neutral') {
            console.log(`📍 [POLYGON-MANAGER] Clicked in ${zoneInfo.type.toUpperCase()} zone:`, zoneInfo.zone?.name);
        }
    }

    /**
     * Event system for notifications
     */
    triggerEvent(eventType, data) {
        console.log(`📡 [POLYGON-MANAGER] Event: ${eventType}`, data);

        // Dispatch custom event
        if (typeof window !== 'undefined') {
            window.dispatchEvent(new CustomEvent(`sshr-${eventType}`, { detail: data }));
        }
    }

    /**
     * Enable interactive shape drawing for variable zones.
     * User selects number of corners and then places template via single click.
     */
    enableShapeDrawing() {
        console.log("🔲 [POLYGON-MANAGER] Enabling shape drawing...");

        // Switch to FLOAT mode if not already
        if (this.mode !== 'FLOAT') {
            this.switchMode('FLOAT');
        }

        // Drawing tools disabled - Management zones functionality removed

        // Reset any previous drawing handlers and restore map interactions
        this.disableDrawing();

        // Activate template placement workflow
        this.drawingActive = true;
        this.cleanupTemplateListener();

        if (!this.map) {
            console.error("❌ [POLYGON-MANAGER] Map reference missing, cannot enable drawing");
            return;
        }

        // Disable map interactions so click is used for template placement
        this.map.dragging.disable();
        this.map.touchZoom.disable();
        this.map.doubleClickZoom.disable();
        this.map.scrollWheelZoom.disable();
        this.map.boxZoom.disable();
        this.map.keyboard.disable();

        // Update map cursor
        this.map.getContainer().style.cursor = 'crosshair';

        // Place template on next map click
        this._templateClickHandler = (e) => {
            this.handleTemplatePlacement(e.latlng);
        };

        this.map.once('click', this._templateClickHandler);
        console.log("🎯 [POLYGON-MANAGER] Awaiting click to place polygon template");
    }

    /**
     * Disable all drawing tools
     */
    disableDrawing() {
        this.drawingActive = false;
        this.cleanupTemplateListener();

        // Draw control disabled - Management zones functionality removed

        if (this.map) {
            // Re-enable map interactions
            this.map.dragging.enable();
            this.map.touchZoom.enable();
            this.map.doubleClickZoom.enable();
            this.map.scrollWheelZoom.enable();
            this.map.boxZoom.enable();
            this.map.keyboard.enable();

            // Reset map cursor
            this.map.getContainer().style.cursor = '';
        }

        console.log("🚫 [POLYGON-MANAGER] All drawing tools disabled, map interactions restored");
    }

    /**
     * Remove pending template listener if exists
     */
    cleanupTemplateListener() {
        if (this._templateClickHandler && this.map) {
            this.map.off('click', this._templateClickHandler);
        }
        this._templateClickHandler = null;
    }

    /**
     * Handle placement of polygon template after user click
     */
    handleTemplatePlacement(latlng) {
        if (!latlng) {
            console.warn("⚠️ [POLYGON-MANAGER] No coordinates provided for template placement");
            this.disableDrawing();
            return;
        }

        try {
            this.cleanupTemplateListener();

            if (this.managementActive && this.managementLimit && this.zones.green.size >= this.managementLimit) {
                alert(`Nelze vytvořit další zónu. Dosáhli jste limitu ${this.managementLimit} zón.`);
                return;
            }

            const corners = Math.max(3, parseInt(this.selectedShape, 10) || 4);
            const radius = this.templateRadiusMeters || this.config.templateRadiusMeters || 25;
            const coordinates = this.createRegularPolygonCoordinates(latlng, corners, radius);

            const validation = this.validatePolygon(coordinates, 'green');
            if (!validation.valid) {
                alert(`Vytvoření zóny selhalo: ${validation.errors.join(', ')}`);
                return;
            }

            const zone = this.addZone({
                name: `Variabilní zóna ${this.zones.green.size + 1}`,
                coordinates: coordinates,
                rotation: 0,
                template: {
                    corners,
                    radius
                }
            }, 'green');

            if (zone) {
                console.log(`🎯 [POLYGON-MANAGER] About to call onZoneDrawn for zone: ${zone.id}`);
                this.onZoneDrawn(zone);
                console.log(`✅ [POLYGON-MANAGER] Template zone ${zone.id} created with ${corners} corners`);
            } else {
                console.error("❌ [POLYGON-MANAGER] Failed to create template zone");
            }
        } finally {
            this.disableDrawing();
        }
    }

    /**
     * Generate regular polygon coordinates around center point
     */
    createRegularPolygonCoordinates(center, corners, radiusMeters) {
        if (!center) return [];

        const points = [];
        const lat = center.lat;
        const lng = center.lng;
        const latRadius = radiusMeters / 111320; // approx meters per degree latitude
        const lngRadius = radiusMeters / (111320 * Math.cos(lat * Math.PI / 180)); // adjust for longitude
        const angleStep = (2 * Math.PI) / corners;

        for (let i = 0; i < corners; i++) {
            const angle = angleStep * i;
            const pointLat = lat + latRadius * Math.cos(angle);
            const pointLng = lng + lngRadius * Math.sin(angle);
            points.push([pointLat, pointLng]);
        }

        // Close polygon by repeating first point
        if (points.length) {
            points.push([points[0][0], points[0][1]]);
        }

        return points;
    }

    /**
     * Enable rotation mode for a specific zone
     */
    enableRotationMode(zoneId) {
        const polygon = this.polygonLayers.get(zoneId);
        const zone = this.zones.green.get(zoneId) || this.zones.red.get(zoneId);

        if (!polygon || !zone) {
            console.warn(`⚠️ [POLYGON-MANAGER] Zone ${zoneId} not found for rotation`);
            return;
        }

        // Disable all other interactions
        this.disableDrawing();

        // Close any open popups
        this.map.closePopup();

        // Add rotation control
        this.addRotationControl(polygon, zone);

        console.log(`🔄 [POLYGON-MANAGER] Rotation mode enabled for zone ${zoneId}`);
    }

    /**
     * Add rotation control (visual wheel) to polygon
     */
    addRotationControl(polygon, zone) {
        const bounds = polygon.getBounds();
        const center = bounds.getCenter();

        // Create rotation control marker (wheel icon)
        const rotationIcon = L.divIcon({
            html: `
                <div style="
                    width: 40px;
                    height: 40px;
                    background: #007bff;
                    border-radius: 50%;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    color: white;
                    font-size: 18px;
                    border: 3px solid white;
                    box-shadow: 0 2px 8px rgba(0,0,0,0.3);
                    cursor: grab;
                ">
                    <i class="fas fa-sync-alt"></i>
                </div>
            `,
            className: 'rotation-control',
            iconSize: [40, 40],
            iconAnchor: [20, 20]
        });

        const rotationMarker = L.marker(center, {
            icon: rotationIcon,
            draggable: true
        }).addTo(this.map);

        // Store original coordinates for rotation calculation
        const originalCoords = [...zone.coordinates];
        const originalCenter = this.calculatePolygonCenter(originalCoords);

        // Handle rotation dragging
        let isDragging = false;
        let startAngle = 0;

        rotationMarker.on('dragstart', (e) => {
            isDragging = true;
            const mousePos = e.target.getLatLng();
            startAngle = this.calculateAngle(originalCenter, mousePos);
            polygon.setStyle({ ...this.config.styles.editing, dashArray: '5, 5' });
        });

        rotationMarker.on('drag', (e) => {
            if (!isDragging) return;

            const mousePos = e.target.getLatLng();
            const currentAngle = this.calculateAngle(originalCenter, mousePos);
            const rotationDelta = currentAngle - startAngle;

            // Rotate polygon coordinates
            const rotatedCoords = this.rotatePolygon(originalCoords, originalCenter, rotationDelta);

            // Update polygon visual
            polygon.setLatLngs(rotatedCoords);

            // Update zone data
            zone.coordinates = rotatedCoords;
            zone.rotation = (zone.rotation || 0) + rotationDelta;
        });

        rotationMarker.on('dragend', (e) => {
            isDragging = false;
            polygon.setStyle(this.config.styles[zone.type]);

            // Update popup content to show new rotation
            polygon.setPopupContent(this.createZonePopup(zone));

            // Remove rotation control
            this.map.removeLayer(rotationMarker);

            // Re-enable drawing
            this.enableShapeDrawing();

            console.log(`✅ [POLYGON-MANAGER] Zone ${zone.id} rotated to ${zone.rotation?.toFixed(1)}°`);

            if (this.mode === 'FLOAT' && !this._suspendLayoutTracking) {
                this.recordLayoutChange('zone-rotated', { zoneId: zone.id });
            }
        });

        // Add instruction popup
        const instructionPopup = L.popup({
            closeButton: false,
            autoClose: false,
            closeOnClick: false,
            className: 'rotation-instruction'
        })
        .setLatLng([center.lat + 0.001, center.lng])
        .setContent(`
            <div style="text-align: center; font-size: 12px;">
                <strong>🔄 Rotation Mode</strong><br>
                Drag the blue wheel to rotate zone<br>
                <small>Release to confirm</small>
            </div>
        `)
        .openOn(this.map);

        // Remove instruction after 3 seconds
        setTimeout(() => {
            this.map.closePopup(instructionPopup);
        }, 3000);
    }

    /**
     * Calculate center of polygon coordinates
     */
    calculatePolygonCenter(coordinates) {
        let lat = 0, lng = 0;

        for (const coord of coordinates) {
            lat += coord[0];
            lng += coord[1];
        }

        return {
            lat: lat / coordinates.length,
            lng: lng / coordinates.length
        };
    }

    /**
     * Calculate angle between center and point
     */
    calculateAngle(center, point) {
        return Math.atan2(point.lng - center.lng, point.lat - center.lat) * (180 / Math.PI);
    }

    /**
     * Rotate polygon coordinates around center point
     */
    rotatePolygon(coordinates, center, angleDegrees) {
        const angleRad = angleDegrees * (Math.PI / 180);
        const cos = Math.cos(angleRad);
        const sin = Math.sin(angleRad);

        return coordinates.map(coord => {
            // Translate to origin
            const x = coord[0] - center.lat;
            const y = coord[1] - center.lng;

            // Rotate
            const newX = x * cos - y * sin;
            const newY = x * sin + y * cos;

            // Translate back
            return [newX + center.lat, newY + center.lng];
        });
    }

    /**
     * Set selected shape for new polygons
     */
    setSelectedShape(corners) {
        this.selectedShape = corners;
        console.log(`🔺 [POLYGON-MANAGER] Selected shape set to ${corners} corners`);
    }

    /**
     * Enable reshape mode for a specific zone (corner drag handles)
     */
    enableReshapeMode(zoneId) {
        const polygon = this.polygonLayers.get(zoneId);
        const zone = this.zones.green.get(zoneId) || this.zones.red.get(zoneId);

        if (!polygon || !zone) {
            console.warn(`⚠️ [POLYGON-MANAGER] Zone ${zoneId} not found for reshape`);
            return;
        }

        // Set active reshape zone
        this.activeReshapeZoneId = zoneId;

        // Show reshape controls in sidebar
        const reshapeControls = document.getElementById('reshape-controls');
        if (reshapeControls) {
            reshapeControls.classList.remove('d-none');
        }

        // Disable all other interactions
        this.disableDrawing();

        // Close any open popups
        this.map.closePopup();

        // Add corner drag handles
        this.addCornerDragHandles(polygon, zone);

        console.log(`🔲 [POLYGON-MANAGER] Reshape mode enabled for zone ${zoneId}`);
    }

    /**
     * Add corner drag handles to polygon for precise reshaping
     */
    addCornerDragHandles(polygon, zone) {
        const coordinates = zone.coordinates;
        const cornerHandles = [];

        // Set editing style
        polygon.setStyle({ ...this.config.styles.editing, dashArray: '10, 5' });

        // Create drag handle for each corner (skip last point if it's duplicate of first)
        const uniqueCoords = this.getUniqueCoordinates(coordinates);

        uniqueCoords.forEach((coord, index) => {
            const handle = this.createCornerHandle(coord, index, polygon, zone, cornerHandles);
            cornerHandles.push(handle);
        });

        // Store handles for cleanup
        polygon._cornerHandles = cornerHandles;

        // Add draggable instruction popup
        const bounds = polygon.getBounds();
        const topLeft = bounds.getNorthWest();

        const instructionPopup = L.popup({
            closeButton: true,
            autoClose: false,
            closeOnClick: false,
            className: 'reshape-instruction draggable-popup'
        })
        .setLatLng([topLeft.lat + 0.002, topLeft.lng]) // Position away from zone
        .setContent(`
            <div style="text-align: center; font-size: 12px; cursor: move;" class="draggable-handle">
                <div style="background: #f8f9fa; padding: 4px; border-radius: 4px; margin-bottom: 8px; border: 1px solid #dee2e6;">
                    <strong>🔲 Reshape Mode</strong>
                    <small style="display: block; color: #6c757d;">Drag this box to move it</small>
                </div>
                <div>Drag corner handles to reshape zone</div>
                <small style="color: #6c757d;">Use sidebar controls to confirm/cancel</small>
            </div>
        `)
        .openOn(this.map);

        // Make popup draggable
        setTimeout(() => {
            const popupElement = instructionPopup.getElement();
            if (popupElement) {
                this.makePopupDraggable(popupElement, instructionPopup);
            }
        }, 100);

        // Store instruction popup for cleanup
        polygon._instructionPopup = instructionPopup;
    }

    /**
     * Create individual corner drag handle
     */
    createCornerHandle(coord, index, polygon, zone, handleArray) {
        // Create corner handle icon
        const handleIcon = L.divIcon({
            html: `
                <div style="
                    width: 16px;
                    height: 16px;
                    background: #fbbf24;
                    border: 2px solid white;
                    border-radius: 3px;
                    cursor: grab;
                    box-shadow: 0 2px 6px rgba(0,0,0,0.4);
                    display: flex;
                    align-items: center;
                    justify-content: center;
                " data-corner-index="${index}">
                    <div style="width: 6px; height: 6px; background: white; border-radius: 1px;"></div>
                </div>
            `,
            className: 'corner-handle',
            iconSize: [16, 16],
            iconAnchor: [8, 8]
        });

        const handle = L.marker([coord[0], coord[1]], {
            icon: handleIcon,
            draggable: true
        }).addTo(this.map);

        // Handle dragging
        handle.on('dragstart', (e) => {
            handle.getElement().style.cursor = 'grabbing';
            console.log(`🔲 [POLYGON-MANAGER] Started dragging corner ${index}`);
        });

        handle.on('drag', (e) => {
            const newPos = e.target.getLatLng();

            // Get unique coordinates for manipulation
            const uniqueCoords = this.getUniqueCoordinates(zone.coordinates);

            // Update the specific corner
            if (index < uniqueCoords.length) {
                uniqueCoords[index] = [newPos.lat, newPos.lng];
            }

            // Ensure polygon is properly closed for Leaflet
            const closedCoords = this.ensurePolygonClosed(uniqueCoords);

            // Update zone coordinates
            zone.coordinates = closedCoords;

            // Update polygon visual
            polygon.setLatLngs(closedCoords);
        });

        handle.on('dragend', (e) => {
            handle.getElement().style.cursor = 'grab';
            console.log(`✅ [POLYGON-MANAGER] Finished dragging corner ${index}`);
        });

        return handle;
    }

    /**
     * Confirm reshape operation
     */
    confirmReshape(zoneId) {
        const polygon = this.polygonLayers.get(zoneId);
        const zone = this.zones.green.get(zoneId) || this.zones.red.get(zoneId);

        if (!polygon || !zone) return;

        // Validate reshaped polygon
        const validation = this.validatePolygon(zone.coordinates, zone.type);
        if (!validation.valid) {
            alert(`Reshape failed: ${validation.errors.join(', ')}`);
            return;
        }

        // Clean up handles and instruction
        this.cleanupReshapeMode(polygon);

        // Hide reshape controls in sidebar
        const reshapeControls = document.getElementById('reshape-controls');
        if (reshapeControls) {
            reshapeControls.classList.add('d-none');
        }

        // Clear active reshape zone
        this.activeReshapeZoneId = null;

        // Restore normal style
        polygon.setStyle(this.config.styles[zone.type]);

        // Update popup content
        polygon.setPopupContent(this.createZonePopup(zone));

        // Re-enable drawing
        this.enableShapeDrawing();

        console.log(`✅ [POLYGON-MANAGER] Zone ${zoneId} reshaped successfully`);

        if (this.mode === 'FLOAT' && !this._suspendLayoutTracking) {
            this.recordLayoutChange('zone-reshaped', { zoneId });
        }
    }

    /**
     * Cancel reshape operation
     */
    cancelReshape(zoneId) {
        const polygon = this.polygonLayers.get(zoneId);
        const zone = this.zones.green.get(zoneId) || this.zones.red.get(zoneId);

        if (!polygon || !zone) return;

        // Restore original coordinates (would need to store them)
        // For now, just clean up
        this.cleanupReshapeMode(polygon);

        // Hide reshape controls in sidebar
        const reshapeControls = document.getElementById('reshape-controls');
        if (reshapeControls) {
            reshapeControls.classList.add('d-none');
        }

        // Clear active reshape zone
        this.activeReshapeZoneId = null;

        // Restore normal style
        polygon.setStyle(this.config.styles[zone.type]);

        // Re-enable drawing
        this.enableShapeDrawing();

        console.log(`🚫 [POLYGON-MANAGER] Zone ${zoneId} reshape cancelled`);
    }

    /**
     * Get unique coordinates (excluding duplicate closing point)
     */
    getUniqueCoordinates(coordinates) {
        if (!coordinates || coordinates.length === 0) return [];

        // Check if polygon is closed (first point = last point)
        const isClosed = coordinates.length > 1 &&
            coordinates[0][0] === coordinates[coordinates.length - 1][0] &&
            coordinates[0][1] === coordinates[coordinates.length - 1][1];

        return isClosed ? coordinates.slice(0, -1) : coordinates;
    }

    /**
     * Ensure polygon is properly closed for Leaflet rendering
     */
    ensurePolygonClosed(coordinates) {
        if (!coordinates || coordinates.length === 0) return coordinates;

        const firstPoint = coordinates[0];
        const lastPoint = coordinates[coordinates.length - 1];

        // Check if already closed
        if (firstPoint[0] === lastPoint[0] && firstPoint[1] === lastPoint[1]) {
            return coordinates; // Already closed
        }

        // Add closing point
        return [...coordinates, [firstPoint[0], firstPoint[1]]];
    }

    /**
     * Make popup draggable
     */
    makePopupDraggable(popupElement, popupInstance) {
        const handle = popupElement.querySelector('.draggable-handle');
        if (!handle) return;

        let isDragging = false;
        let startX, startY, startLat, startLng;

        handle.addEventListener('mousedown', (e) => {
            isDragging = true;
            startX = e.clientX;
            startY = e.clientY;
            const currentLatLng = popupInstance.getLatLng();
            startLat = currentLatLng.lat;
            startLng = currentLatLng.lng;

            handle.style.cursor = 'grabbing';
            e.preventDefault();
        });

        document.addEventListener('mousemove', (e) => {
            if (!isDragging) return;

            const deltaX = e.clientX - startX;
            const deltaY = e.clientY - startY;

            // Convert pixel movement to lat/lng movement
            const bounds = this.map.getBounds();
            const mapSize = this.map.getSize();

            const latPerPixel = (bounds.getNorth() - bounds.getSouth()) / mapSize.y;
            const lngPerPixel = (bounds.getEast() - bounds.getWest()) / mapSize.x;

            const newLat = startLat - (deltaY * latPerPixel);
            const newLng = startLng + (deltaX * lngPerPixel);

            popupInstance.setLatLng([newLat, newLng]);
        });

        document.addEventListener('mouseup', () => {
            if (isDragging) {
                isDragging = false;
                handle.style.cursor = 'move';
            }
        });
    }

    /**
     * Clean up reshape mode handles and popups
     */
    cleanupReshapeMode(polygon) {
        // Remove corner handles
        if (polygon._cornerHandles) {
            polygon._cornerHandles.forEach(handle => {
                this.map.removeLayer(handle);
            });
            delete polygon._cornerHandles;
        }

        // Remove instruction popup
        if (polygon._instructionPopup) {
            this.map.closePopup(polygon._instructionPopup);
            delete polygon._instructionPopup;
        }
    }

    /**
     * Add corner handles to polygon for editing
     */
    addCornerHandles(polygon, zone) {
        const coordinates = polygon.getLatLngs()[0];
        const handles = [];

        // For rectangles, we expect exactly 4 unique corners (or 5 with closing point)
        const uniqueCoordinates = [];
        coordinates.forEach((latlng, index) => {
            // Skip the last coordinate only if it's exactly the same as the first (closing coordinate)
            if (index === coordinates.length - 1 && coordinates.length > 4 &&
                Math.abs(coordinates[0].lat - latlng.lat) < 0.000001 &&
                Math.abs(coordinates[0].lng - latlng.lng) < 0.000001) {
                return; // Skip closing duplicate
            }
            uniqueCoordinates.push({latlng, originalIndex: index});
        });

        uniqueCoordinates.forEach(({latlng, originalIndex}) => {

            const handle = L.circleMarker([latlng.lat, latlng.lng], {
                radius: 6,
                fillColor: '#38bdf8',
                color: '#ffffff',
                weight: 2,
                opacity: 1,
                fillOpacity: 0.8,
                className: 'corner-handle'
            });

            // Make handle draggable
            handle.on('mousedown', (e) => {
                e.originalEvent.stopPropagation();
                this.startDragHandle(handle, polygon, zone, originalIndex);
            });

            handle.on('mouseover', () => {
                handle.setStyle({
                    radius: 8,
                    fillColor: '#0ea5e9'
                });
                this.map.getContainer().style.cursor = 'grab';
            });

            handle.on('mouseout', () => {
                handle.setStyle({
                    radius: 6,
                    fillColor: '#38bdf8'
                });
                this.map.getContainer().style.cursor = '';
            });

            handle.addTo(this.map);
            handles.push(handle);
        });

        // Store handles reference in polygon
        polygon._cornerHandles = handles;

        console.log(`🔵 [POLYGON-MANAGER] Created ${handles.length} corner handles for polygon with ${coordinates.length} coordinates`);
    }

    /**
     * Start dragging corner handle
     */
    startDragHandle(handle, polygon, zone, cornerIndex) {
        this.map.getContainer().style.cursor = 'grabbing';

        const onMouseMove = (e) => {
            const newLatLng = this.map.mouseEventToLatLng(e);
            handle.setLatLng(newLatLng);

            // Update polygon coordinates
            const coordinates = polygon.getLatLngs()[0];
            coordinates[cornerIndex] = newLatLng;

            // Close polygon if needed - update both first and last point if they're supposed to be the same
            if (coordinates.length > 4) {
                // If moving first corner, update last (closing) point
                if (cornerIndex === 0) {
                    coordinates[coordinates.length - 1] = newLatLng;
                }
                // If moving last corner before closing point, update closing point
                else if (cornerIndex === coordinates.length - 2) {
                    coordinates[coordinates.length - 1] = newLatLng;
                }
            }

            polygon.setLatLngs(coordinates);
        };

        const onMouseUp = () => {
            this.map.getContainer().style.cursor = '';
            document.removeEventListener('mousemove', onMouseMove);
            document.removeEventListener('mouseup', onMouseUp);

            // Update zone data
            const newCoordinates = polygon.getLatLngs()[0].map(latlng => [latlng.lat, latlng.lng]);
            zone.coordinates = this.ensurePolygonClosed(newCoordinates);

            // Update zone in storage
            this.zones[zone.type].set(zone.id, zone);

            console.log(`🔄 [POLYGON-MANAGER] Corner ${cornerIndex} updated for zone ${zone.id}`);
        };

        document.addEventListener('mousemove', onMouseMove);
        document.addEventListener('mouseup', onMouseUp);
    }

    /**
     * Handle zone drawing completion event
     */
    onZoneDrawn(zoneData) {
        console.log(`🔥 [POLYGON-MANAGER] onZoneDrawn called for zone: ${zoneData.id}, managementActive: ${this.managementActive}`);

        // Mark zone as pending confirmation (awaiting manual confirmation)
        if (this.pendingZones) {
            this.pendingZones.add(zoneData.id);
            console.log(`✅ [POLYGON-MANAGER] Zone ${zoneData.id} added to pendingZones, current size: ${this.pendingZones.size}`);
        } else {
            console.error(`❌ [POLYGON-MANAGER] pendingZones is null/undefined!`);
        }

        // Keep drawing enabled so user can adjust corner handles
        console.log(`🎨 [POLYGON-MANAGER] Zone ${zoneData.id} drawn, awaiting manual confirmation via button`);

        // Emit custom event for UI to handle
        const eventDetail = {
            zone: zoneData,
            count: this.zones.green.size,
            confirmed: this.confirmedZones.size,
            pending: this.pendingZones.size,
            limit: this.managementLimit,
            awaitingConfirmation: true
        };
        console.log('📡 [POLYGON-MANAGER] Emitting zone-drawn event with detail:', eventDetail);
        console.log('🔍 [POLYGON-MANAGER] Dispatching on window:', window);
        console.log('🔍 [POLYGON-MANAGER] Window has addEventListener:', typeof window.addEventListener);
        window.dispatchEvent(new CustomEvent('zone-drawn', {
            detail: eventDetail
        }));
        console.log('✅ [POLYGON-MANAGER] Event dispatched successfully');
    }

    /**
     * Confirm current pending zone manually via button
     */
    confirmCurrentPendingZone() {
        // Find the most recent pending zone
        const pendingZoneIds = Array.from(this.pendingZones);
        if (pendingZoneIds.length === 0) {
            console.warn('⚠️ [POLYGON-MANAGER] No pending zone to confirm');
            return false;
        }

        const zoneId = pendingZoneIds[pendingZoneIds.length - 1]; // Get most recent
        return this.confirmIndividualZone(zoneId);
    }

    /**
     * Remove corner handles utilities
     */
    removeCornerHandlesForPolygon(polygon) {
        if (!polygon || !polygon._cornerHandles) {
            return;
        }

        polygon._cornerHandles.forEach(handle => {
            if (this.map?.hasLayer(handle)) {
                this.map.removeLayer(handle);
            }
        });
        delete polygon._cornerHandles;
    }

    removeCornerHandlesForZone(zoneId) {
        const polygon = this.polygonLayers.get(zoneId);
        this.removeCornerHandlesForPolygon(polygon);
    }

    removeAllCornerHandles() {
        this.polygonLayers.forEach(polygon => this.removeCornerHandlesForPolygon(polygon));
    }

    /**
     * Confirm individual zone
     */
    confirmIndividualZone(zoneId) {
        if (this.pendingZones.has(zoneId)) {
            this.pendingZones.delete(zoneId);
            this.confirmedZones.add(zoneId);

            console.log(`✅ [POLYGON-MANAGER] Zone ${zoneId} individually confirmed (${this.confirmedZones.size}/${this.managementLimit})`);
            this.removeCornerHandlesForZone(zoneId);

            // Disable drawing after confirmation
            this.disableDrawing();

            // Check if we can continue drawing or if we're done
            if (this.confirmedZones.size < this.managementLimit) {
                // Continue drawing next zone
                setTimeout(() => {
                    this.enableShapeDrawing();
                    console.log(`🔲 [POLYGON-MANAGER] Continue drawing zone ${this.confirmedZones.size + 1}/${this.managementLimit}`);
                }, 500);
            } else {
                // All zones drawn, enable global confirmation
                console.log(`🎯 [POLYGON-MANAGER] All ${this.managementLimit} zones drawn, ready for global confirmation`);
            }

            // Emit confirmation event
            window.dispatchEvent(new CustomEvent('zone-confirmed', {
                detail: {
                    zoneId: zoneId,
                    confirmed: this.confirmedZones.size,
                    pending: this.pendingZones.size,
                    limit: this.managementLimit
                }
            }));

            if (this.mode === 'FLOAT' && !this._suspendLayoutTracking) {
                this.recordLayoutChange('zone-confirmed', { zoneId });
            }

            return true;
        }
        return false;
    }

    /**
     * Delete a zone
     */
    deleteZone(zoneId) {
        // Find zone in all types
        for (const [type, zones] of Object.entries(this.zones)) {
            if (zones.has(zoneId)) {
                const polygon = this.polygonLayers.get(zoneId);
                if (polygon) {
                    // Remove corner handles
                    this.removeCornerHandlesForPolygon(polygon);

                    // Remove polygon
                    this.map.removeLayer(polygon);
                    this.polygonLayers.delete(zoneId);
                }

                // Ensure zone metadata is removed from confirmation tracking
                this.pendingZones.delete(zoneId);
                this.confirmedZones.delete(zoneId);

                zones.delete(zoneId);
                console.log(`🗑️ [POLYGON-MANAGER] Deleted zone ${zoneId}`);

                if (this.mode === 'FLOAT' && !this._suspendLayoutTracking) {
                    this.recordLayoutChange('zone-deleted', { zoneId, zoneType: zone.type });
                }
                break;
            }
        }
    }

    /**
     * Cleanup method
     */
    destroy() {
        console.log("🧹 [POLYGON-MANAGER] Cleaning up...");

        // Clean up any active reshape modes
        this.polygonLayers.forEach(polygon => {
            if (polygon._cornerHandles || polygon._instructionPopup) {
                this.cleanupReshapeMode(polygon);
            }
        });

        this.unregisterDrawingEventListeners();
        this.removeDrawingTools();
        this.clearAllZones();

        if (this.editableLayers) {
            this.map.removeLayer(this.editableLayers);
        }
    }
}

// Export for use in main renderer
if (typeof window !== 'undefined') {
    window.SSHRPolygonManager = SSHRPolygonManager;
}

console.log("✅ [POLYGON-MANAGER] SSHRPolygonManager class loaded successfully");
        this.confirmedZones = this.confirmedZones || new Set();
        this.pendingZones = this.pendingZones || new Set();
