/**
 * ReportingUI - UI komponent pro generování reportů návštěv
 * Integruje IncidentRegistry, GroupInteractionTracker a SSHRVisitService
 */

class ReportingUI {
  constructor() {
    this.isVisible = false;
    this.selectedPersonId = null;
    this.currentReport = null;

    this.init();
    console.log('📊 [REPORTING-UI] Initialized');
  }

  init() {
    this.bindEvents();
    this.updatePersonList();
  }

  bindEvents() {
    // Toggle reporting section
    const toggleBtn = document.getElementById('toggle-reporting-btn');
    if (toggleBtn) {
      toggleBtn.addEventListener('click', () => {
        this.toggleReportingSection();
      });
    }

    // Person selection
    const personSelect = document.getElementById('reporting-person-select');
    if (personSelect) {
      personSelect.addEventListener('change', (e) => {
        this.selectedPersonId = e.target.value;
        this.updateButtonStates();
      });
    }

    // Report type buttons
    document.getElementById('report-incidents')?.addEventListener('click', () => {
      this.generateIncidentReport();
    });

    document.getElementById('report-interactions')?.addEventListener('click', () => {
      this.generateInteractionReport();
    });

    document.getElementById('report-movement')?.addEventListener('click', () => {
      this.generateMovementReport();
    });

    document.getElementById('report-full')?.addEventListener('click', () => {
      this.generateFullReport();
    });

    // Export buttons
    document.getElementById('export-json')?.addEventListener('click', () => {
      this.exportJSON();
    });

    document.getElementById('export-mqtt')?.addEventListener('click', () => {
      this.exportToNAS();
    });
  }

  toggleReportingSection() {
    const section = document.getElementById('reporting-section');
    const toggleBtn = document.getElementById('toggle-reporting-btn');

    if (!section) return;

    this.isVisible = !this.isVisible;

    if (this.isVisible) {
      section.style.display = 'block';
      toggleBtn.innerHTML = '<i class="fas fa-chart-line me-2"></i>Skrýt Reporting';
      toggleBtn.classList.remove('btn-outline-primary');
      toggleBtn.classList.add('btn-primary');

      this.updatePersonList();
    } else {
      section.style.display = 'none';
      toggleBtn.innerHTML = '<i class="fas fa-chart-line me-2"></i>Reporting & Analýza';
      toggleBtn.classList.remove('btn-primary');
      toggleBtn.classList.add('btn-outline-primary');
    }
  }

  updatePersonList() {
    const personSelect = document.getElementById('reporting-person-select');
    if (!personSelect) return;

    // Vyčistit existující možnosti
    personSelect.innerHTML = '<option value="">-- Vyberte osobu --</option>';

    // Získat osoby s daty pro reporting
    const personsWithData = this.getPersonsWithReportData();

    personsWithData.forEach(person => {
      const option = document.createElement('option');
      option.value = person.personId;
      option.textContent = `Osoba ${person.personId} (${person.datasetName || 'N/A'})`;
      personSelect.appendChild(option);
    });

    console.log(`📊 [REPORTING-UI] Updated person list: ${personsWithData.length} persons`);
  }

  getPersonsWithReportData() {
    const personsWithData = [];

    // Získat osoby z různých zdrojů
    const sources = [
      // IncidentRegistry
      window.SSHR?.incidentRegistry?.getAllPersonsWithIncidents() || [],
      // GroupInteractionTracker
      window.SSHR?.groupInteractionTracker?.getAllPersonsWithInteractions() || [],
      // PersonTracker
      this.getPersonsFromPersonTracker()
    ];

    const personMap = new Map();

    sources.forEach(source => {
      source.forEach(person => {
        const personId = person.personId;
        if (!personMap.has(personId)) {
          personMap.set(personId, {
            personId,
            datasetName: person.datasetName || this.getDatasetNameFromPersonTracker(personId),
            hasIncidents: false,
            hasInteractions: false,
            hasMovement: false
          });
        }

        const personData = personMap.get(personId);
        if (person.summary?.totalIncidents > 0) personData.hasIncidents = true;
        if (person.summary?.totalInteractions > 0) personData.hasInteractions = true;
        personData.hasMovement = true; // Pokud je v PersonTracker, má movement data
      });
    });

    return Array.from(personMap.values());
  }

  getPersonsFromPersonTracker() {
    if (!window.personTracker?.persons) return [];

    const persons = [];
    window.personTracker.persons.forEach((person, personId) => {
      persons.push({
        personId,
        datasetName: person.datasetName || person.metadata?.dataset
      });
    });

    return persons;
  }

  getDatasetNameFromPersonTracker(personId) {
    if (!window.personTracker?.persons) return null;

    const person = window.personTracker.persons.get(personId);
    return person?.datasetName || person?.metadata?.dataset || null;
  }

  updateButtonStates() {
    const hasSelection = !!this.selectedPersonId;

    ['report-incidents', 'report-interactions', 'report-movement', 'report-full'].forEach(btnId => {
      const btn = document.getElementById(btnId);
      if (btn) {
        btn.disabled = !hasSelection;
      }
    });
  }

  showLoading(show = true) {
    const statusEl = document.getElementById('report-status');
    const exportEl = document.getElementById('export-options');

    if (statusEl) {
      statusEl.style.display = show ? 'block' : 'none';
    }

    if (exportEl) {
      exportEl.style.display = show ? 'none' : (this.currentReport ? 'block' : 'none');
    }
  }

  async generateIncidentReport() {
    if (!this.selectedPersonId) return;

    this.showLoading(true);

    try {
      const personId = this.selectedPersonId;
      const incidentData = window.SSHR?.incidentRegistry?.getPersonSummary(personId);

      if (!incidentData) {
        throw new Error('Incident data not available');
      }

      this.currentReport = {
        type: 'incidents',
        personId,
        timestamp: new Date().toISOString(),
        data: {
          summary: {
            totalIncidents: incidentData.totalIncidents,
            completedIncidents: incidentData.completedIncidents,
            totalRedTime: incidentData.totalRedTimeSeconds,
            maxDistance: incidentData.maxDistanceMeters
          },
          incidents: incidentData.incidents.map(incident => ({
            id: incident.id,
            startTime: incident.startTime,
            endTime: incident.endTime,
            duration: incident.duration,
            startGPS: incident.startGPS,
            endGPS: incident.endGPS,
            maxDistance: incident.maxDistance,
            movementTypeAtStart: incident.movementTypeAtStart,
            movementTypeAtReturn: incident.movementTypeAtReturn,
            entryAnchor: incident.entryAnchor,
            exitAnchor: incident.exitAnchor,
            zoneInfo: incident.zoneInfo
          }))
        }
      };

      console.log('📊 [REPORTING-UI] Incident report generated:', this.currentReport);
      this.showReportPreview('Incident Report', incidentData.totalIncidents + ' incidentů');

    } catch (error) {
      console.error('❌ [REPORTING-UI] Failed to generate incident report:', error);
      this.showError('Chyba při generování incident reportu');
    } finally {
      this.showLoading(false);
    }
  }

  async generateInteractionReport() {
    if (!this.selectedPersonId) return;

    this.showLoading(true);

    try {
      const personId = this.selectedPersonId;
      const interactionData = window.SSHR?.groupInteractionTracker?.getPersonInteractionSummary(personId);

      if (!interactionData) {
        throw new Error('Interaction data not available');
      }

      this.currentReport = {
        type: 'interactions',
        personId,
        timestamp: new Date().toISOString(),
        data: {
          summary: {
            totalInteractions: interactionData.totalInteractions,
            totalInteractionTime: interactionData.totalInteractionTime,
            uniquePeople: interactionData.uniquePeople,
            averageGroupSize: interactionData.averageGroupSize,
            longestInteraction: interactionData.longestInteraction
          },
          interactions: interactionData.interactions.map(interaction => ({
            groupId: interaction.groupId,
            startTime: interaction.startTime,
            endTime: interaction.endTime,
            duration: interaction.duration,
            members: interaction.members,
            otherMembers: interaction.otherMembers,
            anchorContext: interaction.anchorContext
          }))
        }
      };

      console.log('📊 [REPORTING-UI] Interaction report generated:', this.currentReport);
      this.showReportPreview('Interaction Report', interactionData.totalInteractions + ' interakcí');

    } catch (error) {
      console.error('❌ [REPORTING-UI] Failed to generate interaction report:', error);
      this.showError('Chyba při generování interaction reportu');
    } finally {
      this.showLoading(false);
    }
  }

  async generateMovementReport() {
    if (!this.selectedPersonId) return;

    this.showLoading(true);

    try {
      const personId = this.selectedPersonId;
      const datasetName = this.getDatasetNameFromPersonTracker(personId);

      // Získat movement data z SSHRVisitService
      let movementData = null;
      if (window.SSHRVisitService && datasetName) {
        // Pokud existuje aktivní visit
        const activeVisit = window.SSHRVisitService.activeVisits?.[datasetName];
        if (activeVisit) {
          movementData = {
            movements: activeVisit.movements || [],
            startTime: activeVisit.startTime,
            endTime: activeVisit.endTime
          };
        }
      }

      // Fallback - získat data z PersonTracker
      if (!movementData) {
        const person = window.personTracker?.persons.get(personId);
        if (person) {
          movementData = {
            movements: this.extractMovementFromPersonTracker(person),
            startTime: person.metadata?.firstSeen,
            endTime: person.metadata?.lastUpdate
          };
        }
      }

      if (!movementData || !movementData.movements.length) {
        throw new Error('Movement data not available');
      }

      this.currentReport = {
        type: 'movement',
        personId,
        datasetName,
        timestamp: new Date().toISOString(),
        data: movementData
      };

      console.log('📊 [REPORTING-UI] Movement report generated:', this.currentReport);
      this.showReportPreview('Movement Report', movementData.movements.length + ' pohybů');

    } catch (error) {
      console.error('❌ [REPORTING-UI] Failed to generate movement report:', error);
      this.showError('Chyba při generování movement reportu');
    } finally {
      this.showLoading(false);
    }
  }

  async generateFullReport() {
    if (!this.selectedPersonId) return;

    this.showLoading(true);

    try {
      // Generovat všechny typy reportů
      await this.generateIncidentReport();
      const incidentReport = this.currentReport;

      await this.generateInteractionReport();
      const interactionReport = this.currentReport;

      await this.generateMovementReport();
      const movementReport = this.currentReport;

      // Kombinovat do úplného reportu
      this.currentReport = {
        type: 'full',
        personId: this.selectedPersonId,
        timestamp: new Date().toISOString(),
        data: {
          incidents: incidentReport?.data || null,
          interactions: interactionReport?.data || null,
          movement: movementReport?.data || null,
          summary: {
            reportGeneratedAt: new Date().toISOString(),
            datasetName: this.getDatasetNameFromPersonTracker(this.selectedPersonId)
          }
        }
      };

      console.log('📊 [REPORTING-UI] Full report generated:', this.currentReport);
      this.showReportPreview('Kompletní Report', 'Všechna dostupná data');

    } catch (error) {
      console.error('❌ [REPORTING-UI] Failed to generate full report:', error);
      this.showError('Chyba při generování kompletního reportu');
    } finally {
      this.showLoading(false);
    }
  }

  extractMovementFromPersonTracker(person) {
    const movements = [];

    // Použít movement history pokud existuje
    if (window.personTracker?.movementHistory?.has(person.id)) {
      const history = window.personTracker.movementHistory.get(person.id);
      history.forEach(point => {
        movements.push({
          timestamp: point.timestamp,
          lat: point.lat || point.position?.[0],
          lng: point.lng || point.position?.[1],
          speed: point.speed || 0,
          movementType: point.movementType || 'unknown',
          source: 'PersonTracker'
        });
      });
    }

    return movements;
  }

  showReportPreview(title, summary) {
    // Zobrazit preview v status oblasti
    const statusEl = document.getElementById('report-status');
    if (statusEl) {
      statusEl.innerHTML = `
        <div class="text-success">
          <i class="fas fa-check-circle me-2"></i>
          <strong>${title}</strong><br>
          <small class="text-light">${summary}</small>
        </div>
      `;
    }
  }

  showError(message) {
    const statusEl = document.getElementById('report-status');
    if (statusEl) {
      statusEl.innerHTML = `
        <div class="text-danger">
          <i class="fas fa-exclamation-triangle me-2"></i>
          <small>${message}</small>
        </div>
      `;
    }
  }

  exportJSON() {
    if (!this.currentReport) {
      this.showError('Žádný report k exportu');
      return;
    }

    try {
      const jsonStr = JSON.stringify(this.currentReport, null, 2);
      const blob = new Blob([jsonStr], { type: 'application/json' });
      const url = URL.createObjectURL(blob);

      const a = document.createElement('a');
      a.href = url;
      a.download = `sshr-report-${this.currentReport.personId}-${this.currentReport.type}-${new Date().toISOString().slice(0, 10)}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      console.log('📊 [REPORTING-UI] JSON exported successfully');

    } catch (error) {
      console.error('❌ [REPORTING-UI] JSON export failed:', error);
      this.showError('Chyba při exportu JSON');
    }
  }

  async exportToNAS() {
    if (!this.currentReport) {
      this.showError('Žádný report k odeslání');
      return;
    }

    try {
      this.showLoading(true);

      // Použít SSHR MQTT klient
      if (window.SSHR?.mqttClient) {
        const success = await window.SSHR.mqttClient.publishPersonReport(this.currentReport);

        if (success) {
          this.showReportPreview('Odesláno na NAS', 'Report úspěšně odeslán');
          console.log('📊 [REPORTING-UI] Report sent to NAS via MQTT');
        } else {
          throw new Error('MQTT publish failed');
        }

      } else {
        throw new Error('MQTT client not available');
      }

    } catch (error) {
      console.error('❌ [REPORTING-UI] NAS export failed:', error);
      this.showError('Chyba při odesílání na NAS');
    } finally {
      this.showLoading(false);
    }
  }

  formatReportForNAS(report) {
    // Formátovat podle NAS requirements
    return {
      messageType: 'SSHR_PERSON_REPORT',
      timestamp: report.timestamp,
      personId: report.personId,
      reportType: report.type,
      facility: 'SSHR_Bohuslavice',
      data: report.data
    };
  }
}

// Globální instance
window.SSHR = window.SSHR || {};

// Inicializovat po načtení DOM
document.addEventListener('DOMContentLoaded', () => {
  window.SSHR.reportingUI = new ReportingUI();
});

console.log('📊 [REPORTING-UI] Module loaded');
