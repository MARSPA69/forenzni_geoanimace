/**
 * SSHR Visit Service - Persistent Visit Logs & Reporting
 * =====================================================
 *
 * Robust visit logging system with backend readiness for MQTT/REST integration.
 * Features: JSON persistence, monthly aggregations, visitor analytics.
 */

(function() {
  'use strict';

  // Configuration
  const CONFIG = {
    storage: {
      prefix: 'SSHR_visits_',
      logPrefix: 'SSHR_visitLog_',
      aggregatePrefix: 'SSHR_monthly_'
    },
    backend: {
      mqttTopics: {
        visitStart: 'sshr/visit/start',
        visitStop: 'sshr/visit/stop',
        incidentEval: 'sshr/incident/eval'
      },
      restEndpoints: {
        visits: '/api/sshr/visits',
        incidents: '/api/sshr/incidents',
        reports: '/api/sshr/reports'
      }
    },
    analytics: {
      riskThresholds: {
        incidents: 3,          // 3+ incidents = risky
        infraProximity: 50,    // within 50m of INFRA
        maxDuration: 7200      // 2+ hours = long visit
      }
    }
  };

  class SSHRVisitService {
    constructor() {
      this.activeVisits = new Map(); // cardId -> visitData
      this.visitQueue = []; // Queue for backend sync
      this.mqttClient = null;
      this.restClient = null;

      console.log('📊 [VISIT-SERVICE] SSHR Visit Service initialized');
    }

    /**
     * Start a new visit (ENTRY)
     */
    startVisit(visitorData) {
      const visitId = this.generateVisitId();
      const startTime = new Date();

      const visit = {
        visitId,
        cardId: visitorData.cardId,
        datasetName: visitorData.datasetName,
        panelId: visitorData.panelId,
        type: visitorData.type,

        // Visitor details
        person: visitorData.person || null,
        truck: visitorData.truck || null,

        // Timestamps
        startTime: startTime.toISOString(),
        startTimestamp: startTime.getTime(),
        endTime: null,
        endTimestamp: null,

        // Entry details
        entryTime: visitorData.entryTime,
        recordedBy: visitorData.recordedBy,

        // Tracking data
        incidents: [],
        movements: [],
        zones: [],
        anchors: [],

        // Analytics
        totalDuration: 0,
        maxDistance: 0,
        infraProximity: false,
        riskLevel: 'normal'
      };

      this.activeVisits.set(visitorData.cardId, visit);

      // Persist immediately
      this.persistVisit(visit);

      // Backend publish
      this.publishVisitStart(visit);

      console.log(`✅ [VISIT-SERVICE] Visit started: ${visitId} for card ${visitorData.cardId}`);

      return visitId;
    }

    /**
     * End a visit (EXIT)
     */
    endVisit(cardId, exitData) {
      const visit = this.activeVisits.get(cardId);
      if (!visit) {
        console.warn(`❌ [VISIT-SERVICE] Cannot end visit: card ${cardId} not found`);
        return null;
      }

      const endTime = new Date();
      visit.endTime = endTime.toISOString();
      visit.endTimestamp = endTime.getTime();
      visit.totalDuration = visit.endTimestamp - visit.startTimestamp;
      visit.exitTime = exitData?.exitTime;
      visit.exitRecordedBy = exitData?.recordedBy;

      // Calculate analytics
      this.calculateVisitAnalytics(visit);

      // Final persistence
      this.persistVisit(visit);

      // Backend publish
      this.publishVisitEnd(visit);

      // Monthly aggregation
      this.updateMonthlyStats(visit);

      // Remove from active visits
      this.activeVisits.delete(cardId);

      console.log(`✅ [VISIT-SERVICE] Visit ended: ${visit.visitId}, duration: ${visit.totalDuration}ms`);

      return visit;
    }

    /**
     * Record incident for active visit
     */
    recordIncident(datasetName, incidentData) {
      const visit = this.findVisitByDataset(datasetName);
      if (!visit) {
        return;
      }

      const incident = {
        ...incidentData,
        timestamp: new Date().toISOString(),
        visitId: visit.visitId
      };

      visit.incidents.push(incident);

      // Real-time analytics update
      this.updateVisitRiskLevel(visit);

      // Backend publish
      this.publishIncident(visit, incident);

      console.log(`📝 [VISIT-SERVICE] Incident recorded for visit ${visit.visitId}: ${incidentData.type}`);
    }

    /**
     * Record movement/position update
     */
    recordMovement(datasetName, movementData) {
      const visit = this.findVisitByDataset(datasetName);
      if (!visit || !movementData) {
        return;
      }

      const timestamp = movementData.timestamp
        ? new Date(movementData.timestamp).toISOString()
        : new Date().toISOString();

      const movement = {
        timestamp,
        gps: movementData.gps || { lat: null, lng: null },
        zone: movementData.zone || null,
        anchor: movementData.anchor || null,
        anchorDistance: movementData.anchorDistance ?? null,
        speed: Number.isFinite(movementData.speed) ? movementData.speed : 0,
        distance: Number.isFinite(movementData.distance) ? movementData.distance : 0,
        movementType: movementData.movementType || null,
        movementStatus: movementData.movementStatus || null,
        infraElement: movementData.infraElement || null,
        infraDistance: movementData.infraDistance ?? null,
        groupContext: movementData.groupContext || null,
        visitId: visit.visitId
      };

      visit.movements.push(movement);

      // Update zones and anchors tracking
      if (movementData.zone && !visit.zones.includes(movementData.zone)) {
        visit.zones.push(movementData.zone);
      }

      if (movementData.anchor && !visit.anchors.includes(movementData.anchor)) {
        visit.anchors.push(movementData.anchor);
      }

      // Update max distance
      if (Number.isFinite(movement.distance) && movement.distance > visit.maxDistance) {
        visit.maxDistance = movement.distance;
      }

      // Check INFRA proximity
      if (
        Number.isFinite(movementData.infraDistance) &&
        movementData.infraDistance <= CONFIG.analytics.riskThresholds.infraProximity
      ) {
        visit.infraProximity = true;
        this.updateVisitRiskLevel(visit);
      }
    }

    /**
     * Get visit statistics
     */
    getVisitStats() {
      const today = new Date().toISOString().split('T')[0];
      const todayVisits = this.getTodayVisits();

      return {
        active: this.activeVisits.size,
        todayTotal: todayVisits.length,
        todayIncidents: todayVisits.reduce((sum, v) => sum + v.incidents.length, 0),
        highRisk: todayVisits.filter(v => v.riskLevel === 'high').length,
        avgDuration: this.calculateAverageDuration(todayVisits)
      };
    }

    /**
     * Get monthly analytics for forensic analysis
     */
    getMonthlyAnalytics(year, month) {
      const monthKey = `${year}-${String(month).padStart(2, '0')}`;
      const storageKey = CONFIG.storage.aggregatePrefix + monthKey;

      try {
        const data = localStorage.getItem(storageKey);
        return data ? JSON.parse(data) : null;
      } catch (error) {
        console.error('❌ [VISIT-SERVICE] Error loading monthly analytics:', error);
        return null;
      }
    }

    /**
     * Export visit data for forensic datasets
     */
    exportForensicDataset(startDate, endDate) {
      const visits = this.getVisitsByDateRange(startDate, endDate);
      const riskyVisits = visits.filter(v => v.riskLevel === 'high' || v.incidents.length >= CONFIG.analytics.riskThresholds.incidents);

      const dataset = {
        metadata: {
          generatedAt: new Date().toISOString(),
          dateRange: { startDate, endDate },
          totalVisits: visits.length,
          riskyVisits: riskyVisits.length
        },
        visits: visits.map(v => ({
          visitId: v.visitId,
          person: v.person,
          startTime: v.startTime,
          endTime: v.endTime,
          duration: v.totalDuration,
          incidents: v.incidents,
          zones: v.zones,
          riskLevel: v.riskLevel,
          movements: v.movements.length > 0 ? [v.movements[0], v.movements[v.movements.length - 1]] : []
        })),
        analytics: {
          riskFactors: this.analyzeRiskFactors(riskyVisits),
          patterns: this.detectPatterns(visits),
          recommendations: this.generateRecommendations(visits)
        }
      };

      return dataset;
    }

    // ========== PRIVATE METHODS ==========

    generateVisitId() {
      return `visit_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    }

    findVisitByDataset(datasetName) {
      for (const visit of this.activeVisits.values()) {
        if (visit.datasetName === datasetName) {
          return visit;
        }
      }
      return null;
    }

    persistVisit(visit) {
      const dateKey = visit.startTime.split('T')[0];
      const storageKey = CONFIG.storage.logPrefix + dateKey;

      try {
        const existing = JSON.parse(localStorage.getItem(storageKey) || '[]');
        const index = existing.findIndex(v => v.visitId === visit.visitId);

        if (index >= 0) {
          existing[index] = visit;
        } else {
          existing.push(visit);
        }

        localStorage.setItem(storageKey, JSON.stringify(existing));
      } catch (error) {
        console.error('❌ [VISIT-SERVICE] Error persisting visit:', error);
      }
    }

    calculateVisitAnalytics(visit) {
      let riskScore = 0;

      // Incident risk
      if (visit.incidents.length >= CONFIG.analytics.riskThresholds.incidents) {
        riskScore += 3;
      } else if (visit.incidents.length > 0) {
        riskScore += 1;
      }

      // Duration risk
      if (visit.totalDuration > CONFIG.analytics.riskThresholds.maxDuration * 1000) {
        riskScore += 2;
      }

      // INFRA proximity risk
      if (visit.infraProximity) {
        riskScore += 2;
      }

      // Zone variety risk (too many zones = suspicious)
      if (visit.zones.length > 5) {
        riskScore += 1;
      }

      visit.riskLevel = riskScore >= 4 ? 'high' : riskScore >= 2 ? 'medium' : 'normal';
    }

    updateVisitRiskLevel(visit) {
      this.calculateVisitAnalytics(visit);
    }

    updateMonthlyStats(visit) {
      const month = visit.startTime.substr(0, 7); // YYYY-MM
      const storageKey = CONFIG.storage.aggregatePrefix + month;

      try {
        const stats = JSON.parse(localStorage.getItem(storageKey) || '{}');

        stats.totalVisits = (stats.totalVisits || 0) + 1;
        stats.totalIncidents = (stats.totalIncidents || 0) + visit.incidents.length;
        stats.totalDuration = (stats.totalDuration || 0) + visit.totalDuration;
        stats.riskLevels = stats.riskLevels || { normal: 0, medium: 0, high: 0 };
        stats.riskLevels[visit.riskLevel]++;

        // Track risky visitors
        if (visit.riskLevel === 'high') {
          stats.riskyVisitors = stats.riskyVisitors || [];
          const visitorKey = visit.person ? `${visit.person.firstName} ${visit.person.lastName}` : visit.truck?.driverName;
          if (visitorKey && !stats.riskyVisitors.includes(visitorKey)) {
            stats.riskyVisitors.push(visitorKey);
          }
        }

        localStorage.setItem(storageKey, JSON.stringify(stats));
      } catch (error) {
        console.error('❌ [VISIT-SERVICE] Error updating monthly stats:', error);
      }
    }

    getTodayVisits() {
      const today = new Date().toISOString().split('T')[0];
      const storageKey = CONFIG.storage.logPrefix + today;

      try {
        const data = localStorage.getItem(storageKey);
        return data ? JSON.parse(data) : [];
      } catch (error) {
        console.error('❌ [VISIT-SERVICE] Error loading today visits:', error);
        return [];
      }
    }

    getVisitsByDateRange(startDate, endDate) {
      // Implementation for date range queries
      // This would iterate through storage keys between dates
      return []; // Simplified for now
    }

    calculateAverageDuration(visits) {
      if (visits.length === 0) return 0;
      const total = visits.reduce((sum, v) => sum + (v.totalDuration || 0), 0);
      return Math.round(total / visits.length / 1000); // in seconds
    }

    analyzeRiskFactors(riskyVisits) {
      return {
        mostCommonIncidents: this.getMostCommonIncidents(riskyVisits),
        riskZones: this.getRiskZones(riskyVisits),
        timePatterns: this.getTimePatterns(riskyVisits)
      };
    }

    detectPatterns(visits) {
      // Pattern detection logic
      return {
        peakHours: [],
        commonZones: [],
        repeatVisitors: []
      };
    }

    generateRecommendations(visits) {
      // Generate security recommendations based on visit patterns
      return [
        'Monitor high-risk zones more frequently',
        'Consider additional security measures during peak hours',
        'Review access permissions for repeat violators'
      ];
    }

    getMostCommonIncidents(visits) {
      const incidents = {};
      visits.forEach(v => {
        v.incidents.forEach(i => {
          incidents[i.type] = (incidents[i.type] || 0) + 1;
        });
      });
      return Object.entries(incidents).sort((a, b) => b[1] - a[1]).slice(0, 5);
    }

    getRiskZones(visits) {
      const zones = {};
      visits.forEach(v => {
        v.zones.forEach(z => {
          zones[z] = (zones[z] || 0) + 1;
        });
      });
      return Object.entries(zones).sort((a, b) => b[1] - a[1]).slice(0, 3);
    }

    getTimePatterns(visits) {
      const hours = {};
      visits.forEach(v => {
        const hour = new Date(v.startTime).getHours();
        hours[hour] = (hours[hour] || 0) + 1;
      });
      return Object.entries(hours).sort((a, b) => b[1] - a[1]).slice(0, 3);
    }

    // ========== BACKEND INTEGRATION ==========

    publishVisitStart(visit) {
      if (this.mqttClient) {
        const payload = {
          visitId: visit.visitId,
          cardId: visit.cardId,
          person: visit.person,
          truck: visit.truck,
          startTime: visit.startTime,
          entryTime: visit.entryTime,
          recordedBy: visit.recordedBy
        };

        this.mqttClient.publish(CONFIG.backend.mqttTopics.visitStart, JSON.stringify(payload));
      }

      // Add to REST queue
      this.visitQueue.push({
        type: 'visit-start',
        data: visit,
        timestamp: Date.now()
      });
    }

    publishVisitEnd(visit) {
      if (this.mqttClient) {
        const payload = {
          visitId: visit.visitId,
          cardId: visit.cardId,
          endTime: visit.endTime,
          duration: visit.totalDuration,
          incidents: visit.incidents.length,
          riskLevel: visit.riskLevel
        };

        this.mqttClient.publish(CONFIG.backend.mqttTopics.visitStop, JSON.stringify(payload));
      }

      // Add to REST queue
      this.visitQueue.push({
        type: 'visit-end',
        data: visit,
        timestamp: Date.now()
      });
    }

    publishIncident(visit, incident) {
      if (this.mqttClient) {
        const payload = {
          visitId: visit.visitId,
          incident: incident,
          riskLevel: visit.riskLevel
        };

        this.mqttClient.publish(CONFIG.backend.mqttTopics.incidentEval, JSON.stringify(payload));
      }
    }

    // Initialize backend connections (to be called when backend is available)
    initBackend(mqttClient, restClient) {
      this.mqttClient = mqttClient;
      this.restClient = restClient;
      console.log('🔗 [VISIT-SERVICE] Backend connections initialized');
    }
  }

  // Export as global service
  window.SSHRVisitService = new SSHRVisitService();
  console.log('✅ [VISIT-SERVICE] SSHR Visit Service loaded and ready');

})();
