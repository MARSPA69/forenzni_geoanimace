module.exports = {
  content: [
    "./adminlte/dist/SSHR_Bohuslavice/**/*.html",
    "./adminlte/dist/SSHR_Bohuslavice/**/*.js"
  ],
  theme: {
    extend: {
      colors: {
        stone: {
          900: '#1c1917'
        },
        teal: {
          500: '#14b8a6'
        },
        cyan: {
          700: '#0e7490'
        }
      }
    }
  },
  plugins: []
};
