/**
 * SSHR Bohuslavice Integration Test
 * ================================
 *
 * This script tests the integration of all SSHR modules
 * to ensure they work together correctly.
 *
 * Usage: Run this in browser console after page loads
 */

console.log("🧪 [INTEGRATION-TEST] Starting SSHR Bohuslavice integration test...");

const IntegrationTest = {
    results: {
        passed: 0,
        failed: 0,
        tests: []
    },

    // Test helper functions
    assert(condition, message) {
        if (condition) {
            this.results.passed++;
            this.results.tests.push({ status: 'PASS', message });
            console.log(`✅ [TEST-PASS] ${message}`);
        } else {
            this.results.failed++;
            this.results.tests.push({ status: 'FAIL', message });
            console.error(`❌ [TEST-FAIL] ${message}`);
        }
    },

    // Test module availability
    testModuleAvailability() {
        console.log("📦 [TEST] Testing module availability...");

        this.assert(typeof window.SSHR_CONFIG !== 'undefined', 'SSHR_CONFIG is available');
        this.assert(typeof window.SSHR !== 'undefined', 'Main SSHR object is available');
        this.assert(typeof window.PersonTracker !== 'undefined', 'PersonTracker class is available');
        this.assert(typeof window.SSHRCardManager !== 'undefined', 'SSHRCardManager is available');
        this.assert(typeof window.IncidentManager !== 'undefined', 'IncidentManager class is available');
        this.assert(typeof window.leafletMap !== 'undefined', 'Leaflet map is available');
        this.assert(typeof window.ANCHOR_SSHR !== 'undefined', 'ANCHOR_SSHR data is available');
        this.assert(typeof window.SSHR_CONFIG !== 'undefined', 'SSHR_CONFIG is available');
        this.assert(typeof window.SSHR_ZONES !== 'undefined', 'SSHR_ZONES is available');
        this.assert(typeof window.SSHR_ZONES_API !== 'undefined', 'SSHR_ZONES_API is available');
    },

    // Test PersonTracker functionality
    testPersonTracker() {
        console.log("👤 [TEST] Testing PersonTracker functionality...");

        if (!window.SSHR || !window.SSHR.personTracker) {
            this.assert(false, 'PersonTracker instance not found in SSHR');
            return;
        }

        const tracker = window.SSHR.personTracker;
        const testPosition = [50.33051536896484, 16.094826778414713];

        // Test adding person
        const person = tracker.addPerson('TEST_PERSON_001', testPosition, {
            name: 'Test Person',
            cardId: 'TEST_CARD_001'
        });

        this.assert(person !== null, 'PersonTracker can add a person');
        this.assert(person.id === 'TEST_PERSON_001', 'Person has correct ID');
        this.assert(person.metadata.name === 'Test Person', 'Person has correct name');

        // Test getting person
        const retrievedPerson = tracker.getPerson('TEST_PERSON_001');
        this.assert(retrievedPerson !== undefined, 'PersonTracker can retrieve added person');

        // Test updating position
        const newPosition = [50.33051636896484, 16.094836778414713];
        const updateResult = tracker.updatePersonPosition('TEST_PERSON_001', newPosition);
        this.assert(updateResult === true, 'PersonTracker can update person position');

        // Test removing person
        const removeResult = tracker.removePerson('TEST_PERSON_001');
        this.assert(removeResult === true, 'PersonTracker can remove person');
    },

    // Test SSHRCardManager functionality
    testVisitorCardManager() {
        console.log("🎴 [TEST] Testing SSHRCardManager functionality...");

        if (!window.SSHRCardManager) {
            this.assert(false, 'SSHRCardManager instance not found');
            return;
        }

        const manager = window.SSHRCardManager;
        if (!manager.initialized) {
            manager.init({ initialCardCount: 3 });
        }
        manager.clearAllAssignments();

        this.assert(Array.isArray(manager.cards), 'SSHRCardManager exposes cards array');
        this.assert(manager.cards.length > 0, 'SSHRCardManager generated default cards');

        const card = manager.cards[0];
        this.assert(card.status === 'free', 'New card is free');

        // Prepare artificial drop zone
        const dropZone = document.createElement('div');
        dropZone.className = 'card-drop-zone';
        document.body.appendChild(dropZone);

        manager.registerDropZone({ querySelector: () => dropZone }, { id: 'TEST_PANEL', name: 'SSHR_DATA1' });

        manager.assignmentContext = {
            card,
            dropZone,
            panelId: 'TEST_PANEL',
            datasetName: 'SSHR_DATA1'
        };

        document.getElementById('assignment-type').value = 'person';
        document.getElementById('assignment-first-name').value = 'Jan';
        document.getElementById('assignment-last-name').value = 'Novák';
        document.getElementById('assignment-op-number').value = '123456789';
        document.getElementById('assignment-recorded-by').value = 'Operátor';
        document.getElementById('assignment-entry-time').value = '08:00:00';

        manager.handleAssignmentSubmit(new Event('submit'));
        this.assert(card.status === 'assigned', 'Card assigned through manager');
        this.assert(dropZone.classList.contains('has-card'), 'Drop zone updated with assigned card');

        manager.recordIncident('SSHR_DATA1', { type: 'test-incident' });
        this.assert(card.incidents.length === 1, 'Incident recorded for dataset');

        manager.openExitModal(card);
        document.getElementById('exit-exit-time').value = '09:00:00';
        manager.handleExitSubmit(new Event('submit'));

        this.assert(card.status === 'free', 'Card returned to pool after exit');
        manager.unregisterDropZone('TEST_PANEL');
        document.body.removeChild(dropZone);
    },

    // Test IncidentManager functionality
    testIncidentManager() {
        console.log("🚨 [TEST] Testing IncidentManager functionality...");

        if (!window.SSHR || !window.SSHR.incidentManager) {
            this.assert(false, 'IncidentManager instance not found in SSHR');
            return;
        }

        const incidentManager = window.SSHR.incidentManager;

        // Test handling incident
        const testIncident = {
            type: 'zone-violation',
            person: 'TEST_PERSON_001',
            message: 'Test zone violation incident',
            priority: 'high'
        };

        const incident = incidentManager.handleIncident(testIncident);
        this.assert(incident !== null, 'IncidentManager can handle incident');
        this.assert(incident.type === 'zone-violation', 'Incident has correct type');
        this.assert(incident.status === 'active', 'New incident has active status');

        // Test acknowledging incident
        const ackResult = incidentManager.acknowledgeIncident(incident.id, 'Test System');
        this.assert(ackResult === true, 'IncidentManager can acknowledge incident');

        // Test getting incidents
        const allIncidents = incidentManager.getAllIncidents();
        this.assert(allIncidents.length > 0, 'IncidentManager can retrieve incidents');

        const activeIncidents = incidentManager.getActiveIncidents();
        this.assert(Array.isArray(activeIncidents), 'IncidentManager can get active incidents');
    },

    // Test map integration
    testMapIntegration() {
        console.log("🗺️ [TEST] Testing map integration...");

        this.assert(window.leafletMap !== undefined, 'Leaflet map is initialized');
        this.assert(typeof window.leafletMap.getCenter === 'function', 'Map has getCenter method');

        const center = window.leafletMap.getCenter();
        this.assert(center.lat !== undefined && center.lng !== undefined, 'Map has valid center coordinates');

        // Test map bounds
        const bounds = window.leafletMap.getBounds();
        this.assert(bounds !== undefined, 'Map has bounds');

        // Test zoom level
        const zoom = window.leafletMap.getZoom();
        this.assert(zoom >= 15 && zoom <= 22, 'Map zoom level is within expected range');
    },

    // Test API integration
    testAPIIntegration() {
        console.log("🔗 [TEST] Testing API integration...");

        // Test SSHR API structure
        this.assert(typeof window.SSHR.init === 'function', 'SSHR has init function');
        this.assert(typeof window.SSHR.map === 'object', 'SSHR has map API');
        this.assert(typeof window.SSHR.persons === 'object', 'SSHR has persons API');
        this.assert(typeof window.SSHR.cards === 'object', 'SSHR has cards API');
        this.assert(typeof window.SSHR.zones === 'object', 'SSHR has zones API');
        this.assert(typeof window.SSHR.incidents === 'object', 'SSHR has incidents API');

        // Test UI API
        this.assert(typeof window.SSHR_UI === 'object', 'SSHR_UI is available');
        this.assert(typeof window.SSHR_UI.updatePersonCount === 'function', 'SSHR_UI has updatePersonCount');
        this.assert(typeof window.SSHR_UI.updateStatus === 'function', 'SSHR_UI has updateStatus');
    },

    // Test data loading
    testDataLoading() {
        console.log("📊 [TEST] Testing data loading...");

        // Test anchor data
        this.assert(Array.isArray(window.ANCHOR_SSHR), 'ANCHOR_SSHR is an array');
        this.assert(window.ANCHOR_SSHR.length > 0, 'ANCHOR_SSHR has data');

        // Test anchor data structure
        if (window.ANCHOR_SSHR.length > 0) {
            const firstAnchor = window.ANCHOR_SSHR[0];
            this.assert(typeof firstAnchor.GUID === 'string', 'Anchor has GUID');
            this.assert(typeof firstAnchor.LAT === 'number', 'Anchor has LAT');
            this.assert(typeof firstAnchor.LON === 'number', 'Anchor has LON');
        }

        // Test configuration
        this.assert(Array.isArray(window.SSHR_CONFIG?.map?.center), 'SSHR_CONFIG.map.center exists');
        this.assert(window.SSHR_CONFIG?.map?.center.length === 2, 'SSHR_CONFIG center has lat/lng');

        // Test zone data
        this.assert(window.SSHR_ZONES?.fence?.coordinates?.length >= 3, 'Fence polygon available');
        this.assert(Array.isArray(window.SSHR_ZONES?.greens), 'GREEN zones collection available');
        this.assert(window.SSHR_ZONES.greens.length > 0, 'At least one GREEN zone defined');
        this.assert(Array.isArray(window.SSHR_ZONES?.reds), 'RED zones collection available');
    },

    // Test event system
    testEventSystem() {
        console.log("📡 [TEST] Testing event system...");

        let eventReceived = false;
        const testEventHandler = (event) => {
            eventReceived = true;
        };

        // Listen for test event
        window.addEventListener('sshr-test-event', testEventHandler);

        // Trigger test event
        window.dispatchEvent(new CustomEvent('sshr-test-event', { detail: { test: true } }));

        this.assert(eventReceived === true, 'Event system can dispatch and receive events');

        // Clean up
        window.removeEventListener('sshr-test-event', testEventHandler);
    },

    // Run all tests
    runAllTests() {
        console.log("🧪 [INTEGRATION-TEST] Running complete integration test suite...");

        this.results = { passed: 0, failed: 0, tests: [] };

        try {
            this.testModuleAvailability();
            this.testMapIntegration();
            this.testDataLoading();
            this.testAPIIntegration();
            this.testEventSystem();
            this.testPersonTracker();
            this.testVisitorCardManager();
            this.testIncidentManager();
        } catch (error) {
            console.error("❌ [INTEGRATION-TEST] Test execution error:", error);
            this.assert(false, `Test execution failed: ${error.message}`);
        }

        this.printResults();
    },

    // Print test results
    printResults() {
        console.log("\n" + "=".repeat(60));
        console.log("🧪 [INTEGRATION-TEST] Test Results Summary");
        console.log("=".repeat(60));
        console.log(`✅ Passed: ${this.results.passed}`);
        console.log(`❌ Failed: ${this.results.failed}`);
        console.log(`📊 Total:  ${this.results.passed + this.results.failed}`);

        if (this.results.failed === 0) {
            console.log("🎉 [INTEGRATION-TEST] All tests passed! SSHR system is working correctly.");
        } else {
            console.log("⚠️ [INTEGRATION-TEST] Some tests failed. Check the details above.");
        }

        console.log("\n📋 [INTEGRATION-TEST] Detailed Results:");
        this.results.tests.forEach((test, index) => {
            const icon = test.status === 'PASS' ? '✅' : '❌';
            console.log(`${icon} ${index + 1}. ${test.message}`);
        });

        console.log("=".repeat(60));

        // Return results for programmatic access
        return this.results;
    }
};

// Export for console access
if (typeof window !== 'undefined') {
    window.IntegrationTest = IntegrationTest;
}

// Auto-run tests if this script is loaded directly
if (typeof window !== 'undefined' && window.location) {
    // Wait for page to fully load before running tests
    if (document.readyState === 'complete') {
        setTimeout(() => IntegrationTest.runAllTests(), 3000);
    } else {
        window.addEventListener('load', () => {
            setTimeout(() => IntegrationTest.runAllTests(), 3000);
        });
    }
}

console.log("✅ [INTEGRATION-TEST] Integration test module loaded. Run IntegrationTest.runAllTests() to execute.");
