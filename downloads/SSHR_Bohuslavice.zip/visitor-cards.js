/**
 * Visitor Cards Module for SSHR Bohuslavice
 * =========================================
 *
 * VisitorCardManager Class - Complete visitor card management system
 * Features: Drag & drop, card assignment, entry/exit tracking
 *
 * Dependencies: Bootstrap 5, SortableJS (for drag & drop)
 */

console.log("🎫 [VISITOR-CARDS] Loading VisitorCardManager module...");

class VisitorCardManager {
    constructor(containerId = '#visitor-cards-container') {
        this.container = document.querySelector(containerId);
        this.cards = new Map();
        this.assignments = new Map(); // cardId -> personId
        this.entryQueue = [];
        this.exitQueue = [];

        // Configuration
        this.config = {
            maxCards: 20,
            cardTypes: {
                'employee': { color: 'primary', icon: 'fas fa-id-badge' },
                'visitor': { color: 'success', icon: 'fas fa-user-tag' },
                'contractor': { color: 'warning', icon: 'fas fa-hard-hat' },
                'emergency': { color: 'danger', icon: 'fas fa-ambulance' }
            },
            dragOptions: {
                animation: 200,
                ghostClass: 'card-ghost',
                chosenClass: 'card-chosen',
                dragClass: 'card-drag'
            }
        };

        this.init();
        console.log("✅ [VISITOR-CARDS] Initialized successfully");
    }

    /**
     * Initialize the card system
     */
    init() {
        if (!this.container) {
            console.error("❌ [VISITOR-CARDS] Container not found");
            return;
        }

        this.setupContainer();
        this.setupDragAndDrop();
        this.setupEventListeners();
        this.loadSampleCards();
    }

    /**
     * Setup the container structure
     */
    setupContainer() {
        this.container.innerHTML = `
            <div class="visitor-cards-header mb-3">
                <div class="d-flex justify-content-between align-items-center">
                    <h6 class="mb-0"><i class="fas fa-id-card"></i> Visitor Cards</h6>
                    <div class="card-actions">
                        <button class="btn btn-sm btn-outline-primary" id="add-card-btn">
                            <i class="fas fa-plus"></i> Add Card
                        </button>
                        <button class="btn btn-sm btn-outline-secondary" id="refresh-cards-btn">
                            <i class="fas fa-sync"></i>
                        </button>
                    </div>
                </div>
            </div>

            <div class="visitor-cards-stats mb-3">
                <div class="row text-center">
                    <div class="col-4">
                        <div class="stat-item">
                            <div class="stat-value" id="total-cards">0</div>
                            <div class="stat-label">Total</div>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="stat-item">
                            <div class="stat-value text-success" id="assigned-cards">0</div>
                            <div class="stat-label">Assigned</div>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="stat-item">
                            <div class="stat-value text-warning" id="available-cards">0</div>
                            <div class="stat-label">Available</div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="visitor-cards-list" id="cards-list">
                <!-- Cards will be rendered here -->
            </div>

            <div class="entry-exit-queue mt-3" style="display: none;">
                <h6><i class="fas fa-list"></i> Entry/Exit Queue</h6>
                <div id="queue-list">
                    <!-- Queue items will be rendered here -->
                </div>
            </div>
        `;
    }

    /**
     * Setup drag and drop functionality
     */
    setupDragAndDrop() {
        const cardsList = this.container.querySelector('#cards-list');

        // TODO: Implement SortableJS when available
        // For now, we'll use simple click-to-assign
        console.log("📋 [VISITOR-CARDS] Drag & drop ready (click-to-assign mode)");
    }

    /**
     * Setup event listeners
     */
    setupEventListeners() {
        // Add card button
        const addCardBtn = this.container.querySelector('#add-card-btn');
        if (addCardBtn) {
            addCardBtn.addEventListener('click', () => this.showAddCardModal());
        }

        // Refresh button
        const refreshBtn = this.container.querySelector('#refresh-cards-btn');
        if (refreshBtn) {
            refreshBtn.addEventListener('click', () => this.refreshCards());
        }

        // Listen for person tracking events
        window.addEventListener('sshr-person-added', (e) => {
            this.handlePersonAdded(e.detail.person);
        });

        window.addEventListener('sshr-person-removed', (e) => {
            this.handlePersonRemoved(e.detail.personId);
        });
    }

    /**
     * Load sample cards for demonstration
     */
    loadSampleCards() {
        const sampleCards = [
            {
                id: 'EMP001',
                number: '001',
                type: 'employee',
                name: 'Jan Novák',
                department: 'IT',
                status: 'available',
                validFrom: new Date('2025-01-01'),
                validTo: new Date('2025-12-31')
            },
            {
                id: 'VIS001',
                number: '101',
                type: 'visitor',
                name: 'Marie Svobodová',
                company: 'External Company',
                status: 'available',
                validFrom: new Date(),
                validTo: new Date(Date.now() + 24 * 60 * 60 * 1000) // 24 hours
            },
            {
                id: 'CON001',
                number: '201',
                type: 'contractor',
                name: 'Petr Dvořák',
                company: 'Construction Ltd.',
                status: 'available',
                validFrom: new Date(),
                validTo: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000) // 7 days
            }
        ];

        sampleCards.forEach(card => this.addCard(card));
        console.log(`📋 [VISITOR-CARDS] Loaded ${sampleCards.length} sample cards`);
    }

    /**
     * Add a new card
     */
    addCard(cardData) {
        try {
            const card = {
                id: cardData.id || `CARD_${Date.now()}`,
                number: cardData.number || this.generateCardNumber(),
                type: cardData.type || 'visitor',
                name: cardData.name || 'Unknown Person',
                company: cardData.company || cardData.department || '',
                status: cardData.status || 'available',
                validFrom: cardData.validFrom || new Date(),
                validTo: cardData.validTo || new Date(Date.now() + 24 * 60 * 60 * 1000),
                assignedTo: null,
                assignedAt: null,
                createdAt: new Date(),
                ...cardData
            };

            this.cards.set(card.id, card);
            this.renderCard(card);
            this.updateStats();

            console.log(`🎫 [VISITOR-CARDS] Added card ${card.id}: ${card.name}`);

            // Trigger event
            this.triggerEvent('card-added', { card });

            return card;
        } catch (error) {
            console.error(`❌ [VISITOR-CARDS] Error adding card:`, error);
            return null;
        }
    }

    /**
     * Render a single card
     */
    renderCard(card) {
        const cardsList = this.container.querySelector('#cards-list');
        if (!cardsList) return;

        const cardType = this.config.cardTypes[card.type] || this.config.cardTypes.visitor;
        const isExpired = new Date() > card.validTo;
        const isAssigned = card.status === 'assigned';

        const cardHtml = `
            <div class="visitor-card ${isAssigned ? 'assigned' : ''} ${isExpired ? 'expired' : ''}"
                 data-card-id="${card.id}"
                 draggable="true">
                <div class="card border-${cardType.color} mb-2">
                    <div class="card-body p-2">
                        <div class="d-flex justify-content-between align-items-start">
                            <div class="card-info flex-grow-1">
                                <div class="d-flex align-items-center mb-1">
                                    <i class="${cardType.icon} text-${cardType.color} me-2"></i>
                                    <strong class="card-number">#${card.number}</strong>
                                    <span class="badge bg-${cardType.color} ms-2">${card.type}</span>
                                </div>
                                <div class="card-name">${card.name}</div>
                                ${card.company ? `<small class="text-muted">${card.company}</small>` : ''}
                            </div>
                            <div class="card-status">
                                <span class="badge bg-${this.getStatusColor(card.status)}">${card.status}</span>
                            </div>
                        </div>

                        <div class="card-footer-info mt-2">
                            <small class="text-muted">
                                Valid: ${card.validFrom.toLocaleDateString()} - ${card.validTo.toLocaleDateString()}
                            </small>
                            ${isAssigned ? `<br><small class="text-success">Assigned: ${card.assignedAt?.toLocaleTimeString()}</small>` : ''}
                        </div>

                        <div class="card-actions mt-2">
                            ${!isAssigned ? `
                                <button class="btn btn-sm btn-outline-primary assign-btn" data-card-id="${card.id}">
                                    <i class="fas fa-user-plus"></i> Assign
                                </button>
                            ` : `
                                <button class="btn btn-sm btn-outline-warning unassign-btn" data-card-id="${card.id}">
                                    <i class="fas fa-user-minus"></i> Unassign
                                </button>
                            `}
                            <button class="btn btn-sm btn-outline-secondary edit-btn" data-card-id="${card.id}">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button class="btn btn-sm btn-outline-danger delete-btn" data-card-id="${card.id}">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        `;

        // Remove existing card if it exists
        const existingCard = cardsList.querySelector(`[data-card-id="${card.id}"]`);
        if (existingCard) {
            existingCard.remove();
        }

        // Add new card
        cardsList.insertAdjacentHTML('beforeend', cardHtml);

        // Setup card event listeners
        this.setupCardEventListeners(card.id);
    }

    /**
     * Setup event listeners for a specific card
     */
    setupCardEventListeners(cardId) {
        const cardElement = this.container.querySelector(`[data-card-id="${cardId}"]`);
        if (!cardElement) return;

        // Assign button
        const assignBtn = cardElement.querySelector('.assign-btn');
        if (assignBtn) {
            assignBtn.addEventListener('click', () => this.showAssignModal(cardId));
        }

        // Unassign button
        const unassignBtn = cardElement.querySelector('.unassign-btn');
        if (unassignBtn) {
            unassignBtn.addEventListener('click', () => this.unassignCard(cardId));
        }

        // Edit button
        const editBtn = cardElement.querySelector('.edit-btn');
        if (editBtn) {
            editBtn.addEventListener('click', () => this.showEditCardModal(cardId));
        }

        // Delete button
        const deleteBtn = cardElement.querySelector('.delete-btn');
        if (deleteBtn) {
            deleteBtn.addEventListener('click', () => this.deleteCard(cardId));
        }

        // Drag events (for future drag & drop implementation)
        cardElement.addEventListener('dragstart', (e) => {
            e.dataTransfer.setData('text/plain', cardId);
            cardElement.classList.add('dragging');
        });

        cardElement.addEventListener('dragend', () => {
            cardElement.classList.remove('dragging');
        });
    }

    /**
     * Assign card to a person
     */
    assignCard(cardId, personId, personName = null) {
        const card = this.cards.get(cardId);
        if (!card) {
            console.error(`❌ [VISITOR-CARDS] Card ${cardId} not found`);
            return false;
        }

        if (card.status === 'assigned') {
            console.warn(`⚠️ [VISITOR-CARDS] Card ${cardId} is already assigned`);
            return false;
        }

        try {
            // Update card
            card.status = 'assigned';
            card.assignedTo = personId;
            card.assignedAt = new Date();

            // Update assignments map
            this.assignments.set(cardId, personId);

            // Re-render card
            this.renderCard(card);
            this.updateStats();

            console.log(`🎫 [VISITOR-CARDS] Assigned card ${cardId} to person ${personId}`);

            // Trigger event
            this.triggerEvent('card-assigned', { card, personId, personName });

            return true;
        } catch (error) {
            console.error(`❌ [VISITOR-CARDS] Error assigning card ${cardId}:`, error);
            return false;
        }
    }

    /**
     * Unassign card from person
     */
    unassignCard(cardId) {
        const card = this.cards.get(cardId);
        if (!card) {
            console.error(`❌ [VISITOR-CARDS] Card ${cardId} not found`);
            return false;
        }

        try {
            const personId = card.assignedTo;

            // Update card
            card.status = 'available';
            card.assignedTo = null;
            card.assignedAt = null;

            // Update assignments map
            this.assignments.delete(cardId);

            // Re-render card
            this.renderCard(card);
            this.updateStats();

            console.log(`🎫 [VISITOR-CARDS] Unassigned card ${cardId} from person ${personId}`);

            // Trigger event
            this.triggerEvent('card-unassigned', { card, personId });

            return true;
        } catch (error) {
            console.error(`❌ [VISITOR-CARDS] Error unassigning card ${cardId}:`, error);
            return false;
        }
    }

    /**
     * Delete a card
     */
    deleteCard(cardId) {
        if (!confirm('Are you sure you want to delete this card?')) {
            return false;
        }

        const card = this.cards.get(cardId);
        if (!card) return false;

        try {
            // Unassign if assigned
            if (card.status === 'assigned') {
                this.unassignCard(cardId);
            }

            // Remove from DOM
            const cardElement = this.container.querySelector(`[data-card-id="${cardId}"]`);
            if (cardElement) {
                cardElement.remove();
            }

            // Remove from memory
            this.cards.delete(cardId);
            this.assignments.delete(cardId);

            this.updateStats();

            console.log(`🗑️ [VISITOR-CARDS] Deleted card ${cardId}`);

            // Trigger event
            this.triggerEvent('card-deleted', { cardId, card });

            return true;
        } catch (error) {
            console.error(`❌ [VISITOR-CARDS] Error deleting card ${cardId}:`, error);
            return false;
        }
    }

    /**
     * Update statistics display
     */
    updateStats() {
        const totalCards = this.cards.size;
        const assignedCards = Array.from(this.cards.values()).filter(card => card.status === 'assigned').length;
        const availableCards = totalCards - assignedCards;

        // Update DOM
        const totalElement = this.container.querySelector('#total-cards');
        const assignedElement = this.container.querySelector('#assigned-cards');
        const availableElement = this.container.querySelector('#available-cards');

        if (totalElement) totalElement.textContent = totalCards;
        if (assignedElement) assignedElement.textContent = assignedCards;
        if (availableElement) availableElement.textContent = availableCards;
    }

    /**
     * Show assign card modal
     */
    showAssignModal(cardId) {
        // TODO: Implement modal for person selection
        // For now, use simple prompt
        const personId = prompt('Enter Person ID to assign this card to:');
        if (personId) {
            this.assignCard(cardId, personId);
        }
    }

    /**
     * Show add card modal
     */
    showAddCardModal() {
        // TODO: Implement proper modal
        // For now, use simple prompts
        const name = prompt('Enter person name:');
        const type = prompt('Enter card type (employee/visitor/contractor/emergency):') || 'visitor';
        const company = prompt('Enter company/department:') || '';

        if (name) {
            this.addCard({
                name,
                type,
                company
            });
        }
    }

    /**
     * Show edit card modal
     */
    showEditCardModal(cardId) {
        // TODO: Implement edit modal
        console.log(`📝 [VISITOR-CARDS] Edit card ${cardId} - Modal not yet implemented`);
    }

    /**
     * Handle person added event
     */
    handlePersonAdded(person) {
        // TODO: Implement automatic card suggestion
        console.log(`👤 [VISITOR-CARDS] Person added: ${person.id}, suggesting cards...`);
    }

    /**
     * Handle person removed event
     */
    handlePersonRemoved(personId) {
        // Find and unassign any cards assigned to this person
        const assignedCards = Array.from(this.cards.values())
            .filter(card => card.assignedTo === personId);

        assignedCards.forEach(card => {
            this.unassignCard(card.id);
        });

        console.log(`👤 [VISITOR-CARDS] Person removed: ${personId}, unassigned ${assignedCards.length} cards`);
    }

    /**
     * Get all cards
     */
    getAllCards() {
        return Array.from(this.cards.values());
    }

    /**
     * Get card by ID
     */
    getCard(cardId) {
        return this.cards.get(cardId);
    }

    /**
     * Get cards by status
     */
    getCardsByStatus(status) {
        return Array.from(this.cards.values()).filter(card => card.status === status);
    }

    /**
     * Get assigned person for card
     */
    getAssignedPerson(cardId) {
        return this.assignments.get(cardId);
    }

    /**
     * Generate card number
     */
    generateCardNumber() {
        const existingNumbers = Array.from(this.cards.values()).map(card => parseInt(card.number));
        const maxNumber = Math.max(0, ...existingNumbers);
        return String(maxNumber + 1).padStart(3, '0');
    }

    /**
     * Get status color for Bootstrap
     */
    getStatusColor(status) {
        const colors = {
            'available': 'success',
            'assigned': 'primary',
            'expired': 'secondary',
            'suspended': 'danger'
        };
        return colors[status] || 'secondary';
    }

    /**
     * Refresh cards display
     */
    refreshCards() {
        console.log("🔄 [VISITOR-CARDS] Refreshing cards...");

        // Clear current display
        const cardsList = this.container.querySelector('#cards-list');
        if (cardsList) {
            cardsList.innerHTML = '';
        }

        // Re-render all cards
        this.cards.forEach(card => this.renderCard(card));
        this.updateStats();
    }

    /**
     * Event system for notifications
     */
    triggerEvent(eventType, data) {
        console.log(`📡 [VISITOR-CARDS] Event: ${eventType}`, data);

        // Dispatch custom event
        if (typeof window !== 'undefined') {
            window.dispatchEvent(new CustomEvent(`sshr-${eventType}`, { detail: data }));
        }
    }

    /**
     * Cleanup method
     */
    destroy() {
        console.log("🧹 [VISITOR-CARDS] Cleaning up...");

        this.cards.clear();
        this.assignments.clear();
        this.entryQueue = [];
        this.exitQueue = [];

        if (this.container) {
            this.container.innerHTML = '';
        }
    }
}

// Export for use in main renderer
if (typeof window !== 'undefined') {
    window.VisitorCardManager = VisitorCardManager;
}

console.log("✅ [VISITOR-CARDS] VisitorCardManager class loaded successfully");